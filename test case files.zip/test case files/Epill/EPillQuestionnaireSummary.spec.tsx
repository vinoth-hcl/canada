import React from 'react';
import renderer from 'react-test-renderer';
import { EPillQuestionnaireSummary } from './EPillQuestionnaireSummary';
import { makeSaveQuestionRequestBody } from './utils';
import Adapter from 'enzyme-adapter-react-16';
import { configure, shallow } from 'enzyme';
import { SummaryCard } from '../Questionnaire/components/QuestionSummary/SummaryCard';
import { NOT_RESPONDED_TEXT } from 'src/constants/constants';
import { Footer } from '../Questionnaire/components/QuestionFooter/Footer';
import { BackButton } from '../Options/components/BackButton';


configure({ adapter: new Adapter() });

type EPillQuestionOneProps = {navigation:any, route:any}

jest.useFakeTimers();


const props: EPillQuestionOneProps = {
  navigation:{},
  route:{
    "key": "MODAL_ROUTES.EPILL_QUESTIONNAIRE_SUMMARY-zmycu_S5ScWoAYzUtjTnw",
    "name": "MODAL_ROUTES.EPILL_QUESTIONNAIRE_SUMMARY",
    "params": {
      "screenName": "How_often_do_you_have_difficulty_remembering",
      "screenId": "Medicine_Quest_8a",
      "screenAnswer": {
        "queryType": "rating",
        "value": {
          "value": "5",
          "text": "All the time",
          "nextFollowup": null
        }
      },
      "questionList": [
        {
          "id": "Medicine_Quest_1a",
          "type": "radio_button",
          "name": "Do_you_Sometimes_forget_to_take_your_Medicine",
          "title": "Do you sometimes forget to take your medicine?",
          "titleLocation": "top",
          "hideNumber": false,
          "valueName": "1a",
          "defaultValue": [
            ""
          ],
          "rateValues": [
            {
              "value": "1",
              "text": "Yes",
              "nextFollowup": null
            },
            {
              "value": "2",
              "text": "No",
              "nextFollowup": null
            }
          ],
          "questionIndex": "1"
        },
        {
          "id": "Medicine_Quest_2a",
          "type": "radio_button",
          "name": "People_sometimes_miss_taking_their_medicine_for_reasons",
          "title": "People sometimes miss taking their medicines for reasons other than forgetting. Thinking over the past 2 weeks, were there any days when you did not take your medicine?",
          "titleLocation": "top",
          "hideNumber": false,
          "valueName": "2a",
          "defaultValue": [
            
          ],
          "rateValues": [
            {
              "value": "1",
              "text": "Yes",
              "nextFollowup": null
            },
            {
              "value": "2",
              "text": "No",
              "nextFollowup": null
            }
          ],
          "questionIndex": "1"
        },
        {
          "id": "Medicine_Quest_3a",
          "type": "radio_button",
          "name": "Have_you_ever_cut_back_or_stopped_taking_your_medicine",
          "title": "Have you ever cut back or stopped taking your medicine without telling your doctor because you felt worse when you took it?",
          "titleLocation": "top",
          "hideNumber": false,
          "valueName": "3a",
          "defaultValue": [
            
          ],
          "rateValues": [
            {
              "value": "1",
              "text": "Yes",
              "nextFollowup": null
            },
            {
              "value": "2",
              "text": "No",
              "nextFollowup": null
            }
          ],
          "questionIndex": "1"
        },
        {
          "id": "Medicine_Quest_4a",
          "type": "radio_button",
          "name": "When_you_travel_or_leave_home",
          "title": "When you travel or leave home, do you sometimes forget to bring along your medicine?",
          "titleLocation": "top",
          "hideNumber": false,
          "valueName": "4a",
          "defaultValue": [
            
          ],
          "rateValues": [
            {
              "value": "1",
              "text": "Yes",
              "nextFollowup": null
            },
            {
              "value": "2",
              "text": "No",
              "nextFollowup": null
            }
          ],
          "questionIndex": "1"
        },
        {
          "id": "Medicine_Quest_5a",
          "type": "radio_button",
          "name": "Did_you_take_all_your_medicines_yesterday?",
          "title": "Did you take all your medicines yesterday?",
          "titleLocation": "top",
          "hideNumber": false,
          "valueName": "5a",
          "defaultValue": [
            
          ],
          "rateValues": [
            {
              "value": "1",
              "text": "Yes",
              "nextFollowup": null
            },
            {
              "value": "2",
              "text": "No",
              "nextFollowup": null
            }
          ],
          "questionIndex": "1"
        },
        {
          "id": "Medicine_Quest_6a",
          "type": "radio_button",
          "name": "When_you_feel_like_all_your_symptoms_are_under_control",
          "title": "When you feel like your symptoms are under control, do you sometimes stop taking your medicine?",
          "titleLocation": "top",
          "hideNumber": false,
          "valueName": "6a",
          "defaultValue": [
            
          ],
          "rateValues": [
            {
              "value": "1",
              "text": "Yes",
              "nextFollowup": null
            },
            {
              "value": "2",
              "text": "No",
              "nextFollowup": null
            }
          ],
          "questionIndex": "1"
        },
        {
          "id": "Medicine_Quest_7a",
          "type": "radio_button",
          "name": "Taking_medicines_everyday_is_a_real",
          "title": "Taking medicine every day is a real inconvenience for some people. Do you ever feel hassled about sticking to your treatment plan?",
          "titleLocation": "top",
          "hideNumber": false,
          "valueName": "7a",
          "defaultValue": [
            
          ],
          "rateValues": [
            {
              "value": "1",
              "text": "Yes",
              "nextFollowup": null
            },
            {
              "value": "2",
              "text": "No",
              "nextFollowup": null
            }
          ],
          "questionIndex": "1"
        },
        {
          "id": "Medicine_Quest_8a",
          "type": "radio_button",
          "name": "How_often_do_you_have_difficulty_remembering",
          "title": "How often do you have difficulty remembering to take all your medicine?",
          "titleLocation": "top",
          "hideNumber": false,
          "valueName": "8a",
          "defaultValue": [
            
          ],
          "rateValues": [
            {
              "value": "1",
              "text": "Never/rarely",
              "nextFollowup": null
            },
            {
              "value": "2",
              "text": "Once in a while",
              "nextFollowup": null
            },
            {
              "value": "3",
              "text": "Sometimes",
              "nextFollowup": null
            },
            {
              "value": "4",
              "text": "Usually",
              "nextFollowup": null
            },
            {
              "value": "5",
              "text": "All the time",
              "nextFollowup": null
            }
          ],
          "questionIndex": "1"
        }
      ],
      "configValues": {
        "id": "83d2f219-fcc9-4e7e-a0aa-7ba9b8f91c62",
        "etemplateConfigId": "c658e24f-364f-40da-ae06-1d988dd7c3a7",
        "userId": "42f5a5cd-162e-4b1e-b2a3-0dc942a52fd3",
        "patientResponses": [
          
        ],
        "patientId": "42f5a5cd-162e-4b1e-b2a3-0dc942a52fd3",
        "isCompleted": true,
        "resubmitFlag": false
      }
    }
  }
}

jest.mock('../../services/epill/selector', () => {
  const data = [
    {
      "questionName": "Do_you_Sometimes_forget_to_take_your_Medicine",
      "questionTitle": "Do you sometimes forget to take your medicine?",
      "questionId": "1a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "2",
          "text": "No",
          "nextFollowup": null
        }
      }
    },
    {
      "questionName": "People_sometimes_miss_taking_their_medicine_for_reasons",
      "questionTitle": "People sometimes miss taking their medicines for reasons other than forgetting. Thinking over the past 2 weeks, were there any days when you did not take your medicine?",
      "questionId": "Medicine_Quest_2a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_2a",
        "type": "radio_button",
        "name": "People_sometimes_miss_taking_their_medicine_for_reasons",
        "title": "People sometimes miss taking their medicines for reasons other than forgetting. Thinking over the past 2 weeks, were there any days when you did not take your medicine?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "2a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "Have_you_ever_cut_back_or_stopped_taking_your_medicine",
      "questionTitle": "Have you ever cut back or stopped taking your medicine without telling your doctor because you felt worse when you took it?",
      "questionId": "Medicine_Quest_3a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_3a",
        "type": "radio_button",
        "name": "Have_you_ever_cut_back_or_stopped_taking_your_medicine",
        "title": "Have you ever cut back or stopped taking your medicine without telling your doctor because you felt worse when you took it?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "3a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "When_you_travel_or_leave_home",
      "questionTitle": "When you travel or leave home, do you sometimes forget to bring along your medicine?",
      "questionId": "Medicine_Quest_4a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_4a",
        "type": "radio_button",
        "name": "When_you_travel_or_leave_home",
        "title": "When you travel or leave home, do you sometimes forget to bring along your medicine?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "4a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "Did_you_take_all_your_medicines_yesterday?",
      "questionTitle": "Did you take all your medicines yesterday?",
      "questionId": "Medicine_Quest_5a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_5a",
        "type": "radio_button",
        "name": "Did_you_take_all_your_medicines_yesterday?",
        "title": "Did you take all your medicines yesterday?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "5a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "When_you_feel_like_all_your_symptoms_are_under_control",
      "questionTitle": "When you feel like your symptoms are under control, do you sometimes stop taking your medicine?",
      "questionId": "Medicine_Quest_6a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_6a",
        "type": "radio_button",
        "name": "When_you_feel_like_all_your_symptoms_are_under_control",
        "title": "When you feel like your symptoms are under control, do you sometimes stop taking your medicine?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "6a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "Taking_medicines_everyday_is_a_real",
      "questionTitle": "Taking medicine every day is a real inconvenience for some people. Do you ever feel hassled about sticking to your treatment plan?",
      "questionId": "Medicine_Quest_7a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_7a",
        "type": "radio_button",
        "name": "Taking_medicines_everyday_is_a_real",
        "title": "Taking medicine every day is a real inconvenience for some people. Do you ever feel hassled about sticking to your treatment plan?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "7a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "How_often_do_you_have_difficulty_remembering",
      "questionTitle": "How often do you have difficulty remembering to take all your medicine?",
      "questionId": "Medicine_Quest_8a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "5",
          "text": "All the time",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_8a",
        "type": "radio_button",
        "name": "How_often_do_you_have_difficulty_remembering",
        "title": "How often do you have difficulty remembering to take all your medicine?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "8a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Never/rarely",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "Once in a while",
            "nextFollowup": null
          },
          {
            "value": "3",
            "text": "Sometimes",
            "nextFollowup": null
          },
          {
            "value": "4",
            "text": "Usually",
            "nextFollowup": null
          },
          {
            "value": "5",
            "text": "All the time",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "Do_you_Sometimes_forget_to_take_your_Medicine",
      "questionTitle": "Do you sometimes forget to take your medicine?",
      "questionId": "Medicine_Quest_1a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "2",
          "text": "No",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_1a",
        "type": "radio_button",
        "name": "Do_you_Sometimes_forget_to_take_your_Medicine",
        "title": "Do you sometimes forget to take your medicine?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "1a",
        "defaultValue": [
          "Yes"
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    }
  ]
  return {
    getQuestionChoices: data,
  };
});

jest.mock('react-redux', () => {
  return {
    useDispatch: () => jest.fn(),
    useSelector: jest.fn((selector) => selector),
  };
});

jest.mock('../../utilities/config', () => {
  return {
    isWebView: jest.fn().mockReturnValue(false).mockReturnValueOnce(true),
  };
});

jest.mock('../../hooks/breakpoints', () => {
  return {
    useIsPortrait: jest.fn().mockReturnValue(false),
  };
});

jest.mock('../../services/epill/selector', () => {
  return {
    getStepCount: 8,
  };
});

describe('EPillQuestionnaireSummary component test', () => {
  beforeEach(jest.useFakeTimers);
  afterEach(jest.useRealTimers);

  it('to match snapshot for native version', () => {
    const tree = renderer.create(<EPillQuestionnaireSummary {...props}/>).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('to match snapshot for web version', () => {
    const tree = renderer.create(<EPillQuestionnaireSummary {...props}/>).toJSON();
    expect(tree).toMatchSnapshot();
  }); 
  
  // it('SummaryCard  test', () => {
  //   const onBackButtonPress = jest.fn()
    

  //   const component = shallow(
  //       <EPillQuestionnaireSummary {... props}/>
  //   );
  //   const refreshTrigger: any = component.find(SummaryCard);   
  //   refreshTrigger.props().changeText(NOT_RESPONDED_TEXT);
    
  //   expect(component).toMatchSnapshot();
  // });

  it('Footer  test', () => {
    const handleSubmit = jest.fn()
    const onPressPrevPage = jest.fn()
    const component = shallow(
        <EPillQuestionnaireSummary {... props}/>
    );
    const refreshTrigger: any = component.find(Footer);   
    refreshTrigger.props().onPressNextPage(handleSubmit());
    refreshTrigger.props().onPressPrevPage(onPressPrevPage());
    
    expect(component).toMatchSnapshot();
  });

  it('BackButton  test', () => {
    const onBackButtonPress = jest.fn()
    

    const component = shallow(
        <EPillQuestionnaireSummary {... props}/>
    );
    const refreshTrigger: any = component.find(BackButton);   
    refreshTrigger.props().onPress(onBackButtonPress());
    
    expect(component).toMatchSnapshot();
  });


});

import { configure, shallow } from 'enzyme';
import React from 'react';
import { TouchableOpacity } from 'react-native-gesture-handler';
import renderer from 'react-test-renderer';
import { EmailInputItem } from './EmailInputItem';
import { IEmailInputItemProps } from './types';
import Adapter from 'enzyme-adapter-react-16';
import { TextInput } from 'react-native';


configure({ adapter: new Adapter() });

jest.useFakeTimers();

jest.mock('react-redux', () => {
    return {
      useDispatch: () => jest.fn(),
      useSelector: jest.fn((selector) => selector),
    };
  });

const props: IEmailInputItemProps = {
    item:{"id":"Input_2","emailAddr":"test@gmail.com","isActive":true,"freshAdd":false, "emailValid": true},
    removeInput:() => jest.fn(),
    updateEmailAddress: () => jest.fn()
  }

  const props2: IEmailInputItemProps = {
    item:{"id":"Input_3","emailAddr":"testing@gmail.com","isActive":false,"freshAdd":true, "emailValid": false},
    removeInput:() => jest.fn(),
    updateEmailAddress: () => jest.fn()
  }
  
describe('EmailInputItem component test', () => {
  const removeEmailField = jest.fn();
  const updateEmailField = jest.fn();
  const onEmailFieldChange = jest.fn();


  it('to match snapshot', () => {
    const tree = renderer.create(<EmailInputItem {... props}/>).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('to match snapshot', () => {
    const tree = renderer.create(<EmailInputItem {... props2}/>).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('TouchableOpacity  test', () => {
    const component = shallow(
        <EmailInputItem {... props}/>
    );
    const refreshTrigger: any = component.find(TouchableOpacity);   
    refreshTrigger.props().onPress(removeEmailField());
    expect(component).toMatchSnapshot();
  });

  it('TouchableOpacity  test', () => {
    const component = shallow(
        <EmailInputItem {... props}/>
    );
    const refreshTrigger: any = component.find(TextInput);   
    refreshTrigger.props().onEndEditing(updateEmailField());
    refreshTrigger.props().onChangeText(onEmailFieldChange("test@gmail.com"));
    expect(component).toMatchSnapshot();
  });
});



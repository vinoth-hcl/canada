import { RouteProp } from '@react-navigation/native';
import * as React from 'react';

import renderer, { act } from 'react-test-renderer';
import { MODAL_ROUTES } from '../../../src/navigation/routes';
import { ModalStackParamList } from '../../../src/navigation/types';
import configureStore from 'redux-mock-store';
import { AutoCompleteTextInput } from '../../../src/components/AutoCompleteTextInput/AutoCompleteTextInput';
import { NavigationHeader } from '../Instruction/components/NavigationHeader';
import { Button } from '../../../src/components/Button/Button';
import { AddThirdPersonPage } from './AddThirdPersonPage';
import Adapter from 'enzyme-adapter-react-16';

import Enzyme, { configure, mount, shallow } from "enzyme";
import { get } from 'lodash';

configure({ adapter: new Adapter() });


jest.useFakeTimers();

jest.mock('react-redux', () => {
  return {
    useDispatch: () => jest.fn(),
    useSelector: jest.fn((selector) => selector),
  };
});


type AddThirdPersonRouteScreenNavigationProp = RouteProp<
  ModalStackParamList,
  MODAL_ROUTES.ADD_THIRD_PERSON
>;
interface IAddThirdPersonProps {
  route: AddThirdPersonRouteScreenNavigationProp;
}

const props: IAddThirdPersonProps = {
  route: {
    "key": "MODAL_ROUTES.ADD_THIRD_PERSON-O_sdi1YjaFCuyA5ydOwXy",
    "name": MODAL_ROUTES.ADD_THIRD_PERSON,
    "params": {
      "id": "c67dd187-8d8a-42a2-bd07-5f8f796622ac",
    }
  }
}

jest.mock('../../services/patient/selector', () => {
  const data = {
    "id": "42f5a5cd-162e-4b1e-b2a3-0dc942a52fd3",
    "username": "grumpy-cs3",
    "age": 0,
    "weight": 0,
    "height": 0,
    "activeInputAlerts": [

    ],
    "activeCallRequest": {

    },
    "lastMeasurements": [

    ],
    "trial": {
      "id": "b179b52b-63ca-4b8d-a2ee-35e05589ac9e",
      "name": "PROOF-OF-CONCEPT, NON-INTERVENTIONAL, SINGLE-ARM DECENTRALIZED CLINICAL TRIAL IN ONCOLOGY PATIENTS RECEIVING TREATMENT IN THE VETERANS HEALTH ADMINISTRATION: POTENTIAL",
      "title": "PROOF-OF-CONCEPT, NON-INTERVENTIONAL, SINGLE-ARM DECENTRALIZED CLINICAL TRIAL IN ONCOLOGY PATIENTS RECEIVING TREATMENT IN THE VETERANS HEALTH ADMINISTRATION: POTENTIAL",
      "code": "ML42507"
    },
    "enrollmentDate": "2021-05-17",
    "startDate": "2021-05-17T08:01:55.098509Z",
    "lastLoggedIn": "2021-07-06T12:53:25.881054Z",
    "subjectId": "19050",
    "hcpStudy": {
      "id": "58bc9b72-70e1-401a-ac69-98622500b9b2",
      "role": {
        "id": "44a34945-d86f-45e3-acc1-c97fc12e693d",
        "name": "PrincipalInvestigator",
        "doctor": true
      },
      "enrollmentDate": "2021-05-17T06:12:06.458099Z",
      "hcp": {
        "id": "9313f021-5df4-4ffb-857a-4ec9116a5bba",
        "hcpNumber": "grumpy-pi",
        "name": "VA Grumpy PI",
        "loginName": "grumpy-pi",
        "phoneNumber": "9999999999",
        "email": "",
        "status": "ACTIVE",
        "site": {
          "id": "68cd5f6d-0844-47b8-be49-20cb9a7eda0e",
          "name": "VA Durham Site",
          "country": "US",
          "number": "120011",
          "timeZone": "America/New_York"
        }
      },
      "trial": {
        "id": "b179b52b-63ca-4b8d-a2ee-35e05589ac9e",
        "title": "PROOF-OF-CONCEPT, NON-INTERVENTIONAL, SINGLE-ARM DECENTRALIZED CLINICAL TRIAL IN ONCOLOGY PATIENTS RECEIVING TREATMENT IN THE VETERANS HEALTH ADMINISTRATION: POTENTIAL",
        "code": "ML42507"
      }
    },
    "status": "STUDY_STARTED",
    "site": {
      "id": "68cd5f6d-0844-47b8-be49-20cb9a7eda0e",
      "name": "VA Durham Site",
      "country": "US",
      "number": "120011",
      "timeZone": "America/New_York"
    },
    "device": {

    },
    "nextAppointmentDate": "2021-05-19T07:30:00Z",
    "nextAppointmentId": "36a14fab-7eb6-4c22-9d09-87867370dd7d",
    "readyToComplete": false,
    "actionRequests": [

    ]
  }
  return {
    getProfile: data,
  };
});

jest.mock('../../services/appointments/selector', () => {
  const data = {
    "data": {
      "thirdPersonList": [
        {
          "emailId": "vinoth@gene.com",
          "name": "",
          "isActive": true
        },
        {
          "emailId": "vinoth1@gene.com",
          "name": "",
          "isActive": true
        },
        {
          "emailId": "vinoth2@gene.com",
          "name": "",
          "isActive": true
        },
        {
          "emailId": "vinoth@roche.com",
          "name": "",
          "isActive": true
        },
        {
          "emailId": "varri.divya@gene.com",
          "name": "",
          "isActive": true
        },
        {
          "emailId": "divya@gmail.com",
          "name": "",
          "isActive": true
        }
      ]
    },
    "pending": 0
  }
  return {
    getThirdPersonsByPatient: data,
  };
});

describe('AddThirdPersonPage test', () => {

  const onSuggestionSelect = jest.fn();
  const addButtonPress = jest.fn();
  const handleBack = jest.fn();
  const handleSubmit = jest.fn();

  it('to match snapshot', () => {
    const tree = renderer.create(<AddThirdPersonPage {...props} />).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('AddThirdPersonPage onchange test', () => {
    const component = shallow(
      <AddThirdPersonPage {...props} />
    );
    const refreshTrigger: any = component.find(AutoCompleteTextInput);
    refreshTrigger.props().onChangeText("t");
    refreshTrigger.props().onChangeText("div");
    refreshTrigger.props().onChangeText("");
    refreshTrigger.props().onChangeText("test@gmail.com");
    refreshTrigger.props().onSuggestionSelect(onSuggestionSelect("text"));
    refreshTrigger.props().addButtonPress(addButtonPress());
    expect(component).toMatchSnapshot();
  });

  it('handleBack  test', () => {
    const component = shallow(
      <AddThirdPersonPage {...props} />
    );
    const refreshTrigger: any = component.find(NavigationHeader);
    refreshTrigger.props().handleBack(handleBack());
    expect(component).toMatchSnapshot();
  });

  it('Button  test', () => {
    const component = shallow(
      <AddThirdPersonPage {...props} />
    );
    const refreshTrigger: any = component.find(Button);
    refreshTrigger.props().onPress(handleSubmit());
    expect(component).toMatchSnapshot();
  });

  const route = {"key":"MODAL_ROUTES.ADD_THIRD_PERSON-O_sdi1YjaFCuyA5ydOwXy","name":"MODAL_ROUTES.ADD_THIRD_PERSON","params":{"id":"c67dd187-8d8a-42a2-bd07-5f8f796622ac"}}
  const GET_PARAM_THIRD_PERSON_LIST_PATH = 'params.thirdPersonList'
  
  it('useeffect  test', () => {
    expect(get(route, GET_PARAM_THIRD_PERSON_LIST_PATH, [])).toStrictEqual([]);
    // expect(get(route, GET_PARAM_THIRD_PERSON_LIST_PATH, [])).toStrictEqual([]);
  });

});

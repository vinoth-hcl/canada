import { makeSaveQuestionRequestBody } from './utils';

describe('Add third persons utils tests', () => {
 const selectedAnswers = [
    {
      "questionName": "Do_you_Sometimes_forget_to_take_your_Medicine",
      "questionTitle": "Do you sometimes forget to take your medicine?",
      "questionId": "1a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      }
    },
    {
      "questionName": "People_sometimes_miss_taking_their_medicine_for_reasons",
      "questionTitle": "People sometimes miss taking their medicines for reasons other than forgetting. Thinking over the past 2 weeks, were there any days when you did not take your medicine?",
      "questionId": "Medicine_Quest_2a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_2a",
        "type": "radio_button",
        "name": "People_sometimes_miss_taking_their_medicine_for_reasons",
        "title": "People sometimes miss taking their medicines for reasons other than forgetting. Thinking over the past 2 weeks, were there any days when you did not take your medicine?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "2a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "Have_you_ever_cut_back_or_stopped_taking_your_medicine",
      "questionTitle": "Have you ever cut back or stopped taking your medicine without telling your doctor because you felt worse when you took it?",
      "questionId": "Medicine_Quest_3a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_3a",
        "type": "radio_button",
        "name": "Have_you_ever_cut_back_or_stopped_taking_your_medicine",
        "title": "Have you ever cut back or stopped taking your medicine without telling your doctor because you felt worse when you took it?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "3a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    },
    {
      "questionName": "When_you_travel_or_leave_home",
      "questionTitle": "When you travel or leave home, do you sometimes forget to bring along your medicine?",
      "questionId": "Medicine_Quest_4a",
      "answer": {
        "queryType": "rating",
        "value": {
          "value": "1",
          "text": "Yes",
          "nextFollowup": null
        }
      },
      "question": {
        "id": "Medicine_Quest_4a",
        "type": "radio_button",
        "name": "When_you_travel_or_leave_home",
        "title": "When you travel or leave home, do you sometimes forget to bring along your medicine?",
        "titleLocation": "top",
        "hideNumber": false,
        "valueName": "4a",
        "defaultValue": [
          
        ],
        "rateValues": [
          {
            "value": "1",
            "text": "Yes",
            "nextFollowup": null
          },
          {
            "value": "2",
            "text": "No",
            "nextFollowup": null
          }
        ],
        "questionIndex": "1"
      }
    }
  ];
  const currentAnswer = {
    "question": "When you travel or leave home, do you sometimes forget to bring along your medicine?",
    "valueName": "Medicine_Quest_4a",
    "answer": [
      "Yes"
    ]
  };
  const configValues = {
    "id": "b6e2baaa-a18a-40d6-9a98-50cdd0403111",
    "etemplateConfigId": "c658e24f-364f-40da-ae06-1d988dd7c3a7",
    "userId": "42f5a5cd-162e-4b1e-b2a3-0dc942a52fd3",
    "patientResponses": [
      
    ],
    "patientId": "42f5a5cd-162e-4b1e-b2a3-0dc942a52fd3",
    "isCompleted": true,
    "resubmitFlag": false
  };
  const result = {
    "id": "b6e2baaa-a18a-40d6-9a98-50cdd0403111",
    "etemplateConfigId": "c658e24f-364f-40da-ae06-1d988dd7c3a7",
    "userId": "42f5a5cd-162e-4b1e-b2a3-0dc942a52fd3",
    "patientId": "42f5a5cd-162e-4b1e-b2a3-0dc942a52fd3",
    "patientResponses": [
      {
        "question": "Do you sometimes forget to take your medicine?",
        "valueName": "1a",
        "answer": [
          "Yes"
        ]
      },
      {
        "question": "People sometimes miss taking their medicines for reasons other than forgetting. Thinking over the past 2 weeks, were there any days when you did not take your medicine?",
        "valueName": "Medicine_Quest_2a",
        "answer": [
          "Yes"
        ]
      },
      {
        "question": "Have you ever cut back or stopped taking your medicine without telling your doctor because you felt worse when you took it?",
        "valueName": "Medicine_Quest_3a",
        "answer": [
          "Yes"
        ]
      },
      {
        "question": "When you travel or leave home, do you sometimes forget to bring along your medicine?",
        "valueName": "Medicine_Quest_4a",
        "answer": [
          "Yes"
        ]
      }
    ],
    "isCompleted": true,
    "resubmitFlag": false
  }
 

 describe('makeSaveQuestionRequestBody test', () => {
    it('should return true', () => {
        expect(makeSaveQuestionRequestBody(selectedAnswers, currentAnswer, configValues)).toEqual(result);
    });
    });

});

import React, { ReactElement } from 'react';
import { View } from 'react-native';
import { AccordionItem } from '../../components/AccordionView/types';
import { TASK_TYPES } from './types';

const mockViews: {
  [k: string]: ReactElement;
} = {
  overview: <View style={{ height: 380 }} />,
  appointment: <View style={{ height: 100 }} />,
};
export const mockData: AccordionItem[] = [
  {
    title: 'Overview',
    type: 'simple',
    children: mockViews.overview,
  },
  {
    title: 'To-do list',
    type: 'simple',
    amount: 3,
  },
  {
    title: 'Notifications',
    type: 'notifications',
    amount: 3,
    children: mockViews.overview,
  },
];

export const DASHBOARD_MOCK_DATA = [
  {
    id: '0',
    type: TASK_TYPES.SYNC_OURA_RING_REGULAR,
  },
  {
    id: '1',
    type: TASK_TYPES.SYNC_OURA_RING_IRREGULAR,
  },
  {
    id: '2',
    what: "Please don't forget to sync and charge your Oura ring.",
    type: TASK_TYPES.SYNC_OURA_RING_REGULAR,
  },
  {
    id: '3',
    type: TASK_TYPES.PATIENT_EXIT_SURVEY,
  },
  {
    id: '4',
    type: TASK_TYPES.POST_VISIT_SURVEY,
  },
  {
    id: '5',
    what: 'Please start your survey now!',
    type: TASK_TYPES.PATIENT_EXIT_SURVEY,
  },
];

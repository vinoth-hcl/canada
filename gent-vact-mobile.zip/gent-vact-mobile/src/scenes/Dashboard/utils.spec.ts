import { getCurrentTestDay } from './utils';

describe('test getCurrentTestDay', () => {
  it('should return day 1 if same date', () => {
    const date = '2020-11-24T13:17:51.454337Z';
    expect(getCurrentTestDay(date, date)).toBe('day 1');
  });
  it('should return day 1 if diff date = 0', () => {
    expect(getCurrentTestDay('2020-11-24T13:17:51.454337Z', '2020-11-24T23:17:51.454337Z')).toBe(
      'day 1',
    );
    expect(getCurrentTestDay('2020-11-24T00:17:51.454337Z', '2020-11-24T22:17:51.454337Z')).toBe(
      'day 1',
    );
  });
  it('should return day 2 if diff date = 1', () => {
    expect(getCurrentTestDay('2020-11-24T13:17:51.454337Z', '2020-11-25T23:17:51.454337Z')).toBe(
      'day 2',
    );
  });
  it('should return "" if date not valid', () => {
    expect(getCurrentTestDay('2020-11-24T13:99:51.454337Z', '2020-11-25T23:17:51.454337Z')).toBe(
      '',
    );
    expect(getCurrentTestDay('2020-11-24T13:99:51.454337Z', '2020-11-25T44:17:51.454337Z')).toBe(
      '',
    );
  });
});

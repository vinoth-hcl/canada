import React, { FunctionComponent } from 'react';
import { SafeAreaView, StyleSheet, ScrollView, View } from 'react-native';
import { useSelector } from 'react-redux';

import { Header } from '../../components/Header/Header';
import { SAFE_AREA_COLOR } from '../../constants/constants';
import { getToDoItems } from '../../services/todo/selector';
import { isWebView } from '../../utilities/config';
import { WebLayoutTemplate } from '../../components/WebLayoutTemplate/WebLayoutTemplate';
import { Colors } from '../../utilities/design';
import { DashboardList } from './DashboardList';
import { getCurrentTestDay } from './utils';

interface IDashboardViewProps {
  userName: string;
  startDate: string;
}
export const DashboardView: FunctionComponent<IDashboardViewProps> = ({ userName, startDate }) => {
  const tasks = useSelector(getToDoItems);
  const currentTestDay = getCurrentTestDay(startDate);

  return isWebView() ? (
    <WebLayoutTemplate>
      <View style={styles.wrapper}>
        <ScrollView contentContainerStyle={styles.scroll}>
          <SafeAreaView style={styles.safeView}>
            <Header userName={userName} currentTestDay={currentTestDay} tasks={tasks} />
            <DashboardList />
          </SafeAreaView>
        </ScrollView>
      </View>
    </WebLayoutTemplate>
  ) : (
    <SafeAreaView style={styles.safeView}>
      <Header userName={userName} currentTestDay={currentTestDay} tasks={tasks} />
      <DashboardList />
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  safeView: {
    flex: 1,
    backgroundColor: SAFE_AREA_COLOR,
  },
  scroll: { alignSelf: 'center', width: 400, flexGrow: 1 },
});

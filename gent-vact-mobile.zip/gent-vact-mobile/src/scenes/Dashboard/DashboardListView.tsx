import React, { FunctionComponent, useMemo } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { Action } from 'redux';
import { ToDoDto } from '../../api/ToDoDto';
import { LoadAnimation } from '../../components/LoadAnimation/LoadAnimation';
import { Colors } from '../../utilities/design';
import { TEXT_DASHBOARD_EMPTY_TASKS } from '../../constants/constants';
import CheckIcon from '../../../assets/images/MockCheckbox.svg';
import { TPendingToDO } from '../../services/todo/reducer';
import { CARDS_SETTINGS } from './settings';
import { MockCard } from './cards/mock/MockCard';

export interface IDashboardListViewProps {
  tasks: ToDoDto[];
  isListPending: boolean;
  pendingTasks: TPendingToDO;
  onAction: (action: Action) => {};
}

export const DashboardListView: FunctionComponent<IDashboardListViewProps> = ({
  tasks,
  isListPending,
  pendingTasks,
  onAction,
}) => {
  const placeHolder = useMemo(
    () =>
      isListPending ? (
        <View style={styles.loadView}>
          <LoadAnimation
            style={{
              container: styles.animationContainer,
              circle: styles.animationCircles,
              text: styles.animationText,
            }}
          />
        </View>
      ) : (
        <MockCard text={TEXT_DASHBOARD_EMPTY_TASKS} Icon={CheckIcon} />
      ),
    [isListPending],
  );

  const cards = useMemo(() => {
    return tasks.map((task) => {
      const cardSettings = CARDS_SETTINGS[task.type];

      if (cardSettings) {
        const { defaultWhat, actions, Component } = cardSettings;

        return (
          <Component
            key={task.id}
            what={task.what || defaultWhat}
            actions={actions}
            onAction={onAction}
            data={task}
            isListPending={isListPending}
            isPending={task.id in pendingTasks}
            style={styles.card}
          />
        );
      }
    });
  }, [tasks, onAction, isListPending, pendingTasks]);

  return (
    <View style={styles.container}>
      {tasks.length ? <ScrollView>{cards}</ScrollView> : placeHolder}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingLeft: 10,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    backgroundColor: Colors.white,
  },
  card: {
    marginTop: 8,
    marginBottom: 8,
  },
  loadView: {
    flex: 1,
    position: 'relative',
  },
  animationContainer: {
    backgroundColor: Colors.white,
  },
  animationCircles: {
    backgroundColor: Colors.black,
  },
  animationText: {
    color: Colors.black,
  },
});

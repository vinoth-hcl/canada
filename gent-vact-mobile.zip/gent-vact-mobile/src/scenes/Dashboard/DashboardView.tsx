import React, { FunctionComponent } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';

import { Header } from '../../components/Header/Header';
import { SAFE_AREA_COLOR } from '../../constants/constants';
import { getToDoItems } from '../../services/todo/selector';
import { DashboardList } from './DashboardList';
import { getCurrentTestDay } from './utils';

interface IDashboardViewProps {
  userName: string;
  startDate: string | null;
}
export const DashboardView: FunctionComponent<IDashboardViewProps> = ({ userName, startDate }) => {
  const tasks = useSelector(getToDoItems);
  const currentTestDay = startDate ? getCurrentTestDay(startDate) : '';
  return (
    <SafeAreaView style={styles.safeView}>
      <Header userName={userName} currentTestDay={currentTestDay} tasks={tasks} />
      <DashboardList />
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  safeView: {
    flex: 1,
    backgroundColor: SAFE_AREA_COLOR,
  },
});

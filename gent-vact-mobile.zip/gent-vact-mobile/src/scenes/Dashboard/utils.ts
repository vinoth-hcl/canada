import dayjs from 'dayjs';
import timezone from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';

dayjs.extend(utc);
dayjs.extend(timezone);

export function getCurrentTestDay(date: string, todayDate?: string): string {
  const today = dayjs(todayDate).tz('UTC').startOf('day');
  const startDay = dayjs(date).tz('UTC').startOf('day');
  return startDay.isValid() && today.isValid() ? `day ${today.diff(startDay, 'day') + 1}` : '';
}

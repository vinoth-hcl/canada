import { FunctionComponent } from 'react';
import { Action } from 'redux';
import { StyleProp, ViewStyle } from 'react-native';
import { IDashboardCardAction } from '../../components/DashboardCard/types';

export interface IDashboardCardProps {
  what?: string;
  actions: IDashboardCardAction[];
  data: any;
  style?: StyleProp<ViewStyle>;
  isPending: boolean;
  isListPending: boolean;
  onAction: (action: Action) => void;
}

export enum TASK_TYPES {
  ACTIVITY = 'ACTIVITY',
  MEDICATION = 'MEDICATION',
  SURVEY = 'SURVEY',
  TRIAL = 'TRIAL',
  STANDARD_CARE = 'STANDARD_CARE',
  APPOINTMENT = 'APPOINTMENT',
  NONE = 'NONE',
  SYNC_OURA_RING_REGULAR = 'SYNC_OURA_RING_REGULAR',
  SYNC_OURA_RING_IRREGULAR = 'SYNC_OURA_RING_IRREGULAR',
  PATIENT_EXIT_SURVEY = 'PATIENT_EXIT_SURVEY',
  POST_VISIT_SURVEY = 'POST_VISIT_SURVEY',
  PATIENT_WITHDRAW_SURVEY = 'PATIENT_WITHDRAW_SURVEY',
  WITHDRAWAL = 'WITHDRAWAL',
}

export interface IDashboardCardSetting {
  defaultWhat: string;
  actions: IDashboardCardAction[];
  // We are using Component property for possible customisation the specific task in the future. If they will be stay the same,
  // we'll transfer Icon and other specific props to the settings and use SimpleDashboardCard or BigDashboardCard
  // for view instead of separate component for each task
  Component: FunctionComponent<IDashboardCardProps>;
}

export interface IDashboardCardSettings {
  [key: string]: IDashboardCardSetting;
}

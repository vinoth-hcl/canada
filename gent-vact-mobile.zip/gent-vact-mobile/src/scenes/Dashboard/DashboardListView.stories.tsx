import React from 'react';
import { StyleSheet, View } from 'react-native';
import { storiesOf } from '@storybook/react-native';
import { withKnobs } from '@storybook/addon-knobs';
import { action } from '@storybook/addon-actions';

import centered from '../../../storybook/decorators/centered';
import { Colors } from '../../utilities/design';
import { DashboardListView } from './DashboardListView';
import { DASHBOARD_MOCK_DATA } from './mockData';

storiesOf('Dashboard list', module)
  .addDecorator(centered)
  .addDecorator(withKnobs)
  .add('dashboard', () => (
    <View style={styles.container}>
      <DashboardListView tasks={DASHBOARD_MOCK_DATA} onAction={action('onPress')} />
    </View>
  ));

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    width: '100%',
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

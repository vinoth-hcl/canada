export const CARDS_ACTION_TEXTS = {
  APPOINTMENT: {
    CHOOSE_DATE: 'Choose day/time',
    SET_REMINDER: 'Set reminder',
  },
  SURVEY: {
    TODAY: 'Yes, fill survey now',
    FILL_NOW: 'Fill survey now',
    START_EXIT: 'Start exit process',
  },
  OURA: {
    OPEN_APP: 'Open Oura App to start sync',
    SHOW_HOW_SYNC: 'Show me how to sync',
    SHOW_HOW_CHARGE: 'Show me how to charge',
    OPEN_APP_TO_SYNC_NOW: 'Open Oura app to sync now',
    DISMISS_MSG: 'A dismiss message here?',
  },
  WITHDRAWAL: {
    LINK_LABEL: 'Cancel your request',
  },
};

export const CARDS_DEFAULT_DESCRIPTIONS = {
  APPOINTMENT: {
    CHOOSE_DATE: 'Doctor has suggested possible dates for your next appointment.',
    SET_REMINDER: 'You have an appointment with doctor.',
  },
  SURVEY: {
    TODAY: "Ready to fill the survey of today's appointment",
    YESTERDAY: "Don't forget to fill the survey of yesterday's appointment",
    WEEK: "Don't forget to fill the survey of this week's appointment",
    OVERDUE: "Last week's appointment survey is overdue",
    COMPLETE_EXIT: "Thank you for completing the trial! There's only one last step to go",
    WITHDRAWING_EXIT:
      "We're sorry that you are withdrawing from the study. Please click on the ling below to start the exit process.",
  },
  OURA: {
    DAILY: 'Do your daily sync & charge of the Oura ring.',
    LAST_5_DAYS: "You haven't synced your Oura ring in the last 5 days.",
    LOW_BATTERY: "Your Oura ring's battery is low. Please charge it",
  },
  WITHDRAWAL: {
    DEFAULT_MESSAGE:
      "We're sorry that you are withdrawing from the trial. A member of the trial team will contact you soon to confirm your withdrawal.",
  },
};

import { appRoute, replaceRoute, startOuraRing } from '../../app/actions';
import { MODAL_ROUTES } from '../../navigation/routes';
import { ModalType } from '../Modal/ModalContent';
import {
  SUCCESS_COMPLETED_TRIAL_MESSAGE,
  SUCCESS_COMPLETED_TRIAL_TITLE,
  TRIAL_COMPLETED_BUTTON,
} from '../../constants/constants';
import { INSTRUCTION } from '../Instruction/types';
import { IDashboardCardSettings, TASK_TYPES } from './types';
import { YellowOuraWarningCard } from './cards/oura/YellowOuraWarningCard';
import { MediumOuraCard } from './cards/oura/MediumOuraCard';
import { CompleteExitSurveyCard } from './cards/exitSurvey/CompleteExitCard';
import { SurveyCardByWhen } from './cards/survey/SurveyCardByWhen';
import { CARDS_ACTION_TEXTS, CARDS_DEFAULT_DESCRIPTIONS } from './constants';
import { GreenWithdrawalCard } from './cards/withdrawal/GreenWithdrawalCard';

export const CARDS_SETTINGS: IDashboardCardSettings = {
  [TASK_TYPES.SYNC_OURA_RING_IRREGULAR]: {
    defaultWhat: CARDS_DEFAULT_DESCRIPTIONS.OURA.LAST_5_DAYS,
    actions: [
      {
        text: CARDS_ACTION_TEXTS.OURA.OPEN_APP_TO_SYNC_NOW,
        onPress: (task) => startOuraRing(task.id),
        disable: (task, isItemPending, isListPending) => Boolean(isItemPending),
      },
    ],
    Component: YellowOuraWarningCard,
  },
  [TASK_TYPES.SYNC_OURA_RING_REGULAR]: {
    defaultWhat: CARDS_DEFAULT_DESCRIPTIONS.OURA.DAILY,
    actions: [
      {
        text: CARDS_ACTION_TEXTS.OURA.OPEN_APP,
        onPress: (task) => startOuraRing(task.id),
        disable: (task, isItemPending, isListPending) => Boolean(isItemPending),
      },
      {
        text: CARDS_ACTION_TEXTS.OURA.SHOW_HOW_SYNC,
        onPress: (task) => appRoute(MODAL_ROUTES.INSTRUCTION, { type: INSTRUCTION.SYNC }),
      },
      {
        text: CARDS_ACTION_TEXTS.OURA.SHOW_HOW_CHARGE,
        onPress: (task) => appRoute(MODAL_ROUTES.INSTRUCTION, { type: INSTRUCTION.CHARGE }),
      },
    ],
    Component: MediumOuraCard,
  },
  [TASK_TYPES.PATIENT_EXIT_SURVEY]: {
    defaultWhat: CARDS_DEFAULT_DESCRIPTIONS.SURVEY.COMPLETE_EXIT,
    actions: [
      {
        text: CARDS_ACTION_TEXTS.SURVEY.START_EXIT,
        onPress: (task) => {
          return appRoute(MODAL_ROUTES.MODAL_MESSAGE, {
            type: ModalType.CUSTOM_DETAILS,
            title: SUCCESS_COMPLETED_TRIAL_TITLE,
            message: SUCCESS_COMPLETED_TRIAL_MESSAGE,
            buttonText1: TRIAL_COMPLETED_BUTTON,
            onButton1: replaceRoute(MODAL_ROUTES.EXIT_INSTRUCTIONS),
            onCloseAction: replaceRoute(MODAL_ROUTES.EXIT_INSTRUCTIONS),
          });
        },
      },
    ],
    Component: CompleteExitSurveyCard,
  },
  [TASK_TYPES.POST_VISIT_SURVEY]: {
    defaultWhat: CARDS_DEFAULT_DESCRIPTIONS.SURVEY.COMPLETE_EXIT,
    actions: [
      {
        text: CARDS_ACTION_TEXTS.SURVEY.FILL_NOW,
        onPress: (task) => {
          const { id: taskId, trialId, type } = task;

          return appRoute(MODAL_ROUTES.SURVEY, { trialId, type, taskId });
        },
      },
    ],
    Component: SurveyCardByWhen,
  },
  [TASK_TYPES.WITHDRAWAL]: {
    defaultWhat: CARDS_DEFAULT_DESCRIPTIONS.WITHDRAWAL.DEFAULT_MESSAGE,
    actions: [],
    Component: GreenWithdrawalCard,
  },
  [TASK_TYPES.PATIENT_WITHDRAW_SURVEY]: {
    defaultWhat: CARDS_DEFAULT_DESCRIPTIONS.SURVEY.WITHDRAWING_EXIT,
    actions: [
      {
        text: CARDS_ACTION_TEXTS.SURVEY.START_EXIT,
        onPress: (task) => {
          return appRoute(MODAL_ROUTES.MODAL_MESSAGE, {
            type: ModalType.CUSTOM_DETAILS,
            title: SUCCESS_COMPLETED_TRIAL_TITLE,
            message: SUCCESS_COMPLETED_TRIAL_MESSAGE,
            buttonText1: TRIAL_COMPLETED_BUTTON,
            onButton1: replaceRoute(MODAL_ROUTES.EXIT_INSTRUCTIONS),
            onCloseAction: replaceRoute(MODAL_ROUTES.EXIT_INSTRUCTIONS),
          });
        },
      },
    ],
    Component: CompleteExitSurveyCard,
  },
};

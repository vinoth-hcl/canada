import React, { FunctionComponent } from 'react';
import { useSelector } from 'react-redux';
import { get } from 'lodash';

import { getProfile } from '../../services/patient/selector';
import { DashboardView } from './DashboardView';

export const Dashboard: FunctionComponent<{}> = () => {
  const profile = useSelector(getProfile);
  const username = get(profile, 'username', '');
  const startDate = get(profile, 'firstDataDate', '');

  return <DashboardView userName={username} startDate={startDate} />;
};

import { FunctionComponent } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getPendingToDoItems, getToDoItems, isToDoListPending } from '../../services/todo/selector';
import { DashboardListView } from './DashboardListView';

export const DashboardList: FunctionComponent = () => {
  const dispatch = useDispatch();
  const tasks = useSelector(getToDoItems);
  const isListPending = useSelector(isToDoListPending);
  const pendingTasks = useSelector(getPendingToDoItems);

  return DashboardListView({ tasks, isListPending, pendingTasks, onAction: dispatch });
};

import React, { FunctionComponent } from 'react';
import { IDashboardCardProps } from '../../types';
import CheckIcon from '../../../../../assets/images/Dashboard/CheckInCircle.svg';
import { SimpleDashboardCard } from '../../../../components/DashboardCard/SimpleDashboardCard/SimpleDashboardCard';
import { Colors } from '../../../../utilities/design';

export const CompleteExitSurveyCard: FunctionComponent<IDashboardCardProps> = ({
  what,
  actions,
  ...props
}) => (
  <SimpleDashboardCard
    Icon={CheckIcon}
    title={what}
    actions={actions}
    backgroundColor={Colors.greenLightest}
    {...props}
  />
);

import React from 'react';
import { StyleSheet, View } from 'react-native';
import { SvgProps } from 'react-native-svg';
import { Colors } from '../../../../utilities/design';
import { GText } from '../../../../components/GText/GText';
import { TextStyles } from '../../../../components/GText/styles';

export const MockCard = ({ text, Icon }: { text: string; Icon: SvgProps }) => (
  <View style={styles.container}>
    <View style={styles.inner}>
      <View style={styles.icon}>
        <Icon />
      </View>
      <GText style={styles.text} textStyle={TextStyles.SOURCE_SANS_16_20_NORMAL}>
        {text}
      </GText>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  inner: {
    height: 180,
    backgroundColor: Colors.greenLightest,
    paddingTop: 32,
    paddingRight: 40,
    paddingBottom: 40,
    paddingLeft: 40,
    borderRadius: 24,
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 12,
    shadowOpacity: 1,
    elevation: 5,
  },
  text: {
    textAlign: 'center',
    color: Colors.greyDark,
  },
  icon: {
    alignItems: 'center',
    marginBottom: 24,
  },
});

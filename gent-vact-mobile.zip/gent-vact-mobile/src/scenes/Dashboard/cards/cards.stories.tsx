import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { storiesOf } from '@storybook/react-native';
import { withKnobs } from '@storybook/addon-knobs';
import { action } from '@storybook/addon-actions';

import centered from '../../../../storybook/decorators/centered';
import { Colors } from '../../../utilities/design';
import { CARDS_ACTION_TEXTS, CARDS_DEFAULT_DESCRIPTIONS } from '../constants';
import { Separator } from '../../../components/Separator/Separator';
import { MediumOuraCard } from './oura/MediumOuraCard';
import { SmallOuraCard } from './oura/SmallOuraCard';
import { YellowOuraWarningCard } from './oura/YellowOuraWarningCard';
import { RedOuraWarningCard } from './oura/RedOuraWarningCard';
import { SmallCalendarAppointmentCard } from './appointment/SmallCalendarAppointmentCard';
import { SmallReminderAppointmentCard } from './appointment/SmallReminderAppointmentCard';
import { GreenSurveyCard } from './survey/GreenSurveyCard';
import { YellowSurveyWarningCard } from './survey/YellowSurveyWarningCard';
import { RedSurveyWarningCard } from './survey/RedSurveyWarningCard';
import { CompleteExitSurveyCard } from './exitSurvey/CompleteExitCard';
import { WithdrawingExitSurveyCard } from './exitSurvey/WithdrawingExitCard';

storiesOf('Simple dashboard card', module)
  .addDecorator(centered)
  .addDecorator(withKnobs)
  .add('all cards without Big cards', () => (
    <View style={styles.container}>
      <ScrollView>
        <Text style={styles.header}>Oura</Text>
        <MediumOuraCard
          what={CARDS_DEFAULT_DESCRIPTIONS.OURA.DAILY}
          actions={[
            { text: CARDS_ACTION_TEXTS.OURA.OPEN_APP, onPress: action('onPress') },
            { text: CARDS_ACTION_TEXTS.OURA.SHOW_HOW_SYNC, onPress: action('onPress') },
            { text: CARDS_ACTION_TEXTS.OURA.SHOW_HOW_CHARGE, onPress: action('onPress') },
          ]}
        />
        <Separator style={styles.separator} />

        <SmallOuraCard
          actions={[{ text: CARDS_ACTION_TEXTS.OURA.OPEN_APP, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />

        <YellowOuraWarningCard
          what={CARDS_DEFAULT_DESCRIPTIONS.OURA.LAST_5_DAYS}
          actions={[{ text: CARDS_ACTION_TEXTS.OURA.OPEN_APP, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />

        <RedOuraWarningCard
          what={CARDS_DEFAULT_DESCRIPTIONS.OURA.LOW_BATTERY}
          actions={[{ text: CARDS_ACTION_TEXTS.OURA.DISMISS_MSG, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />

        <Text style={styles.header}>Appointments</Text>
        <SmallCalendarAppointmentCard
          what={CARDS_DEFAULT_DESCRIPTIONS.APPOINTMENT.CHOOSE_DATE}
          actions={[
            { text: CARDS_ACTION_TEXTS.APPOINTMENT.CHOOSE_DATE, onPress: action('onPress') },
          ]}
        />
        <Separator style={styles.separator} />

        <SmallReminderAppointmentCard
          what={CARDS_DEFAULT_DESCRIPTIONS.APPOINTMENT.SET_REMINDER}
          actions={[
            { text: CARDS_ACTION_TEXTS.APPOINTMENT.SET_REMINDER, onPress: action('onPress') },
          ]}
        />
        <Separator style={styles.separator} />

        <Text style={styles.header}>Surveys</Text>
        <GreenSurveyCard
          what={CARDS_DEFAULT_DESCRIPTIONS.SURVEY.TODAY}
          actions={[{ text: CARDS_ACTION_TEXTS.SURVEY.TODAY, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />

        <YellowSurveyWarningCard
          what={CARDS_DEFAULT_DESCRIPTIONS.SURVEY.YESTERDAY}
          actions={[{ text: CARDS_ACTION_TEXTS.SURVEY.FILL_NOW, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />

        <YellowSurveyWarningCard
          what={CARDS_DEFAULT_DESCRIPTIONS.SURVEY.WEEK}
          actions={[{ text: CARDS_ACTION_TEXTS.SURVEY.FILL_NOW, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />

        <RedSurveyWarningCard
          what={CARDS_DEFAULT_DESCRIPTIONS.SURVEY.OVERDUE}
          actions={[{ text: CARDS_ACTION_TEXTS.SURVEY.FILL_NOW, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />

        <Text style={styles.header}>Exit Surveys</Text>
        <CompleteExitSurveyCard
          what={CARDS_DEFAULT_DESCRIPTIONS.SURVEY.COMPLETE_EXIT}
          actions={[{ text: CARDS_ACTION_TEXTS.SURVEY.START_EXIT, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />

        <WithdrawingExitSurveyCard
          what={CARDS_DEFAULT_DESCRIPTIONS.SURVEY.WITHDRAWING_EXIT}
          actions={[{ text: CARDS_ACTION_TEXTS.SURVEY.START_EXIT, onPress: action('onPress') }]}
        />
        <Separator style={styles.separator} />
      </ScrollView>
    </View>
  ));

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    width: '100%',
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  separator: {
    borderBottomWidth: 0,
    marginTop: 10,
    marginBottom: 10,
  },
  header: {
    fontSize: 35,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});

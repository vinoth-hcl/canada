import React, { FunctionComponent } from 'react';
import { IDashboardCardProps } from '../../types';
import GreyWarning from '../../../../../assets/images/Dashboard/GreyWarning.svg';
import { SimpleDashboardCard } from '../../../../components/DashboardCard/SimpleDashboardCard/SimpleDashboardCard';
import { Colors } from '../../../../utilities/design';

export const RedSurveyWarningCard: FunctionComponent<IDashboardCardProps> = ({
  what,
  actions,
  ...props
}) => (
  <SimpleDashboardCard
    Icon={GreyWarning}
    title={what}
    actions={actions}
    backgroundColor={Colors.secondaryLightest}
    {...props}
  />
);

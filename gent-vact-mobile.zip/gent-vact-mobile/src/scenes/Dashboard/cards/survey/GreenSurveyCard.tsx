import React, { FunctionComponent } from 'react';
import { IDashboardCardProps } from '../../types';
import GreyNotesIcon from '../../../../../assets/images/Dashboard/GreyNotes.svg';
import { SimpleDashboardCard } from '../../../../components/DashboardCard/SimpleDashboardCard/SimpleDashboardCard';
import { Colors } from '../../../../utilities/design';

export const GreenSurveyCard: FunctionComponent<IDashboardCardProps> = ({
  what,
  actions,
  ...props
}) => (
  <SimpleDashboardCard
    Icon={GreyNotesIcon}
    title={what}
    actions={actions}
    backgroundColor={Colors.greenLightest}
    {...props}
  />
);

import React, { FunctionComponent } from 'react';
import { get } from 'lodash';
import dayjs from 'dayjs';
import { useSelector } from 'react-redux';
import { getPatientTimezone } from '../../../../app/selectors';
import { IDashboardCardProps } from '../../types';
import { getFeatureFlag } from '../../../../utilities/config';
import { GreenSurveyCard } from './GreenSurveyCard';
import { YellowSurveyWarningCard } from './YellowSurveyWarningCard';
import { RedSurveyWarningCard } from './RedSurveyWarningCard';

const showDashboardGreenCard = getFeatureFlag('showGreenDashboardCard');
const showYellowDashboardCard = getFeatureFlag('showYellowDashboardCard');
const showRedDashboardCard = getFeatureFlag('showRedDashboardCard');

export const SurveyCardByWhen: FunctionComponent<IDashboardCardProps> = (props) => {
  const patientTimeZonePreferences = useSelector(getPatientTimezone);
  const when = get(props, ['data', 'when']);
  const current = dayjs().tz(patientTimeZonePreferences.iana);
  const whenToday = dayjs(when).tz(patientTimeZonePreferences.iana).endOf('day');
  const whenTomorrow = dayjs(whenToday).tz(patientTimeZonePreferences.iana).add(1, 'day');
  const whenPlus1Week = dayjs(whenToday)
    .tz(patientTimeZonePreferences.iana)
    .subtract(1, 'day')
    .add(1, 'week');

  if (showDashboardGreenCard) {
    return <GreenSurveyCard {...props} />;
  } else if (showYellowDashboardCard) {
    return <YellowSurveyWarningCard {...props} />;
  } else if (showRedDashboardCard) {
    return <RedSurveyWarningCard {...props} />;
  }

  if (current < whenToday) {
    return <GreenSurveyCard {...props} />;
  }

  if (current < whenTomorrow) {
    return <YellowSurveyWarningCard {...props} />;
  }

  if (current < whenPlus1Week) {
    return <YellowSurveyWarningCard {...props} />;
  }

  return <RedSurveyWarningCard {...props} />;
};

import React, { FunctionComponent } from 'react';
import { IDashboardCardProps } from '../../types';
import CalendarIcon from '../../../../../assets/images/CalendarBlack.svg';
import { SimpleDashboardCard } from '../../../../components/DashboardCard/SimpleDashboardCard/SimpleDashboardCard';
import { Colors } from '../../../../utilities/design';

export const SmallCalendarAppointmentCard: FunctionComponent<IDashboardCardProps> = ({
  what,
  actions,
  ...props
}) => (
  <SimpleDashboardCard
    Icon={CalendarIcon}
    title={what}
    actions={actions}
    backgroundColor={Colors.primaryAltLightestAlt}
    {...props}
  />
);

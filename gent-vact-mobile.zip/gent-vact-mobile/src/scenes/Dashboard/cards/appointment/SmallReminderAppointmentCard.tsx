import React, { FunctionComponent } from 'react';
import { IDashboardCardProps } from '../../types';
import StethoscopeIcon from '../../../../../assets/images/Appointment.svg';
import { SimpleDashboardCard } from '../../../../components/DashboardCard/SimpleDashboardCard/SimpleDashboardCard';
import { Colors } from '../../../../utilities/design';

export const SmallReminderAppointmentCard: FunctionComponent<IDashboardCardProps> = ({
  what,
  actions,
  ...props
}) => (
  <SimpleDashboardCard
    Icon={StethoscopeIcon}
    title={what}
    actions={actions}
    backgroundColor={Colors.primaryAltLightestAlt}
    {...props}
  />
);

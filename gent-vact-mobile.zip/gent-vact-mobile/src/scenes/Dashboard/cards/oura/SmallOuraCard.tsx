import React, { FunctionComponent } from 'react';
import { IDashboardCardProps } from '../../types';
import GreyOuraRingIcon from '../../../../../assets/images/Dashboard/GreyOuraRing.svg';
import { SimpleDashboardCard } from '../../../../components/DashboardCard/SimpleDashboardCard/SimpleDashboardCard';

export const SmallOuraCard: FunctionComponent<IDashboardCardProps> = ({ actions, ...props }) => (
  <SimpleDashboardCard Icon={GreyOuraRingIcon} actions={actions} {...props} />
);

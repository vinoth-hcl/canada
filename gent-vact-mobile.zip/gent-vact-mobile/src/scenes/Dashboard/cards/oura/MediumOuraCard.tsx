import React, { FunctionComponent } from 'react';
import { IDashboardCardProps } from '../../types';
import GreyOuraRingIcon from '../../../../../assets/images/Dashboard/GreyOuraRing.svg';
import { SimpleDashboardCard } from '../../../../components/DashboardCard/SimpleDashboardCard/SimpleDashboardCard';

export const MediumOuraCard: FunctionComponent<IDashboardCardProps> = ({
  what,
  actions,
  ...props
}) => <SimpleDashboardCard Icon={GreyOuraRingIcon} actions={actions} title={what} {...props} />;

import React, { FunctionComponent } from 'react';
import { IDashboardCardProps } from '../../types';
import Withdraw from '../../../../../assets/images/Dashboard/Withdraw.svg';
import { SimpleDashboardCard } from '../../../../components/DashboardCard/SimpleDashboardCard/SimpleDashboardCard';
import { Colors } from '../../../../utilities/design';

export const GreenWithdrawalCard: FunctionComponent<IDashboardCardProps> = ({
  what,
  actions,
  ...props
}) => (
  <SimpleDashboardCard
    Icon={Withdraw}
    title={what}
    actions={actions}
    backgroundColor={Colors.greenLightest}
    {...props}
  />
);

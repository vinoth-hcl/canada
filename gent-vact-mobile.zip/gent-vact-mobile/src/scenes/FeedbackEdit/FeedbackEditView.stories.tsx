import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import centered from '../../../storybook/decorators/centered';
import { TEXT_SUBMIT_BUTTON } from '../../constants/constants';
import { ButtonKind } from '../../components/Button/types';
import { FeedbackMockDto } from '../../services/feedback/mock/FeedbackMockDto';
import { Grade } from '../Feedback/types';
import { FeedbackEditView } from './FeedbackEditView';

const question: FeedbackMockDto = {
  Id: '1',
  question: 'Do you like the application?',
  answer: Grade.HAPPY,
};

storiesOf('FeedbackEdit', module)
  .addDecorator(centered)
  .add('view', () => (
    <FeedbackEditView
      question={question}
      currentQuestion={question}
      handleEdit={action('edit')}
      handleChangeInput={action('input')}
      handleButton={action('button')}
      changeText={'comment'}
      textButton={TEXT_SUBMIT_BUTTON}
      buttonKind={ButtonKind.BLUE}
    />
  ));

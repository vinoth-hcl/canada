import { FunctionComponent, useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { isUndefined } from 'lodash';
import { TEXT_SKIP_BUTTON, TEXT_SUBMIT_BUTTON } from '../../constants/constants';
import { getButtonKind } from '../Feedback/utils';
import { useSelectorFactory } from '../../utilities/hooks';
import { getQuestionBy } from '../../services/feedback/selector';
import { FeedbackMockDto } from '../../services/feedback/mock/FeedbackMockDto';
import { addAnswerFeedbackById, checkAnswerFeedback } from '../../services/feedback/actions';
import { appRoute } from '../../app/actions';
import { MODAL_ROUTES } from '../../navigation/routes';
import { IEditProps } from './types';
import { FeedbackEditView } from './FeedbackEditView';

export const FeedbackEdit: FunctionComponent<IEditProps> = ({ route }) => {
  const dispatch = useDispatch();

  const Id = route.params?.Id ?? '';
  const question = useSelectorFactory(getQuestionBy, Id);

  const [changeText, setChangeText] = useState<string>('');
  const [currentQuestion, setCurrentQuestion] = useState<FeedbackMockDto>({ ...question });

  const hasAnswer =
    !isUndefined(currentQuestion.answer) && currentQuestion.answer !== question.answer;
  const hasStyleButton = !!changeText || hasAnswer;
  const buttonKind = getButtonKind(hasStyleButton);
  const textButton = hasStyleButton ? TEXT_SUBMIT_BUTTON : TEXT_SKIP_BUTTON;

  const hasValidation = (text: any) => typeof text === 'string';

  const handleChangeInput = useCallback((text) => {
    if (hasValidation(text)) {
      setChangeText(text);
    }
  }, []);

  const handleEdit = useCallback((answer: FeedbackMockDto) => {
    setCurrentQuestion(answer);
  }, []);

  const handleButton = useCallback(() => {
    dispatch(addAnswerFeedbackById({ ...currentQuestion, comment: changeText }));
    dispatch(checkAnswerFeedback(appRoute(MODAL_ROUTES.HOME)));
  }, [changeText, currentQuestion, dispatch]);

  useEffect(() => {
    setChangeText('');
    setCurrentQuestion({ ...question });
  }, [question, Id]);

  return FeedbackEditView({
    question,
    currentQuestion,
    handleEdit,
    changeText,
    handleChangeInput,
    handleButton,
    textButton,
    buttonKind,
  });
};

import { RouteProp } from '@react-navigation/native';
import { ModalStackParamList } from '../../navigation/types';
import { MODAL_ROUTES } from '../../navigation/routes';

type ModalScreenNavigationProp = RouteProp<ModalStackParamList, MODAL_ROUTES.FEEDBACK_EDIT>;

export interface IEditProps {
  route: ModalScreenNavigationProp;
}

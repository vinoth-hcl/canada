import { StyleSheet, Text, TextInput, View } from 'react-native';
import React, { FunctionComponent } from 'react';
import { Colors } from '../../utilities/design';
import { TEXT_FEEDBACK_EDIT_HEADER, TEXT_FEEDBACK_EDIT_INPUT } from '../../constants/constants';
import { ButtonGrade } from '../../components/Question/ButtonGrade';
import { Button } from '../../components/Button/Button';
import { FeedbackMockDto } from '../../services/feedback/mock/FeedbackMockDto';
import { ButtonKind } from '../../components/Button/types';

export interface FeedbackEditViewProps {
  question: FeedbackMockDto;
  currentQuestion: FeedbackMockDto;
  handleEdit: (answer: FeedbackMockDto) => void;
  changeText: string;
  handleChangeInput: (text: string) => void;
  handleButton: () => void;
  textButton: string;
  buttonKind: ButtonKind;
}

export const FeedbackEditView: FunctionComponent<FeedbackEditViewProps> = ({
  question,
  currentQuestion,
  handleEdit,
  changeText,
  handleChangeInput,
  handleButton,
  textButton,
  buttonKind,
}) => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>{TEXT_FEEDBACK_EDIT_HEADER}</Text>
      <Text style={styles.question}>{question.question}</Text>
      <ButtonGrade quiz={currentQuestion} onEdit={handleEdit} />
      <TextInput
        autoFocus
        placeholder={TEXT_FEEDBACK_EDIT_INPUT}
        placeholderTextColor={Colors.grey}
        autoCapitalize={'none'}
        style={styles.input}
        value={changeText}
        onChangeText={handleChangeInput}
        maxLength={250}
      />
      <Button
        onPress={handleButton}
        text={textButton}
        kind={buttonKind}
        style={{
          container: styles.button,
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 56,
    paddingBottom: 44,
    paddingLeft: 54,
    paddingRight: 54,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: Colors.lightGrey,
  },
  header: {
    width: 260,
    fontWeight: '500',
    fontSize: 24,
    lineHeight: 42,
    textAlign: 'left',
    color: Colors.grey,
  },
  question: {
    width: 260,
    marginTop: 10,
    marginBottom: 10,
    fontWeight: 'normal',
    fontSize: 17,
    lineHeight: 30,
    textAlign: 'left',
    color: Colors.middleBlack,
  },
  input: {
    height: 180,
    width: '100%',
    marginTop: 10,
    marginBottom: 10,
    paddingTop: 10,
    paddingBottom: 10,
    paddingLeft: 10,
    paddingRight: 10,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: Colors.warmGrey,
    fontSize: 14,
    lineHeight: 16,
    backgroundColor: Colors.white,
    color: Colors.middleBlack,
    textAlignVertical: 'top',
  },
  button: {
    width: 269,
  },
});

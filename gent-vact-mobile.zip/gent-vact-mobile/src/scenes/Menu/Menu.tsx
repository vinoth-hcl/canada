import React, { FunctionComponent, useCallback } from 'react';
import { useDispatch } from 'react-redux';

import { appRoute, backRouteAction } from '../../app/actions';
import { MENU_ITEMS } from '../../constants/constants';
import { IMenuProps } from './types';
import { MenuView } from './MenuView';

export const Menu: FunctionComponent<IMenuProps> = ({ route }) => {
  const dispatch = useDispatch();
  const currentRoute = route.params?.currentRoute ?? '';

  const handleCancelButton = useCallback(() => {
    dispatch(backRouteAction());
  }, [dispatch]);

  const handleAppRoute = useCallback(
    (item: string) => {
      if (currentRoute !== item) {
        dispatch(appRoute(item));
      } else {
        handleCancelButton();
      }
    },
    [handleCancelButton, currentRoute, dispatch],
  );

  return (
    <MenuView
      items={MENU_ITEMS}
      currentRoute={currentRoute}
      onCancel={handleCancelButton}
      onPressRoute={handleAppRoute}
    />
  );
};

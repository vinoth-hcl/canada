import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet } from 'react-native';

import { Button } from '../../components/Button/Button';
import { ButtonKind } from '../../components/Button/types';
import { Colors } from '../../utilities/design';
import { IMenuItemProps } from './types';

export const MenuItem: FunctionComponent<IMenuItemProps> = ({
  active,
  onPressRoute,
  item: { route, title },
}) => {
  const handlePress = useCallback(() => {
    onPressRoute(route);
  }, [onPressRoute, route]);
  const color = active ? Colors.grey : Colors.black;

  return (
    <Button
      onPress={handlePress}
      text={title}
      kind={ButtonKind.TRANSPARENT_BLACK}
      style={{ textStyle: { color }, container: styles.container }}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'flex-start',
  },
});

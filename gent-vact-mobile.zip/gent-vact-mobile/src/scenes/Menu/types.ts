export interface IMenuProps {
  route: any;
}

export interface IMenuViewProps {
  items: IMenuItem[];
  currentRoute: string;
  onCancel: () => void;
  onPressRoute: (route: string) => void;
}

export interface IMenuItemProps {
  active: boolean;
  item: IMenuItem;
  onPressRoute: (route: string) => void;
}

export interface IMenuItem {
  route: string;
  title: string;
}

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import { StyleSheet, View } from 'react-native';
import { text } from '@storybook/addon-knobs';
import centered from '../../../storybook/decorators/centered';
import { TAB_ROUTES } from '../../navigation/routes';
import { MENU_ITEMS } from '../../constants/constants';
import { MenuView } from './MenuView';
import { MenuItem } from './MenuItem';

storiesOf('Menu', module)
  .addDecorator(centered)
  .add('View', () => (
    <View style={styles.container}>
      <MenuView
        items={MENU_ITEMS}
        onCancel={action('close')}
        onPressRoute={action('appRoute')}
        currentRoute={text('text', TAB_ROUTES.DASHBOARD)}
      />
    </View>
  ))
  .add('Item: active', () => (
    <MenuItem item={MENU_ITEMS[0]} onPressRoute={action('appRoute')} active={true} />
  ))
  .add('Item: not active', () => (
    <MenuItem item={MENU_ITEMS[0]} onPressRoute={action('appRoute')} active={false} />
  ));

const styles = StyleSheet.create({
  container: {
    width: '100%',
    flex: 1,
  },
});

import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { map } from 'lodash';

import { Button } from '../../components/Button/Button';
import { Colors } from '../../utilities/design';
import { TEXT_CLOSE_BUTTON } from '../../constants/constants';
import { ButtonKind } from '../../components/Button/types';
import Close from '../../../assets/images/Close.svg';
import { IMenuViewProps } from './types';
import { MenuItem } from './MenuItem';

export const MenuView: FunctionComponent<IMenuViewProps> = ({
  items,
  currentRoute,
  onCancel,
  onPressRoute,
}) => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Button
          onPress={onCancel}
          text={TEXT_CLOSE_BUTTON}
          kind={ButtonKind.BLACK}
          Icon={Close}
          style={{
            container: styles.button,
            iconStyle: styles.iconStyle,
          }}
        />
      </View>
      <View style={styles.listRoutes}>
        {map(items, (item, index) => {
          return (
            <MenuItem
              onPressRoute={onPressRoute}
              item={item}
              key={index}
              active={currentRoute === item.route}
            />
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.lightGrey,
  },
  header: {
    width: '90%',
    flexDirection: 'row',
    marginTop: 10,
    marginBottom: 10,
    justifyContent: 'flex-end',
  },
  button: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    paddingRight: 10,
  },
  listRoutes: {
    flex: 1,
    width: '90%',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  iconStyle: {
    marginRight: 5,
  },
});

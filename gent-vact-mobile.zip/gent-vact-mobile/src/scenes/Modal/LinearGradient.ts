import LinearGradient from 'react-native-linear-gradient';

export default LinearGradient;

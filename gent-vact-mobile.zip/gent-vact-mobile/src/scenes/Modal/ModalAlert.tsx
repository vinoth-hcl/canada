import React, { FunctionComponent } from 'react';
import { Text, View } from 'react-native';
import Icon from '../../../assets/images/ModalWarning.svg';
import { Button } from '../../components/Button/Button';
import { ButtonKind } from '../../components/Button/types';
import { TEXT_OK } from '../../constants/constants';
import { testId } from '../../utilities/TestId';
import { useAccessibleFocus } from '../../hooks/useAccessibleFocus';
import { blueButton, viewStyles } from './styles';

interface IModalAlertProps {
  message?: string;
  onCancel?: () => void;
}

export const ModalAlert: FunctionComponent<IModalAlertProps> = ({
  message = '',
  onCancel = () => {},
}) => {
  const modalRef = useAccessibleFocus();

  return (
    <View style={viewStyles.container}>
      <View style={viewStyles.root} accessible={true} ref={modalRef}>
        <View importantForAccessibility={'no-hide-descendants'}>
          <Icon {...testId('AlertIcon')} />
        </View>
        <Text style={viewStyles.text} {...testId('AlertText')}>
          {message}
        </Text>
        <Button
          onPress={onCancel}
          kind={ButtonKind.CIRCLE_WHITE}
          isShadow
          style={blueButton}
          text={TEXT_OK}
          testID={'AlertButton'}
        />
      </View>
    </View>
  );
};

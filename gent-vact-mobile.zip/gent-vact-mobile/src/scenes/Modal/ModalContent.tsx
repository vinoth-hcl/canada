import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Action, Dispatch } from 'redux';
import { map, get } from 'lodash';

import { Button } from '../../components/Button/Button';
import { ButtonKind } from '../../components/Button/types';
import { Colors } from '../../utilities/design';
import { useAccessibleFocus } from '../../hooks/useAccessibleFocus';

export enum ModalType {
  NORMAL = 'NORMAL',
  NOTIFICATION = 'NOTIFICATION',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
  WARNING = 'WARNING',
  DETAILS = 'DETAILS',
  CUSTOM_DETAILS = 'CUSTOM_DETAILS',
  ALERT = 'ALERT',
  YELLOW = 'YELLOW',
  NO_NET_CONNECT = 'NO_NET_CONNECT',
}

const bgColors = {
  [ModalType.WARNING]: Colors.secondaryDark,
  [ModalType.ALERT]: Colors.secondaryDark,
  [ModalType.NORMAL]: Colors.primary,
  [ModalType.NOTIFICATION]: Colors.primary,
};

const btmTextColors = {
  [ModalType.WARNING]: Colors.secondary,
  [ModalType.ALERT]: Colors.secondary,
  [ModalType.NORMAL]: Colors.primaryDarker,
  [ModalType.NOTIFICATION]: Colors.primaryDarker,
};

interface IModalButton {
  text: string;
  onPress?: (e?: Event) => void;
  action?: Action;
}

interface IModalContentProps {
  type: ModalType;
  title?: string;
  message?: string;
  buttons: IModalButton[];
  dispatch: Dispatch;
}

function renderButton(type: ModalType, dispatch: Dispatch) {
  const Func: FunctionComponent<IModalButton> = ({ text, onPress, action }) => {
    const handlePress = () => {
      if (onPress) {
        onPress();
      }
      if (action) {
        dispatch(action);
      }
    };
    return (
      <Button
        key={text}
        kind={ButtonKind.WHITE}
        text={text}
        onPress={handlePress}
        style={{
          textStyle: { color: get(btmTextColors, type) },
          container: {
            width: 135,
            height: 40,
            borderWidth: 0,
            marginTop: 20,
          },
        }}
      />
    );
  };
  return Func;
}

export const ModalContent: FunctionComponent<IModalContentProps> = ({
  type,
  title,
  message,
  buttons,
  dispatch,
}) => {
  const modalRef = useAccessibleFocus();

  return (
    <View
      style={[styles.root, { backgroundColor: get(bgColors, type) }]}
      accessible={true}
      ref={modalRef}
    >
      <Text style={[styles.text, styles.title]}>{title}</Text>
      <Text style={styles.text}>{message}</Text>
      <View style={styles.buttonsContainer}>{map(buttons, renderButton(type, dispatch))}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    position: 'relative',
    opacity: 1,
  },
  buttonsContainer: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
  title: {
    fontWeight: 'bold',
    fontSize: 24,
    marginTop: 20,
  },
  text: {
    marginTop: 10,
    marginLeft: 20,
    marginRight: 20,
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 32,
    color: 'white',
    textAlign: 'center',
  },
});

export enum AlertLevel {
  CRITICAL = 'CRITICAL',
  MIDDLE = 'MIDDLE',
  LOW = 'LOW',
}

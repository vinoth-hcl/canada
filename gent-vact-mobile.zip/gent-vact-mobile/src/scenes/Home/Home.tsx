import React, { FunctionComponent, useCallback } from 'react';
import { SafeAreaView, StyleSheet, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { isEmpty } from 'lodash';

import { EventList } from '../../components/EventList/EventList';
import { SensorList } from '../../components/SensorList/SensorList';
import { Button } from '../../components/Button/Button';
import { setIsActiveSensor } from '../../services/sensors/actions';
import { Colors } from '../../utilities/design';
import {
  getActiveInputAlerts,
  getLastAggregatedMeasurements,
} from '../../services/patient/selector';
import { AUTH_ROUTES, MODAL_ROUTES } from '../../navigation/routes';
import { SensorType } from '../../components/Sensor/types';
import { appRoute } from '../../app/actions';
import {
  MOCK_FEEDBACK_BUTTON,
  TEXT_HEARTBEAT_ON_BUTTON,
  TEXT_LOGIN,
  TEXT_REQUEST_DOCTORS_CALL_BUTTON,
} from '../../constants/constants';
import { isAuthenticatedSelector, temperatureModeSelector } from '../../app/selectors';
import { addMockFeedback } from '../../services/feedback/actions';
import { getSensorsState } from '../../services/sensors/selector';
import { getFeatureFlag } from '../../utilities/config';
import { BackButton } from '../Options/components/BackButton';

interface IHomeProps {
  navigation: object;
}

export const Home: FunctionComponent<IHomeProps> = ({ navigation }) => {
  const dispatch = useDispatch();
  const measurements = useSelector(getLastAggregatedMeasurements);
  const activeAlerts = useSelector(getActiveInputAlerts);
  const isAuthenticated = useSelector(isAuthenticatedSelector);

  const hasSensorList = !isEmpty(measurements);

  const handleCallButton = useCallback(() => {
    dispatch(appRoute(MODAL_ROUTES.SUPPORT_REQUEST));
  }, [dispatch]);

  const handleClickUpdateSensor = useCallback(
    (isActive: boolean, sensorType: SensorType) => {
      dispatch(setIsActiveSensor(isActive, sensorType));
      if (sensorType === SensorType.HEART_RATE) {
        dispatch(appRoute(MODAL_ROUTES.UPDATE_SENSOR, { type: sensorType }));
      }
    },
    [dispatch],
  );

  const handleHeartBeatOn = useCallback(() => {
    dispatch(setIsActiveSensor(true, SensorType.HEART_RATE));
    dispatch(appRoute(MODAL_ROUTES.UPDATE_SENSOR, { type: SensorType.HEART_RATE }));
  }, [dispatch]);

  const handleLogin = useCallback(() => {
    dispatch(appRoute(AUTH_ROUTES.LOGIN));
  }, [dispatch]);

  const handleMockFeedback = useCallback(() => {
    dispatch(appRoute(MODAL_ROUTES.FEEDBACK));
  }, [dispatch]);

  const handleBack = useCallback(() => {
    navigation.goBack();
  }, [navigation]);

  const handleAddMockDate = useCallback(() => {
    dispatch(addMockFeedback());
  }, [dispatch]);

  const temperatureMode = useSelector(temperatureModeSelector);
  const sensorsState = useSelector(getSensorsState);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <BackButton onPress={handleBack} />
      </View>
      {hasSensorList && (
        <SensorList
          onPress={handleClickUpdateSensor}
          measurements={measurements}
          temperatureMode={temperatureMode}
          sensorsState={sensorsState}
        />
      )}
      {activeAlerts.length > 0 && <EventList events={activeAlerts} />}
      {isAuthenticated && (
        <Button
          onPress={handleCallButton}
          text={TEXT_REQUEST_DOCTORS_CALL_BUTTON}
          style={{
            container: styles.button,
          }}
        />
      )}
      {!hasSensorList && (
        <Button
          onPress={handleHeartBeatOn}
          text={TEXT_HEARTBEAT_ON_BUTTON}
          style={{
            container: styles.startHeartBeat,
          }}
        />
      )}
      {getFeatureFlag('featureFeedback') && (
        <>
          <Button
            onPress={handleMockFeedback}
            text={MOCK_FEEDBACK_BUTTON}
            style={{
              container: styles.button,
            }}
          />
          <Button
            onPress={handleAddMockDate}
            text={'MOCK_FEEDBACK_BUTTON'}
            style={{
              container: {
                ...styles.button,
                position: 'relative',
                marginTop: 30,
                marginBottom: 30,
              },
            }}
          />
        </>
      )}
      {!isAuthenticated && (
        <Button
          onPress={handleLogin}
          text={TEXT_LOGIN}
          style={{
            container: styles.button,
          }}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    paddingBottom: 51,
    paddingLeft: 25,
    paddingRight: 25,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: Colors.lightGrey,
  },
  startHeartBeat: {
    width: 269,
    marginBottom: 10,
    backgroundColor: Colors.grey,
  },
  button: {
    width: 269,
    backgroundColor: Colors.blue,
  },
  header: {
    width: '100%',
    height: 16,
    flexDirection: 'row',
    marginTop: 25,
    marginBottom: 23,
    alignItems: 'flex-start',
    paddingLeft: 25,
  },
});

import React, { FunctionComponent, useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import dayjs from 'dayjs';
import { RouteProp } from '@react-navigation/native';
import { StyleSheet } from 'react-native';
import { get } from 'lodash';

import {
  cleanAppointmentDetails,
  getAppointmentDetailsById,
  setCheckChecklistComplete,
} from '../../services/appointments/actions';
import { getFeatureFlag } from '../../utilities/config';
import { appRoute, replaceRoute, startVideoConf } from '../../app/actions';
import { APPT_ROUTES, AUTH_ROUTES, MODAL_ROUTES, TAB_ROUTES } from '../../navigation/routes';
import { getAppointmentDetails } from '../../services/appointments/selector';
import { AppointmentsStackParamList } from '../../navigation/types';
import { AppointmentDto } from '../../api/AppointmentDto';
import { LoadAnimation } from '../../components/LoadAnimation/LoadAnimation';
import { Colors } from '../../utilities/design';
import { useAnimated } from '../../utilities/hooks';
import { getPatientTimezone } from '../../app/selectors';
import { makePhoneCall } from '../../services/externalApps/utils';
import { AppointmentDetailView } from './components/AppointmentDetailView';
import { ApptDetailsHandlers } from './components/types';
import { checkboxGroupMock } from './components/mocks';

const newStartTime = dayjs()
  .set('minute', dayjs().get('minute') + 5)
  .toISOString();

type AppointmentsScreenNavigationProp = RouteProp<AppointmentsStackParamList, APPT_ROUTES.DETAIL>;

interface IAppointmentsDetailPageProps {
  route: AppointmentsScreenNavigationProp;
}

export const AppointmentsDetailPage: FunctionComponent<IAppointmentsDetailPageProps> = ({
  route,
}) => {
  const dispatch = useDispatch();
  const appointmentId = get(route, 'params.id', '');
  const { data: appointment, pending } = useSelector(getAppointmentDetails);
  const patientTimeZonePreferences = useSelector(getPatientTimezone);

  const useCheckListData = getFeatureFlag('useMockCheckList')
    ? ({ ...appointment, checkList: checkboxGroupMock } as AppointmentDto)
    : appointment;

  const alwaysShowAttendButtonData = getFeatureFlag('alwaysShowAttendButton')
    ? { ...useCheckListData, startTime: newStartTime }
    : useCheckListData;

  const checkListId = get(alwaysShowAttendButtonData, 'checkList.id', '');

  const handlers = useMemo(
    (): ApptDetailsHandlers => ({
      handleAttendAppt: () => {
        if (appointment.communicationType === 'VIDEO') {
          const confId = get(appointment, 'connectIds.VIDEO', '');

          dispatch(startVideoConf(confId, appointmentId));
        } else if (appointment.communicationType === 'PHONE') {
          const phoneNumber = get(appointment, 'connectIds.PHONE');
          makePhoneCall(phoneNumber);
        }
      },
      handleBack: () => {
        dispatch(
          replaceRoute(
            `${AUTH_ROUTES.MODAL_NAVIGATOR}:${MODAL_ROUTES.TAB_NAVIGATOR}:${TAB_ROUTES.APPOINTMENTS_MODAL_NAVIGATOR_LIST}`,
          ),
        );
      },
      handleCheck: () => {
        dispatch(setCheckChecklistComplete(checkListId));
      },
      handleReminder: () => {
        // TODO: should be later add action for setRemainder page
        dispatch({ type: 'navigate => setRemainder' });
      },
      handleReschedule: () => {
        dispatch(appRoute(MODAL_ROUTES.RESCHEDULE_REASON, { id: appointmentId }));
      },
      handleSendComment: () => {
        // TODO: should be later add action for input message page
        dispatch({ type: 'navigate => share with caregiver' });
      },
    }),
    [dispatch, appointmentId, appointment, checkListId],
  );

  useEffect(() => {
    dispatch(getAppointmentDetailsById(appointmentId));
    return () => {
      dispatch(cleanAppointmentDetails());
    };
  }, [dispatch, appointmentId]);

  useAnimated();

  return pending ? (
    <LoadAnimation
      style={{
        container: styles.animationContainer,
        circle: styles.animationCircles,
        text: styles.animationText,
      }}
    />
  ) : (
    <AppointmentDetailView
      appointment={alwaysShowAttendButtonData}
      timeZonePreferences={patientTimeZonePreferences}
      handlers={handlers}
    />
  );
};

const styles = StyleSheet.create({
  animationContainer: {
    backgroundColor: Colors.white,
  },
  animationCircles: {
    backgroundColor: Colors.black,
  },
  animationText: {
    color: Colors.black,
  },
});

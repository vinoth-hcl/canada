import React, { FunctionComponent, useCallback, useMemo, useRef } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Platform,
  StyleSheet,
  useWindowDimensions,
  View,
} from 'react-native';
import { debounce, get, map } from 'lodash';

import {
  DEVICE_HEIGHT,
  OS_WEB,
  TEXT_APPOINTMENTS,
  TEXT_PLACEHOLDER_CALENDAR_TITLE,
  TEXT_REQUEST_AN_APPOINTMENT_BUTTON,
  TEXT_REQUESTS,
} from '../../../constants/constants';
import { AppointmentHeader } from '../../../components/Appointment/AppointmentHeader';
import { AppointmentItem } from '../../../components/Appointment/AppointmentItem';
import { AppointmentDto } from '../../../api/AppointmentDto';
import { Separator } from '../../../components/Separator/Separator';
import { AppointmentStatus } from '../../../services/appointments/types';
import { Colors } from '../../../utilities/design';
import {
  getScreenModel,
  WebLayoutTemplate,
  WebViews,
} from '../../../components/WebLayoutTemplate/WebLayoutTemplate';
import { PlaceHolderView } from '../../../components/PlaceholderView/PlaceholderView';
import { TextStyles } from '../../../components/GText/styles';
import { GText } from '../../../components/GText/GText';
import { GButton } from '../../../components/GButton/GButton';
import { ButtonKind } from '../../../components/GButton/types';
import Plus from '../../../../assets/images/Plus.svg';
import { useIsPortrait } from '../../../hooks/breakpoints';
import { ApptPlaceholder } from './ApptPlaceholder';
import {
  getHasShowLeftSide,
  getIsHeader,
  isAppointmentRequest,
  keyExtractor,
  VIEW_CHANGE_DEBOUNCE,
  viewabilityConfig,
} from './utils';
import { IAppointmentsView } from './types';
import RefreshControl from './RefreshControl';

function getRightSide(
  pendingAppt: boolean,
  screenModel: WebViews.MOBILE | WebViews.SMALL | WebViews.TINY | WebViews.LARGE | WebViews.MEDIUM,
  actualApps: AppointmentDto[],
  renderAppointment: ({ item: appointment, index }: { item: any; index: any }) => JSX.Element,
  renderWebHeader: (title: string) => () => JSX.Element | null,
  renderPlaceHolder: () => JSX.Element,
  onViewableItemsChanged: any,
) {
  const hasShowBigScreen = screenModel === WebViews.LARGE || screenModel === WebViews.MEDIUM;

  return [
    getLoaderIndicator(pendingAppt && hasShowBigScreen),
    <FlatList
      data={actualApps}
      renderItem={renderAppointment}
      ItemSeparatorComponent={Separator}
      ListHeaderComponent={renderWebHeader(TEXT_APPOINTMENTS)}
      ListEmptyComponent={renderPlaceHolder}
      style={[
        screenModel === WebViews.LARGE && {
          marginLeft: 80,
        },
        screenModel === WebViews.MEDIUM && {
          marginLeft: 40,
        },
      ]}
      onViewableItemsChanged={onViewableItemsChanged.current}
      keyExtractor={keyExtractor}
    />,
  ];
}

function getLoaderIndicator(hasShow: boolean) {
  return (
    <>
      {hasShow && (
        <View
          style={styles.indicator}
          children={<ActivityIndicator size={'large'} color={Colors.black} />}
        />
      )}
    </>
  );
}

function getLeftSide(
  screenModel:
    | WebViews
    | WebViews.MOBILE
    | WebViews.MEDIUM
    | WebViews.SMALL
    | WebViews.TINY
    | WebViews.LARGE,
  pendingRequestPartial: boolean,
  pendingAppt: boolean,
  appointmentsRequestPartial: AppointmentDto[],
  renderAppointment: ({ item: appointment, index }: { item: any; index: any }) => JSX.Element,
  renderHeader: () => JSX.Element | null,
  renderWebHeader: (title: string) => () => JSX.Element | null,
  renderWebPlaceholder: () => JSX.Element | null,
  onViewableItemsChanged: any,
) {
  const { hasShowSmallScreen, hasShowBigScreen, hasShowLoaderIndicator } = getHasShowLeftSide(
    screenModel,
    pendingRequestPartial,
    pendingAppt,
  );

  return [
    getLoaderIndicator(hasShowLoaderIndicator),
    <FlatList
      data={appointmentsRequestPartial}
      renderItem={renderAppointment}
      ItemSeparatorComponent={Separator}
      ListHeaderComponent={hasShowSmallScreen ? renderHeader : renderWebHeader(TEXT_REQUESTS)}
      ListEmptyComponent={renderWebPlaceholder}
      style={[
        screenModel === WebViews.LARGE && {
          marginRight: 80,
        },
        screenModel === WebViews.MEDIUM && {
          marginRight: 40,
        },
      ]}
      onViewableItemsChanged={onViewableItemsChanged.current}
      keyExtractor={keyExtractor}
    />,
    <>{hasShowBigScreen && <View style={styles.emptyComponent} />}</>,
  ];
}

export const AppointmentsView: FunctionComponent<IAppointmentsView> = ({
  actualApps,
  partialApps,
  requestApps,
  timeZonePreferences,
  onApptPress,
  handlePressAddAppt,
  onViewChange,
  onEndReached,
  onRefreshAppt,
  onRefreshRequestPartial,
  pendingAppt,
  pendingRequestPartial,
}) => {
  const dimensions = useWindowDimensions();
  const isPortrait = useIsPortrait();

  const screenModel = useMemo(() => getScreenModel(dimensions.width), [dimensions.width]);
  const pending = useMemo(() => pendingAppt || pendingRequestPartial, [
    pendingAppt,
    pendingRequestPartial,
  ]);
  const onRefresh = useCallback(() => {
    if (pending) {
      return;
    }
    onRefreshAppt();
    onRefreshRequestPartial();
  }, [pending, onRefreshAppt, onRefreshRequestPartial]);

  const hasPlaseholder =
    !pending && actualApps.length === 0 && partialApps.length === 0 && requestApps.length === 0;

  const appointmentsRequestPartial = useMemo(() => {
    const appointmentRequestItems: AppointmentDto[] = map(
      requestApps,
      (item) =>
        ({
          doctor: item.doctor,
          id: item.id,
          startTime: item.createdDate,
          communicationType: get(item, 'trialCalendar.communicationType'),
          connectIds: {},
          status: AppointmentStatus.NEW,
        } as any),
    );

    return [...appointmentRequestItems, ...partialApps];
  }, [requestApps, partialApps]);

  const appointments = useMemo(() => {
    return [...appointmentsRequestPartial, ...actualApps];
  }, [appointmentsRequestPartial, actualApps]);

  const handlePressOpenAppt = useCallback(
    (appointment: AppointmentDto) => {
      if (isAppointmentRequest(appointment)) {
        return;
      }
      onApptPress(appointment);
    },
    [onApptPress],
  );

  const renderAppointment = useCallback(
    ({ item: appointment, index }) => {
      const { startTime } = appointment;
      const isHeader = getIsHeader(
        appointment,
        index,
        appointments,
        startTime,
        timeZonePreferences,
      );
      return (
        <AppointmentItem
          isHeader={isHeader}
          timeZonePreferences={timeZonePreferences}
          onPress={handlePressOpenAppt}
          appointment={appointment}
          key={`${appointment.id}-${appointment.status}`}
          index={index}
        />
      );
    },
    [handlePressOpenAppt, appointments, timeZonePreferences],
  );

  const renderPlaceHolder = useCallback(() => {
    return (
      <>
        {!isPortrait && !pending && (
          <View style={styles.center}>
            <PlaceHolderView
              text={''}
              style={{ container: styles.placeholderContainer }}
              children={
                <GText
                  textStyle={TextStyles.BITTER_20_28_NORMAL}
                  style={styles.textPlaceholder}
                  children={TEXT_PLACEHOLDER_CALENDAR_TITLE}
                />
              }
            />
          </View>
        )}
      </>
    );
  }, [pending, isPortrait]);

  const renderHeader = useCallback(
    () => (
      <AppointmentHeader
        handlePressAddApt={handlePressAddAppt}
        textHeader={TEXT_REQUEST_AN_APPOINTMENT_BUTTON}
      />
    ),
    [handlePressAddAppt],
  );

  const renderButton = useCallback(
    () => (
      <GButton
        onPress={handlePressAddAppt}
        kind={ButtonKind.WHITE}
        text={TEXT_REQUEST_AN_APPOINTMENT_BUTTON}
        Icon={Plus}
        isShadow
        style={{
          container: styles.button,
          iconContainerStyle: styles.iconContainer,
          textStyle: styles.text,
          textFont: TextStyles.SOURCE_SANS_16_20_SEMIBOLD,
        }}
        testID={'AddAppointment'}
      />
    ),
    [handlePressAddAppt],
  );

  const renderWebHeader = useCallback(
    (title: string): (() => JSX.Element | null) => () =>
      screenModel === WebViews.LARGE || screenModel === WebViews.MEDIUM ? (
        <>
          {hasPlaseholder ? (
            <View style={{ alignItems: 'center' }} children={renderButton()} />
          ) : (
            <GText
              textStyle={TextStyles.SOURCE_SANS_16_24_SEMIBOLD}
              style={{ color: Colors.greyDark, marginBottom: 16, marginLeft: 20, marginTop: 40 }}
              testID={'HeaderAppt'}
              children={title}
            />
          )}
          <Separator />
        </>
      ) : null,
    [renderButton, screenModel, hasPlaseholder],
  );

  const renderWebPlaceholder = useCallback(() => (hasPlaseholder ? <ApptPlaceholder /> : null), [
    hasPlaseholder,
  ]);

  const onViewableItemsChanged = useRef(
    debounce(({ viewableItems }) => {
      onViewChange(map(viewableItems, ({ item }) => item));
    }, VIEW_CHANGE_DEBOUNCE),
  );

  return (
    <>
      {Platform.OS === OS_WEB ? (
        <WebLayoutTemplate
          leftSide={getLeftSide(
            screenModel,
            pendingRequestPartial,
            pendingAppt,
            appointmentsRequestPartial,
            renderAppointment,
            renderHeader,
            renderWebHeader,
            renderWebPlaceholder,
            onViewableItemsChanged,
          )}
          rightSide={
            !hasPlaseholder
              ? getRightSide(
                  pendingAppt,
                  screenModel,
                  actualApps,
                  renderAppointment,
                  renderWebHeader,
                  renderPlaceHolder,
                  onViewableItemsChanged,
                )
              : undefined
          }
          enableRightScroll={true}
          enableLeftScroll={true}
          enableCommonScroll={true}
          isSeparator={!hasPlaseholder}
          button={!hasPlaseholder ? renderButton() : undefined}
          topMargin={0}
        />
      ) : (
        <>
          <FlatList
            data={appointments}
            renderItem={renderAppointment}
            ItemSeparatorComponent={Separator}
            ListHeaderComponent={renderHeader}
            ListEmptyComponent={renderWebPlaceholder}
            onEndReached={onEndReached}
            onEndReachedThreshold={0.3}
            viewabilityConfig={viewabilityConfig}
            onViewableItemsChanged={onViewableItemsChanged.current}
            onRefresh={onRefresh}
            refreshing={!!pending}
            keyExtractor={keyExtractor}
            refreshControl={
              //TODO switch to custom loader
              // <CustomRefreshControl refreshing={!!pending} />
              <RefreshControl
                refreshing={!!pending}
                onRefresh={onRefresh}
                progressViewOffset={DEVICE_HEIGHT * 0.3}
                size={(RefreshControl.SIZE as any).LARGE}
              />
            }
          />
        </>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  indicator: {
    position: 'absolute',
    width: '100%',
    top: 100,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
  },
  footer: {
    alignItems: 'center',
  },
  button: {
    width: 239,
    marginTop: 16,
    marginBottom: 16,
  },
  text: {
    color: Colors.greyDark,
  },
  iconContainer: {
    width: 24,
    height: 24,
    backgroundColor: Colors.gold,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderContainer: {
    height: '100%',
    maxWidth: 312,
  },
  center: {
    marginTop: 48,
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
  },
  emptyComponent: {
    height: 96,
  },
  textPlaceholder: {
    textAlign: 'center',
    color: Colors.greyDark,
  },
});

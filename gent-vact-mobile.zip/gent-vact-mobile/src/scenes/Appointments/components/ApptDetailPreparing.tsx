import React, { FunctionComponent, useCallback, useMemo, useState } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { map, get } from 'lodash';

import { CheckBoxItem } from '../../../components/CheckBoxBlock/CheckBoxItem';
import { CheckBoxTypes } from '../../../components/CheckBoxBlock/types';
import { Colors } from '../../../utilities/design';
import {
  EVERYTHING_READY,
  MARK_EVERYTHING_READY,
  TEXT_SURVEY_HEADER,
} from '../../../constants/constants';
import { Title } from './Title';
import { IApptDetailPreparingProps } from './types';

export const ApptDetailPreparing: FunctionComponent<IApptDetailPreparingProps> = ({
  checkboxGroup,
  onCheck,
}) => {
  const itemsList = get(checkboxGroup, 'items', []);
  const [isChecked, setChecked] = useState(checkboxGroup.status === 'COMPLETED');
  const checkBoxLabel = useMemo(() => (isChecked ? EVERYTHING_READY : MARK_EVERYTHING_READY), [
    isChecked,
  ]);
  const handleCheck = useCallback(() => {
    if (!isChecked) {
      onCheck();
      setChecked(true);
    }
  }, [isChecked, onCheck]);

  return (
    <View style={styles.container}>
      <Title
        title={TEXT_SURVEY_HEADER}
        descriptionText={checkboxGroup.description}
        style={{
          header: styles.header,
          description: styles.description,
        }}
      >
        {itemsList.length > 0 && (
          <>
            {map(itemsList, (item, index) => {
              const { id, title, description } = item;
              const key = `${id}_${index}`;

              return (
                <View style={styles.listContainer} key={key}>
                  <View style={styles.dot} />
                  <View style={styles.item}>
                    <Text style={styles.text}>{title}</Text>
                    <Text style={styles.descriptionText}>{description}</Text>
                  </View>
                </View>
              );
            })}
            <CheckBoxItem
              text={checkBoxLabel}
              type={CheckBoxTypes.MEDIUM_GOLD}
              index={'allReady'}
              style={styles.checkButtonStyle}
              allViewTouchable
              initialCheck={isChecked}
              readonly={isChecked}
              onCheck={handleCheck}
            />
          </>
        )}
      </Title>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: 25,
    paddingBottom: 25,
    backgroundColor: Colors.white,
    paddingLeft: 20,
    paddingRight: 20,
  },
  header: {
    marginBottom: 20,
  },
  description: {
    marginBottom: 20,
    color: Colors.greyDark,
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 24,
  },
  dot: {
    backgroundColor: Colors.greyDark,
    width: 8,
    height: 8,
    borderRadius: 4,
    marginTop: 9,
    marginRight: 27,
    marginLeft: 18,
  },
  listContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    marginTop: 10,
    marginBottom: 10,
    paddingRight: 10,
  },
  text: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 16,
    lineHeight: 24,
  },
  checkButtonStyle: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    paddingLeft: 16,
    marginTop: 16,
    height: 64,
    alignItems: 'center',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderRadius: 10,
    borderColor: Colors.almostWhite,
  },
  descriptionText: {
    fontStyle: 'normal',
    fontWeight: '400',
    fontSize: 16,
    lineHeight: 24,
  },
  item: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    width: '90%',
  },
});

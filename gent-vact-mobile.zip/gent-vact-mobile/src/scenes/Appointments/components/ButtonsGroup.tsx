import React, { FunctionComponent } from 'react';
import { map } from 'lodash';

import { Button } from '../../../components/Button/Button';
import { ButtonKind } from '../../../components/Button/types';
import { IButtonItem, IButtonsGroupProps } from './types';

export const ButtonsGroup: FunctionComponent<IButtonsGroupProps> = ({ handlers, buttons }) => {
  return (
    <>
      {map(buttons, ({ type, Icon, buttonType, title: titleText }: IButtonItem, index: number) => {
        const isDisable = buttonType === ButtonKind.MAIN_DISABLED;
        const onPress = handlers(type);
        const key = `${type}_${index}`;

        return (
          <Button
            onPress={onPress}
            kind={buttonType}
            key={key}
            Icon={Icon}
            text={titleText}
            disabled={isDisable}
            style={{ container: { paddingLeft: 16 } }}
            testID={`GroupButton_${index}`}
          />
        );
      })}
    </>
  );
};

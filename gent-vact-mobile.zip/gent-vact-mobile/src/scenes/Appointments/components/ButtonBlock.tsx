import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

import { ButtonsGroup } from './ButtonsGroup';
import { ApptDetailPlaceholder } from './ApptDetailPlaceholder';
import { IButtonBlockProps } from './types';

export const ButtonBlock: FunctionComponent<IButtonBlockProps> = ({
  buttonGroup,
  handlers,
  date,
  time,
  status,
}) => {
  const hasButtons = buttonGroup.length > 0;

  return (
    <View style={styles.container}>
      {hasButtons ? (
        <ButtonsGroup handlers={handlers} buttons={buttonGroup} />
      ) : (
        <ApptDetailPlaceholder title={date} description={time} status={status} />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingLeft: 25,
    paddingRight: 25,
    marginBottom: 32,
  },
});

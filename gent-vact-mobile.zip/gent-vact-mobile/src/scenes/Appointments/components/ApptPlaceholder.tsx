import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

import { GText } from '../../../components/GText/GText';
import { TextStyles } from '../../../components/GText/styles';
import {
  TEXT_PLACHOLDER_CALENDAR_DESC,
  TEXT_PLACHOLDER_CALENDAR_HEADER,
  TEXT_PLACEHOLDER_CALENDAR_TITLE,
  IS_OS_WEB,
} from '../../../constants/constants';
import Calendar from '../../../../assets/images/CalendarPlaceholder.svg';
import { Colors } from '../../../utilities/design';

export const ApptPlaceholder: FunctionComponent<{}> = () => {
  return (
    <View style={StyleSheet.flatten([styles.container, IS_OS_WEB && styles.containerWeb])}>
      <GText
        textStyle={TextStyles.BITTER_20_24_NORMAL}
        style={StyleSheet.flatten([styles.text, styles.textWrapper])}
        children={TEXT_PLACEHOLDER_CALENDAR_TITLE}
      />
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        style={styles.text}
        children={TEXT_PLACHOLDER_CALENDAR_HEADER}
      />
      <View style={styles.icon}>
        <Calendar />
      </View>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        style={styles.text}
        children={TEXT_PLACHOLDER_CALENDAR_DESC}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginTop: 32,
    marginRight: 16,
    marginLeft: 16,
    marginBottom: 80,
  },
  containerWeb: {
    marginTop: 80,
  },
  textWrapper: {
    marginBottom: 16,
  },
  text: {
    color: Colors.greyDark,
    maxWidth: 312,
    textAlign: 'center',
  },
  icon: {
    marginTop: 30,
    marginBottom: 42,
  },
});

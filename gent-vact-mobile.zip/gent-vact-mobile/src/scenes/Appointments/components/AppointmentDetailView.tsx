import React, { FunctionComponent, useCallback, useEffect, useMemo, useState } from 'react';
import { ScrollView, StyleSheet, View, Text, SafeAreaView } from 'react-native';
import dayjs from 'dayjs';
import { get } from 'lodash';

import {
  APPOINTMENT_DETAILS,
  APPOINTMENT_RESCHEDULED_TEXT,
  IS_OS_WEB,
  SAFE_AREA_COLOR,
  TEXT_EMPTY_APPOINTMENT,
} from '../../../constants/constants';
import { Colors } from '../../../utilities/design';
import { PlaceHolderView } from '../../../components/PlaceholderView/PlaceholderView';
import { BackButton } from '../../Options/components/BackButton';
import { useInterval } from '../../../hooks/useInterval';
import { AppointmentStatus } from '../../../services/appointments/types';
import { CheckListDto } from '../../../api/CheckListDto';
import { testId } from '../../../utilities/TestId';
import { formatDate } from '../../../utilities/date';
import { FORMAT_TIME_24_ENABLED } from '../../../utilities/config';
import { GText } from '../../../components/GText/GText';
import { TextStyles } from '../../../components/GText/styles';
import { ApptDetailGetReadyBlock } from '../../../components/Appointment/components/ApptDetailGetReadyBlock';
import { ApptDetailHeader } from './ApptDetailHeader';
import { ApptDetailPreparing } from './ApptDetailPreparing';
import { ButtonType, IAppointmentDetailViewProps } from './types';
import { getButtonGroup } from './utils';
import { ButtonBlock } from './ButtonBlock';

const FORMAT_DATE = 'dddd, MMMM D YYYY';
const FORMAT_TIME = FORMAT_TIME_24_ENABLED ? 'HH:mm (Z)' : 'hh:mm A (Z)';
const IS_ATTEND_BUTTON_TIME = 6;
const DELAY_IS_ATTEND_BUTTON_UPDATE = 9 * 1000;

export const AppointmentDetailView: FunctionComponent<IAppointmentDetailViewProps> = ({
  appointment,
  timeZonePreferences,
  handlers: {
    handleBack,
    handleReschedule,
    handleReminder,
    handleCheck,
    handleSendComment,
    handleAttendAppt,
  },
}) => {
  const id = get(appointment, 'id', '');
  const apptStatus = get(appointment, 'status');
  const startTime = get(appointment, 'startTime', '');
  const checkList: any = get(appointment, 'checkList', []);
  const endTime: string = get(appointment, 'endTime', '');
  const communicationType = get(appointment, 'communicationType', 'IN_PERSON');
  const localizeDate = useCallback(
    (formatTemplate) => {
      if (!startTime) {
        return '';
      }

      return formatDate(startTime, timeZonePreferences, formatTemplate);
    },
    [startTime, timeZonePreferences],
  );

  const drName = `Dr. ${get(appointment, 'doctor.name', '')}`;

  const date = useMemo(() => localizeDate(FORMAT_DATE), [localizeDate]);
  const time = useMemo(() => localizeDate(FORMAT_TIME), [localizeDate]);

  const [isActiveAttendButton, setIsActiveAttendButton] = useState<boolean>(false);

  const buttonGroup = useMemo(() => {
    return getButtonGroup(appointment, isActiveAttendButton);
  }, [appointment, isActiveAttendButton]);

  const checkForAttendBtnShow = useCallback(() => {
    if (!startTime || !endTime) {
      return;
    }

    const now = dayjs().tz(timeZonePreferences.iana);
    const lessThan6MinutesToApt = dayjs(startTime).diff(now, 'minute') < IS_ATTEND_BUTTON_TIME;
    const lessThan1HourAfterEndTime = dayjs(endTime).add(1, 'hour');

    if (
      lessThan6MinutesToApt &&
      now.isBefore(lessThan1HourAfterEndTime) &&
      communicationType !== 'IN_PERSON'
    ) {
      setIsActiveAttendButton(true);
    } else if (isActiveAttendButton) {
      setIsActiveAttendButton(false);
    }
  }, [startTime, endTime, isActiveAttendButton, communicationType, timeZonePreferences]);

  useEffect(checkForAttendBtnShow, []);
  useInterval(checkForAttendBtnShow, DELAY_IS_ATTEND_BUTTON_UPDATE, [startTime, endTime]);

  const getHandlePress = useCallback(
    (item: ButtonType) => () => {
      switch (item) {
        case ButtonType.ATTEND: {
          return handleAttendAppt();
        }
        case ButtonType.PEOPLE: {
          return handleSendComment();
        }
        case ButtonType.SET_HOURS: {
          return handleReminder();
        }
        case ButtonType.RESCHEDULE: {
          return handleReschedule();
        }
      }
    },
    [handleAttendAppt, handleSendComment, handleReminder, handleReschedule],
  );

  const header = (
    <View style={styles.backWithTitle}>
      <BackButton onPress={handleBack} />
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_SEMIBOLD}
        children={APPOINTMENT_DETAILS}
        style={styles.headerText}
        role={'header'}
      />
    </View>
  );

  const readyBlock = <ApptDetailGetReadyBlock />;

  const renderLeftSide = () => (
    <SafeAreaView style={styles.container}>
      <View style={styles.subContainer}>
        {header}
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={StyleSheet.flatten([
            { width: '100%' },
            IS_OS_WEB && { marginTop: 40, alignItems: 'center' },
          ])}
        >
          {id ? (
            <View style={styles.header}>
              <ApptDetailHeader
                name={drName}
                startTime={startTime}
                endTime={endTime}
                status={apptStatus}
                timeZonePreferences={timeZonePreferences}
                communicationType={communicationType}
              />
              {apptStatus === AppointmentStatus.RESCHEDULED ? (
                <View style={styles.rescheduledGold}>
                  <Text style={styles.rescheduledText} {...testId('Text_reschedule')}>
                    {APPOINTMENT_RESCHEDULED_TEXT(drName)}
                  </Text>
                </View>
              ) : (
                <>
                  <View style={styles.separator} />
                  <ButtonBlock
                    buttonGroup={buttonGroup}
                    handlers={getHandlePress}
                    date={date}
                    time={time}
                    status={apptStatus}
                  />
                </>
              )}
            </View>
          ) : (
            <PlaceHolderView text={TEXT_EMPTY_APPOINTMENT} />
          )}
          {checkList.items?.length > 0 && (
            <ApptDetailPreparing checkboxGroup={checkList as CheckListDto} onCheck={handleCheck} />
          )}
          {!IS_OS_WEB && readyBlock}
        </ScrollView>
      </View>
    </SafeAreaView>
  );

  return renderLeftSide();
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: SAFE_AREA_COLOR,
  },
  subContainer: {
    backgroundColor: Colors.white,
    flex: 1,
    justifyContent: 'flex-start',
    width: '100%',
    maxWidth: 1024,
  },
  backWithTitle: {
    marginLeft: 13,
    marginTop: 24,
    flexDirection: 'row',
  },
  header: {
    marginTop: 8,
    marginLeft: 16,
    marginRight: 16,
    backgroundColor: Colors.whiteGray,
    borderRadius: 24,
    maxWidth: IS_OS_WEB ? 328 : '100%',
    flex: IS_OS_WEB ? 1 : 0,
  },
  headerText: {
    marginLeft: 30,
  },
  separator: {
    height: 1,
    width: '90%',
    borderTopColor: Colors.greyWarmLight,
    borderTopWidth: 1,
    marginLeft: 16,
    marginRight: 16,
    marginTop: 24,
    marginBottom: 24,
  },
  rescheduledGold: {
    backgroundColor: Colors.goldLight,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    paddingLeft: 16,
    paddingRight: 16,
    paddingTop: 20,
    paddingBottom: 20,
  },
  rescheduledText: {
    fontWeight: 'bold',
    fontStyle: 'normal',
    fontSize: 16,
    lineHeight: 24,
    color: 'black',
  },
});

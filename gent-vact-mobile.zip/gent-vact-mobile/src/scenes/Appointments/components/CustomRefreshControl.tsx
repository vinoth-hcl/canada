import { RefreshControlProps, StyleSheet, View } from 'react-native';
import React, { FunctionComponent } from 'react';
import { LoadAnimation } from '../../../components/LoadAnimation/LoadAnimation';
import { Colors } from '../../../utilities/design';

export interface CustomRefreshControlProps extends RefreshControlProps {
  children?: any;
}

export const CustomRefreshControl: FunctionComponent<CustomRefreshControlProps> = ({
  refreshing,
  children,
}) => {
  if (!refreshing) {
    return children;
  }
  return (
    <View style={styles.animationWrapper}>
      {children}
      <LoadAnimation
        style={{
          container: styles.animationContainer,
          circle: styles.animationCircles,
          text: styles.animationText,
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  animationWrapper: {
    position: 'relative',
  },
  animationContainer: {
    backgroundColor: 'transparent',
    position: 'absolute',
    height: 80,
    width: '100%',
    flex: undefined,
  },
  animationCircles: {
    backgroundColor: Colors.black,
  },
  animationText: {
    color: Colors.black,
  },
});

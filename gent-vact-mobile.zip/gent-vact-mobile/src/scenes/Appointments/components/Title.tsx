import React, { FunctionComponent } from 'react';
import { StyleSheet, Text } from 'react-native';

import { Colors } from '../../../utilities/design';
import { ITitleProps } from './types';

export const Title: FunctionComponent<ITitleProps> = ({
  children,
  title,
  descriptionText,
  style = {},
}) => {
  const { header = {}, description = {} } = style;
  const headerStyle = [styles.header, header];
  const descriptionStyle = [styles.description, description];

  return (
    <>
      {!!title && <Text style={headerStyle} children={title} />}
      {!!descriptionText && <Text style={descriptionStyle} children={descriptionText} />}
      {children}
    </>
  );
};

const styles = StyleSheet.create({
  header: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 17,
    lineHeight: 22,
    color: Colors.black,
  },
  description: {
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 24,
    color: Colors.black,
  },
});

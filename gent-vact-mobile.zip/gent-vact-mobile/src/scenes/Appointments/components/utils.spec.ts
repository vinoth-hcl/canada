import { mockAppointment } from '../../../components/Appointment/mock';
import { AppointmentType } from '../../../services/appointments/types';
import { getApptType, getButtonGroup, getDrName } from './utils';

describe('Appointments utils tests', () => {
  describe('getButtonGroup test', () => {
    it('should return []', () => {
      expect(getButtonGroup({ ...mockAppointment, status: 'REJECTED' }, true)).toEqual([]);
      expect(getButtonGroup({ ...mockAppointment, status: 'REJECTED' }, false)).toEqual([]);
      expect(getButtonGroup({ ...mockAppointment, status: 'RESOLVED' }, true)).toEqual([]);
      expect(getButtonGroup({ ...mockAppointment, status: 'RESOLVED' }, false)).toEqual([]);
      expect(getButtonGroup({ ...mockAppointment, status: 'MISSED' }, true)).toEqual([]);
      expect(getButtonGroup({ ...mockAppointment, status: 'MISSED' }, false)).toEqual([]);
    });
  });

  describe('getApptType test', () => {
    it('should return correct string', () => {
      expect(getApptType(AppointmentType.IN_PERSON)).toBe('In Person');
      expect(getApptType(AppointmentType.VIDEO)).toBe('Video Call');
      expect(getApptType(AppointmentType.PHONE)).toBe('Phone Call');
      expect(getApptType('123ddd')).toBe('');
    });

    it('should return ""', () => {
      expect(getApptType('123ddd')).toBe('');
      expect(getApptType('')).toBe('');
    });
  });

  describe('getDrName test', () => {
    it('should return correct string', () => {
      expect(getDrName(['Brown', 'Adam'])).toBe('Brown Adam');
      expect(getDrName(['Brown', 'Adam', ''])).toBe('Brown Adam');
      expect(getDrName(['Brown', ''])).toBe('Brown');
    });

    it('should return ""', () => {
      expect(getDrName(['', '', ''])).toBe('');
      expect(getDrName([''])).toBe('');
      expect(getDrName(undefined)).toBe('');
      expect(getDrName()).toBe('');
    });
  });
});

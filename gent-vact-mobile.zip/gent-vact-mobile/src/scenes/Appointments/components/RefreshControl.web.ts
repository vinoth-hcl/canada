function RefreshControl({ children }: any) {
  return children;
}

RefreshControl.SIZE = {
  LARGE: 2,
};

export default RefreshControl;

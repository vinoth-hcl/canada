import React, { FunctionComponent, useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Colors } from '../../../utilities/design';
import {
  TEXT_IN_PERSON,
  TEXT_PHONE_CALL,
  VIDEO_CALL,
  VIRTUAL_APPOINTMENT,
} from '../../../constants/constants';
import { AppointmentStatus } from '../../../services/appointments/types';
import { testId } from '../../../utilities/TestId';
import { TimezoneDto } from '../../../api/TimezoneDto';
import { formatDate } from '../../../utilities/date';
import PInvestigator from '../../../../assets/images/PInvestigator.svg';
import { FORMAT_TIME_24_ENABLED } from '../../../utilities/config';

const DATE_FROM = FORMAT_TIME_24_ENABLED ? 'dddd, MMMM Do, H:mm' : 'dddd, MMMM Do, h:mm a';
const DATE_TO = FORMAT_TIME_24_ENABLED ? 'H:mm' : 'h:mm a';

interface IApptDetailHeaderProps {
  name: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  timeZonePreferences: TimezoneDto;
  communicationType: string;
}

export const ApptDetailHeader: FunctionComponent<IApptDetailHeaderProps> = ({
  name,
  startTime,
  endTime,
  status,
  communicationType,
  timeZonePreferences,
}) => {
  const commTypes: { [k: string]: string } = {
    VIDEO: VIDEO_CALL,
    PHONE: TEXT_PHONE_CALL,
    IN_PERSON: TEXT_IN_PERSON,
  };
  const from = useMemo(
    () => formatDate(startTime, { ...timeZonePreferences, abbreviation: '' }, DATE_FROM),
    [startTime, timeZonePreferences],
  );
  const to = useMemo(() => formatDate(endTime, timeZonePreferences, DATE_TO), [
    endTime,
    timeZonePreferences,
  ]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.virtualText} numberOfLines={2}>
          {VIRTUAL_APPOINTMENT(name)}
        </Text>
        <View style={styles.picture}>
          <PInvestigator />
        </View>
      </View>
      <Text style={styles.timeStyle} {...testId('Telehealth')}>
        {commTypes[communicationType]}
      </Text>
      <Text
        style={[
          styles.timeStyle,
          status === AppointmentStatus.RESCHEDULED ? styles.rescheduledText : {},
        ]}
        {...testId('Dates')}
      >{`${from} - ${to}`}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  virtualText: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 16,
    lineHeight: 24,
    color: Colors.greyDark,
    flex: 1,
  },
  header: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 32,
    paddingLeft: 16,
    paddingRight: 16,
  },
  headerText: {
    fontWeight: 'bold',
    fontSize: 20,
    lineHeight: 30,
  },
  trialText: {
    fontWeight: '600',
    fontSize: 16,
    lineHeight: 24,
    textTransform: 'uppercase',
    color: Colors.green,
  },
  image: {
    height: 40,
    width: 40,
  },
  timeStyle: {
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 24,
    color: Colors.greyDark,
    marginLeft: 16,
  },
  rescheduledText: {
    color: Colors.secondaryDarkest,
    marginBottom: 24,
  },
  picture: {
    width: 56,
    height: 56,
  },
});

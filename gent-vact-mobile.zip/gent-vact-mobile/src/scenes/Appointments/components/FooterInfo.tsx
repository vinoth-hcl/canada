import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Button } from '../../../components/Button/Button';
import { ButtonKind } from '../../../components/Button/types';
import {
  TEXT_INFO_CONNECT_BUTTON,
  TEXT_INFO_HEADER,
  TEXT_INFO_TELEHEALTH_BUTTON,
} from '../../../constants/constants';
import { Colors } from '../../../utilities/design';
import { IFooterInfoProps } from './types';

export const FooterInfo: FunctionComponent<IFooterInfoProps> = ({
  onPressConnect,
  onPressTelehealth,
}) => {
  const buttonStyle = {
    container: [styles.buttonContainer, { backgroundColor: Colors.greyWarmLight }],
  };

  return (
    <View style={styles.container}>
      <View style={styles.underline} />
      <Text style={styles.header} children={TEXT_INFO_HEADER} />
      <Button
        onPress={onPressConnect}
        kind={ButtonKind.CIRCLE_WHITE}
        text={TEXT_INFO_CONNECT_BUTTON}
        style={buttonStyle}
        disabled={true}
      />
      <Button
        onPress={onPressTelehealth}
        kind={ButtonKind.CIRCLE_WHITE}
        text={TEXT_INFO_TELEHEALTH_BUTTON}
        style={buttonStyle}
        disabled={true}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
  },
  header: {
    marginLeft: 25,
    marginRight: 25,
    marginTop: 20,
    marginBottom: 20,
  },
  underline: {
    height: 10,
    width: '100%',
    backgroundColor: Colors.greyLightest,
  },
  buttonContainer: {
    marginLeft: 25,
    marginRight: 25,
    marginBottom: 13,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: Colors.gold,
    justifyContent: 'flex-start',
    paddingLeft: 16,
    paddingRight: 16,
  },
});

import { ElementType } from 'react';
import { StyleProp, TextStyle } from 'react-native';

import { AppointmentDto } from '../../../api/AppointmentDto';
import { AppointmentDetailsDto } from '../../../api/AppointmentDetailsDto';
import { ButtonKind } from '../../../components/Button/types';
import { CheckListDto } from '../../../api/CheckListDto';
import { AppointmentStatus } from '../../../services/appointments/types';
import { TimezoneDto } from '../../../api/TimezoneDto';
import { FutureAppointmentDto } from '../../../api/FutureAppointmentDto';

export interface IAppointmentsView {
  actualApps: AppointmentDto[];
  partialApps: AppointmentDto[];
  requestApps: FutureAppointmentDto[];
  timeZonePreferences: TimezoneDto;
  onApptPress: (appointment: AppointmentDto) => void;
  handlePressAddAppt: () => void;
  onViewChange: (items: AppointmentDto[]) => void;
  onEndReached: () => void;
  onRefreshAppt: () => void;
  onRefreshRequestPartial: () => void;
  pendingAppt: boolean;
  pendingRequestPartial: boolean;
}

export interface ITitleProps {
  title?: string;
  descriptionText?: string;
  style?: {
    header?: StyleProp<TextStyle>;
    description?: StyleProp<TextStyle>;
  };
}

export interface IApptDetailPlaceholderProps {
  title: string;
  description: string;
  status: AppointmentStatus;
}

export enum ButtonType {
  ATTEND = 'ATTEND',
  PEOPLE = 'PEOPLE',
  SET_HOURS = 'SET_HOURS',
  RESCHEDULE = 'RESCHEDULE',
  CHOOSE_TIME = 'CHOOSE_TIME',
}

export interface IButtonItem {
  type: ButtonType;
  Icon: ElementType;
  buttonType: ButtonKind;
  title: string;
}

export interface IFooterInfoProps {
  onPressConnect: () => void;
  onPressTelehealth: () => void;
}

export interface IButtonsGroupProps {
  handlers: (buttonType: ButtonType) => () => void;
  buttons: IButtonItem[];
}

export interface IApptDetailPreparingProps {
  checkboxGroup: CheckListDto;
  onCheck: () => void;
}

export interface ApptDetailsHandlers {
  handleBack: () => void;
  handleReschedule: () => void;
  handleReminder: () => void;
  handleCheck: () => void;
  handleSendComment: () => void;
  handleAttendAppt: () => void;
}

export interface IAppointmentDetailViewProps {
  appointment: AppointmentDetailsDto;
  timeZonePreferences: TimezoneDto;
  handlers: ApptDetailsHandlers;
}

export interface IButtonBlockProps {
  buttonGroup: IButtonItem[];
  handlers: (buttonType: ButtonType) => () => void;
  date: string;
  time: string;
  status: AppointmentStatus;
}

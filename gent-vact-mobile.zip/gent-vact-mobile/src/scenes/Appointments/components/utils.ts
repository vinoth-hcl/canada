import { filter } from 'lodash';

import dayjs from 'dayjs';
import { AppointmentStatus, AppointmentType } from '../../../services/appointments/types';
import VideoCall from '../../../../assets/images/VideoCall.svg';
import People from '../../../../assets/images/People.svg';
import Hours from '../../../../assets/images/Hours.svg';
import CalendarBlue from '../../../../assets/images/CalendarBlue.svg';
import { AppointmentDto } from '../../../api/AppointmentDto';
import { ButtonKind } from '../../../components/Button/types';
import { TimezoneDto } from '../../../api/TimezoneDto';
import { WebViews } from '../../../components/WebLayoutTemplate/WebLayoutTemplate';
import { ButtonType, IButtonItem } from './types';

export function getApptType(type: string): string {
  switch (type) {
    case AppointmentType.VIDEO: {
      return 'Video Call';
    }
    case AppointmentType.PHONE: {
      return 'Phone Call';
    }
    case AppointmentType.IN_PERSON: {
      return 'In Person';
    }
    default: {
      return '';
    }
  }
}

export function getDrName(name?: string[] | undefined): string {
  const fullName = (name && name.length > 0 && filter(name, (item) => item !== '')) || [];
  return fullName.length > 0 ? `${fullName.join(' ')}` : '';
}

export const buttonGroup: IButtonItem[] = [
  {
    type: ButtonType.ATTEND,
    Icon: VideoCall,
    buttonType: ButtonKind.MAIN_BLUE,
    title: 'Click to join your appointment',
  },
  {
    type: ButtonType.SET_HOURS,
    Icon: Hours,
    buttonType: ButtonKind.MAIN_DISABLED,
    title: 'Set reminder',
  },
  {
    type: ButtonType.PEOPLE,
    Icon: People,
    buttonType: ButtonKind.MAIN_DISABLED,
    title: 'Share with caregiver',
  },
  {
    type: ButtonType.RESCHEDULE,
    Icon: CalendarBlue,
    buttonType: ButtonKind.MAIN_WHITE,
    title: 'Reschedule my appointment',
  },
];

export function getButtonGroup(appt: AppointmentDto, isAttendButton = false): IButtonItem[] {
  const isPhoneNumber = appt.connectIds && (appt.connectIds.PHONE || appt.connectIds.VIDEO);
  if (appt.status === AppointmentStatus.SCHEDULED) {
    return isAttendButton
      ? [
          isPhoneNumber
            ? buttonGroup[0]
            : {
                ...buttonGroup[0],
                title: 'Attend appointment (No phone number)',
                buttonType: ButtonKind.MAIN_DISABLED,
              },
        ]
      : [buttonGroup[3]];
  } else {
    return [] as IButtonItem[];
  }
}

export function isAppointmentRequest(appointment: AppointmentDto) {
  return (appointment.status as any) === 'NEW';
}

export function isAppointmentStatus(appointment: AppointmentDto, status: AppointmentStatus) {
  return appointment.status === status;
}

export function getIsHeader(
  appointment: AppointmentDto,
  index: number,
  appointments: AppointmentDto[],
  startTime: string,
  timeZonePreferences: TimezoneDto,
) {
  if (
    isAppointmentRequest(appointment) ||
    isAppointmentStatus(appointment, AppointmentStatus.PARTIAL_SCHEDULED)
  ) {
    return false;
  }

  return dayjs().tz(timeZonePreferences.iana).isSame(startTime, 'day');
}

export const keyExtractor = (item: AppointmentDto) => `${item.status}:${item.id}`;
export const VIEW_CHANGE_DEBOUNCE = 1000;
export const viewabilityConfig = {
  waitForInteraction: true,
  itemVisiblePercentThreshold: 75,
};

export function getHasShowLeftSide(
  screenModel:
    | WebViews
    | WebViews.MOBILE
    | WebViews.MEDIUM
    | WebViews.SMALL
    | WebViews.TINY
    | WebViews.LARGE,
  pendingRequestPartial: boolean,
  pendingAppt: boolean,
) {
  const hasShowSmallScreen = screenModel !== WebViews.LARGE && screenModel !== WebViews.MEDIUM;
  const hasShowBigScreen = screenModel === WebViews.LARGE || screenModel === WebViews.MEDIUM;
  const hasShowLoaderIndicator =
    (hasShowBigScreen && pendingRequestPartial) ||
    (hasShowSmallScreen && (pendingAppt || pendingRequestPartial));
  return { hasShowSmallScreen, hasShowBigScreen, hasShowLoaderIndicator };
}

import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

import {
  TEXT_APPT_DETAIL_PLACEHOLDER_DESCRIPTION,
  TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_CANCELLED,
  TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_COMPLETED,
  TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_MISSED,
  TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_RESCHEDULED,
} from '../../../constants/constants';
import { AppointmentStatus } from '../../../services/appointments/types';
import { Title } from './Title';
import { IApptDetailPlaceholderProps } from './types';

function getStatusTitle(status: AppointmentStatus) {
  switch (status) {
    case AppointmentStatus.RESCHEDULED:
      return TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_RESCHEDULED;
    case AppointmentStatus.CANCELLED:
      return TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_CANCELLED;
    case AppointmentStatus.COMPLETED:
      return TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_COMPLETED;
    case AppointmentStatus.MISSED:
      return TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_MISSED;
    default:
      return '';
  }
}

export const ApptDetailPlaceholder: FunctionComponent<IApptDetailPlaceholderProps> = ({
  title,
  description,
  status,
}) => {
  const statusTitle = getStatusTitle(status);
  return (
    <Title
      title={title}
      descriptionText={description}
      style={{ header: styles.dateText, description: styles.dateText }}
    >
      <View style={styles.placeholder}>
        <Title
          title={statusTitle}
          descriptionText={statusTitle ? '' : TEXT_APPT_DETAIL_PLACEHOLDER_DESCRIPTION}
          style={{ header: styles.placeholderText, description: styles.placeholderText }}
        />
      </View>
    </Title>
  );
};

const styles = StyleSheet.create({
  dateText: {
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 24,
  },
  placeholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    fontWeight: 'normal',
    fontSize: 17,
    lineHeight: 22,
    marginTop: 25,
  },
  placeholderTextHeader: {
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

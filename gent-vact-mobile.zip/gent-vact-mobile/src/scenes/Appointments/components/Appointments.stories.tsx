import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import centered from '../../../../storybook/decorators/centered';
import { AppointmentStatus } from '../../../services/appointments/types';
import { checkboxGroupMock } from './mocks';
import { Title } from './Title';
import { ApptDetailPlaceholder } from './ApptDetailPlaceholder';
import { ButtonsGroup } from './ButtonsGroup';
import { buttonGroup } from './utils';
import { FooterInfo } from './FooterInfo';
import { ApptDetailHeader } from './ApptDetailHeader';
import { ApptDetailPreparing } from './ApptDetailPreparing';
import { ButtonBlock } from './ButtonBlock';

const TIMEZONE_PREFERENCES = { iana: 'UTC', abbreviation: 'UTC', raw: {} };

storiesOf('Appointments', module)
  .addDecorator(centered)
  // TODO: should be refactoring after
  // .add('View', () => (
  //   <AppointmentsView
  //     appointments={[] as AppointmentDto[]}
  //     handlePressAddAppt={action('handlePressAddAppt')}
  //     onApptPress={action('onApptPress')}
  //     onViewChange={action('onScroll')}
  //     onEndReached={action('onEndReached')}
  //     onRefresh={action('onRefresh')}
  //     pending={0}
  //     timeZonePreferences={TIMEZONE_PREFERENCES}
  //   />
  // ))
  // .add('View with pending', () => (
  //   <AppointmentsView
  //     appointments={[]}
  //     onViewChange={action('onScroll')}
  //     handlePressAddAppt={action('handlePressAddAppt')}
  //     onApptPress={action('onApptPress')}
  //     onEndReached={action('onEndReached')}
  //     onRefresh={action('onRefresh')}
  //     pending={1}
  //     timeZonePreferences={TIMEZONE_PREFERENCES}
  //   />
  // ))
  // .add('View with mocks', () => (
  //   <AppointmentsView
  //     appointments={APPOINTMENTS_MOCK_DATA}
  //     onViewChange={action('onScroll')}
  //     onEndReached={action('onEndReached')}
  //     onRefresh={action('onRefresh')}
  //     handlePressAddAppt={action('handlePressAddAppt')}
  //     onApptPress={action('onApptPress')}
  //     pending={0}
  //     timeZonePreferences={TIMEZONE_PREFERENCES}
  //   />
  // ))
  .add('Title', () => <Title title={'Header'} descriptionText={'Description'} />)
  .add('ButtonGroup: button choose time', () => {
    const handlers = () => () => {
      action('onPress');
    };
    return <ButtonsGroup handlers={handlers} buttons={[buttonGroup[3]]} />;
  })
  .add('ButtonGroup: all button', () => {
    const handlers = () => () => {
      action('onPress');
    };
    return <ButtonsGroup handlers={handlers} buttons={buttonGroup} />;
  })
  .add('ButtonBlock', () => {
    const handlers = () => () => {
      action('onPress');
    };
    return (
      <ButtonBlock
        buttonGroup={buttonGroup}
        handlers={handlers}
        date={'date'}
        time={'time'}
        status={AppointmentStatus.RESCHEDULED}
      />
    );
  })
  .add('ButtonBlock: no button', () => {
    const handlers = () => () => {
      action('onPress');
    };
    return (
      <ButtonBlock
        buttonGroup={[]}
        handlers={handlers}
        date={'date'}
        time={'time'}
        status={AppointmentStatus.RESCHEDULED}
      />
    );
  })
  .add('ButtonBlock: button ChooseTime', () => {
    const handlers = () => () => {
      action('onPress');
    };
    return (
      <ButtonBlock
        buttonGroup={[buttonGroup[3]]}
        handlers={handlers}
        date={'date'}
        time={'time'}
        status={AppointmentStatus.RESCHEDULED}
      />
    );
  })
  .add('FooterInfo', () => (
    <FooterInfo
      onPressConnect={action('onPress handlePressAddAppt')}
      onPressTelehealth={action('onPress handlePressAddAppt')}
    />
  ))
  .add('ApptDetailPlaceholder', () => (
    <ApptDetailPlaceholder
      title={'Header'}
      description={'Description'}
      status={AppointmentStatus.RESCHEDULED}
    />
  ))
  .add('ApptDetailPlaceholder: video', () => (
    <ApptDetailHeader
      name={'Brown'}
      startTime={''}
      endTime={''}
      status={AppointmentStatus.RESCHEDULED}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('ApptDetailPlaceholder: phone', () => (
    <ApptDetailHeader
      name={'Brown'}
      startTime={''}
      endTime={''}
      status={AppointmentStatus.RESCHEDULED}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('ApptDetailPlaceholder: in_person', () => (
    <ApptDetailHeader
      name={'Brown'}
      startTime={''}
      endTime={''}
      status={AppointmentStatus.RESCHEDULED}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('ApptDetailPreparing', () => {
    const handleCheck = () => {
      action('onPress');
    };
    return <ApptDetailPreparing onCheck={handleCheck} checkboxGroup={checkboxGroupMock} />;
  });

import React, { FunctionComponent, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { get, first } from 'lodash';
import { SafeAreaView, StyleSheet, View } from 'react-native';

import dayjs from 'dayjs';
import {
  getAppointmentRequests,
  getAppointments,
  getPartialAppointments,
  setFirstVisibleAppointment,
} from '../../services/appointments/actions';
import {
  getAppointmentsPaginationStatus,
  getAppointmentsPending,
  getAppointmentRequestsSelector,
  getPartialAppointmentsSelector,
  getActualAppointmentsSelector,
  getAppointmentsRequestPartialPending,
} from '../../services/appointments/selector';
import { AppointmentDto } from '../../api/AppointmentDto';
import { AppointmentStatus, FETCH_APPOINTMENTS_PAGE_SIZE } from '../../services/appointments/types';
import { appRoute } from '../../app/actions';
import { APPT_ROUTES, MODAL_ROUTES } from '../../navigation/routes';
import { getPatientTimezone } from '../../app/selectors';
import { SAFE_AREA_COLOR } from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { AppointmentsView } from './components/AppointmentsView';

export const Appointments: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();

  const actualAppointments = useSelector(getActualAppointmentsSelector);
  const partialAppointments = useSelector(getPartialAppointmentsSelector);
  const appointmentRequests = useSelector(getAppointmentRequestsSelector);
  const pendingAppt = useSelector(getAppointmentsPending);
  const pendingRequestPartial = useSelector(getAppointmentsRequestPartialPending);
  const paginationStatus = useSelector(getAppointmentsPaginationStatus);
  const patientTimeZonePreferences = useSelector(getPatientTimezone);
  const startTimeMin = dayjs().tz(patientTimeZonePreferences.iana).startOf('day').format();

  const onApptPress = useCallback(
    (appointment: AppointmentDto) => {
      const { id, status } = appointment;
      if (status === AppointmentStatus.PARTIAL_SCHEDULED) {
        dispatch(appRoute(MODAL_ROUTES.SCHEDULING_WITH_TIME_SLOT, { id }));
      } else {
        dispatch(appRoute(APPT_ROUTES.DETAIL, { id }));
      }
    },
    [dispatch],
  );

  const onViewChange = useCallback(
    (items: AppointmentDto[]) => {
      const id = get(first(items), 'id', '');
      dispatch(setFirstVisibleAppointment(id));
    },
    [dispatch],
  );

  const onEndReached = useCallback(() => {
    const { page } = paginationStatus;
    if (pendingAppt || pendingRequestPartial) {
      return;
    }
    dispatch(
      getAppointments({ page: page + 1, size: FETCH_APPOINTMENTS_PAGE_SIZE }, false, startTimeMin),
    );
  }, [dispatch, paginationStatus, pendingRequestPartial, pendingAppt, startTimeMin]);

  const onRefreshAppt = useCallback(() => {
    if (pendingAppt) {
      return;
    }
    dispatch(getAppointments({ page: 0, size: FETCH_APPOINTMENTS_PAGE_SIZE }, true, startTimeMin));
  }, [dispatch, pendingAppt, startTimeMin]);

  const onRefreshRequestPartial = useCallback(() => {
    if (pendingRequestPartial) {
      return;
    }
    dispatch(getPartialAppointments());
    dispatch(getAppointmentRequests());
  }, [dispatch, pendingRequestPartial]);

  const handlePressAddAppt = useCallback(() => {
    dispatch(appRoute(MODAL_ROUTES.REQUEST_REASON));
  }, [dispatch]);

  return (
    <SafeAreaView style={styles.safeView}>
      <View style={styles.container}>
        <AppointmentsView
          actualApps={actualAppointments}
          partialApps={partialAppointments}
          requestApps={appointmentRequests}
          timeZonePreferences={patientTimeZonePreferences}
          handlePressAddAppt={handlePressAddAppt}
          onApptPress={onApptPress}
          onViewChange={onViewChange}
          onEndReached={onEndReached}
          onRefreshAppt={onRefreshAppt}
          onRefreshRequestPartial={onRefreshRequestPartial}
          pendingAppt={pendingAppt}
          pendingRequestPartial={pendingRequestPartial}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeView: {
    width: '100%',
    height: '100%',
    backgroundColor: SAFE_AREA_COLOR,
  },
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: Colors.white,
  },
});

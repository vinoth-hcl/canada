import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { TEXT_CONTACT_ADMINISTRATOR, TEXT_FORBIDDEN, TEXT_LOGIN } from '../../constants/constants';
import { Button } from '../../components/Button/Button';
import { Colors } from '../../utilities/design';
import { ButtonKind } from '../../components/Button/types';

export interface ForbiddenViewProps {
  handleLogin: () => void;
}

export const ForbiddenView: FunctionComponent<ForbiddenViewProps> = ({ handleLogin }) => {
  return (
    <View style={styles.container}>
      <View style={styles.textBox}>
        <Text style={styles.info}>{TEXT_FORBIDDEN}</Text>
        <Text style={styles.contact}>{TEXT_CONTACT_ADMINISTRATOR}</Text>
      </View>
      <Button
        kind={ButtonKind.MAIN_BLUE}
        onPress={handleLogin}
        text={TEXT_LOGIN}
        style={{
          container: styles.loginButton,
        }}
      />
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 56,
    paddingBottom: 51,
    paddingLeft: 52,
    paddingRight: 52,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: Colors.lightGrey,
  },
  textBox: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  info: {
    fontSize: 40,
    color: Colors.red,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 40,
  },
  contact: {
    fontSize: 24,
    color: Colors.middleBlack,
    textAlign: 'center',
    fontWeight: 'bold',
  },
  loginButton: {
    width: 269,
    justifyContent: 'center',
  },
});

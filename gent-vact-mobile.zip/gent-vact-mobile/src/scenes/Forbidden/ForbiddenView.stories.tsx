import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import centered from '../../../storybook/decorators/centered';
import { ForbiddenView } from './ForbiddenView';

storiesOf('Forbidden', module)
  .addDecorator(centered)
  .add('view', () => <ForbiddenView handleLogin={action('onLogin')} />);

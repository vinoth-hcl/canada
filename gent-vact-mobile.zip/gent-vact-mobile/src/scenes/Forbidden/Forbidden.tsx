import { FunctionComponent, useCallback } from 'react';
import { useDispatch } from 'react-redux';

import { AUTH_ROUTES } from '../../navigation/routes';
import { appRoute } from '../../app/actions';
import { ForbiddenView } from './ForbiddenView';

export const Forbidden: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();

  const handleLogin = useCallback(() => {
    dispatch(appRoute(AUTH_ROUTES.LOGIN));
  }, [dispatch]);

  return ForbiddenView({ handleLogin });
};

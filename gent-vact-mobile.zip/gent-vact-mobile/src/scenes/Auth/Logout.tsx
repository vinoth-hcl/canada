import React, { FunctionComponent, useCallback, useEffect, useRef, useState } from 'react';
import { Platform, StatusBar, StyleSheet, Text, View } from 'react-native';
import { WebView, WebViewNavigation } from 'react-native-webview';
import { useDispatch } from 'react-redux';

import { Colors } from '../../utilities/design';
import { AUTH_ROUTES, TAB_ROUTES } from '../../navigation/routes';
import { appAuthState, appLog, appRoute, clearPersistedStore } from '../../app/actions';
import {
  DEVICE_HEIGHT,
  DEVICE_WIDTH,
  OS_ANDROID,
  TEXT_CANCEL_BUTTON,
  TEXT_CONNECTING_AUTH_SERVER,
} from '../../constants/constants';
import { Button } from '../../components/Button/Button';
import { clearSession } from '../../services/authentication/getTokens';
import { AppAuthState } from '../../app/types';
import { removeKeychain, setAuthTokens } from '../../services/info/actions';
import { ConnectionState } from './types';
import { API_URL, getLogoutUri, LOGOUT_REDIRECT_URI } from './utils';

const SHOW_CANCEL_TIMEOUT = 30 * 1000;
const logoutUri = getLogoutUri(API_URL, LOGOUT_REDIRECT_URI);

export const Logout: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();

  const [connectState, setConnectState] = useState(ConnectionState.InProgress);

  const viewRef = useRef<WebView>();
  const onRef = useCallback(
    (ref) => {
      viewRef.current = ref;
    },
    [viewRef],
  );
  useEffect(() => {
    dispatch(appAuthState(AppAuthState.INITIAL));
    dispatch(setAuthTokens('', ''));
    dispatch(removeKeychain());
  }, [dispatch]);

  const onNavigationStateChange = useCallback(
    (state: WebViewNavigation) => {
      dispatch(appLog('webView state', state));
      if (state.url === `${LOGOUT_REDIRECT_URI}/`) {
        if (viewRef.current) {
          viewRef.current.stopLoading();
        }
        setConnectState(ConnectionState.Connected);
        dispatch(appAuthState(AppAuthState.INITIAL));
        dispatch(clearPersistedStore());
        clearSession();
        dispatch(appRoute(AUTH_ROUTES.WELCOME));
      }
    },
    [dispatch],
  );

  const [showLogout, setShowLogout] = useState(false);
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setShowLogout(true);
    }, SHOW_CANCEL_TIMEOUT);
    return () => {
      clearTimeout(timeoutId);
    };
  }, []);

  const handleCancel = useCallback(() => {
    dispatch(appRoute(TAB_ROUTES.DASHBOARD));
  }, [dispatch]);

  return (
    <View style={styles.container}>
      <StatusBar translucent={true} hidden={true} animated={true} />
      <WebView
        ref={onRef}
        source={{ uri: logoutUri }}
        style={styles.web}
        incognito={Platform.OS === OS_ANDROID ? true : false}
        cacheMode={'LOAD_NO_CACHE'}
        onNavigationStateChange={onNavigationStateChange}
      />
      {connectState === ConnectionState.InProgress && (
        <Text style={styles.connect}>{TEXT_CONNECTING_AUTH_SERVER}</Text>
      )}
      {connectState !== ConnectionState.Connected && showLogout && (
        <Button
          onPress={handleCancel}
          text={TEXT_CANCEL_BUTTON}
          style={{ container: styles.cancelButton }}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    flexDirection: 'column',
    backgroundColor: Colors.grey,
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginBottom: 0,
  },
  web: {
    width: DEVICE_WIDTH,
    height: DEVICE_HEIGHT - 20,
    backgroundColor: Colors.grey,
  },
  connect: {
    textAlign: 'center',
    position: 'absolute',
    top: '30%',
  },
  cancelButton: {
    width: 269,
    position: 'absolute',
    bottom: 10,
    backgroundColor: Colors.blue,
  },
});

import { API_AUTHENTICATE_ENDPOINT, API_LOGOUT_ENDPOINT } from '../../api/endpoints';
import { getAuthUri, getLogoutUri } from './utils';

describe('Auth utils tests', () => {
  describe('getAuthUri test', () => {
    it('should return string', () => {
      const mockUrl: string = 'Url';
      const mockRedirect: string = 'Redirect';
      const result: string = `${mockUrl}${API_AUTHENTICATE_ENDPOINT}?redirectUrl=${mockRedirect}`;
      expect(getAuthUri(mockUrl, mockRedirect)).toBe(result);
    });
  });

  describe('getLogoutUri test', () => {
    it('should return string', () => {
      const mockUrl: string = 'Url';
      const mockRedirect: string = 'Redirect';
      const result: string = `${mockUrl}${API_LOGOUT_ENDPOINT}?redirectUrl=${mockRedirect}`;
      expect(getLogoutUri(mockUrl, mockRedirect)).toBe(result);
    });
  });
});

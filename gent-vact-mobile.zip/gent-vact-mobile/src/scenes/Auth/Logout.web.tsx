import React, { FunctionComponent, useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useDispatch } from 'react-redux';

import { getApiURL } from '../../utilities/config';
import { TEXT_CONNECTING_AUTH_SERVER } from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { clearPersistedStore } from '../../app/actions';
import { clearSession } from '../../services/authentication/getTokens';
import { getLogoutUri, WEB_API_URL } from './utils';

export const doLogout = async () => {
  // @ts-ignore
  window.location.assign(getLogoutUri(getApiURL(), WEB_API_URL));
};

export const Logout: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(clearPersistedStore());
    clearSession();
    doLogout();
  }, [dispatch]);

  return (
    <View style={styles.container}>
      <View style={styles.connect}>
        <Text>{TEXT_CONNECTING_AUTH_SERVER}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.grey,
    marginBottom: 0,
  },
  connect: {
    textAlign: 'center',
    position: 'absolute',
    top: '30%',
  },
});

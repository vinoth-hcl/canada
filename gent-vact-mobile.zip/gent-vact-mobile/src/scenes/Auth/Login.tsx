import React, { FunctionComponent, useCallback, useEffect, useRef, useState } from 'react';
import { Platform, StatusBar, StyleSheet, Text, View } from 'react-native';
import { WebView, WebViewNavigation } from 'react-native-webview';
import { useDispatch } from 'react-redux';

import { Colors } from '../../utilities/design';
import { AUTH_ROUTES } from '../../navigation/routes';
import { appAuthState, appLog, appLoginSuccess, appRoute, replaceRoute } from '../../app/actions';
import { AppAuthState, LogLevel } from '../../app/types';
import {
  DEVICE_HEIGHT,
  DEVICE_WIDTH,
  OS_ANDROID,
  TEXT_CANNOT_CONNECT_SERVER,
  TEXT_CONNECTING_AUTH_SERVER,
  TEXT_RELOGIN,
} from '../../constants/constants';
import { Button } from '../../components/Button/Button';
import { fetchPatientProfile } from '../../services/patient/actions';
import { useTimeout } from '../../utilities/hooks';
import { testId } from '../../utilities/TestId';
import { clearSession, getTokens } from '../../services/authentication/getTokens';
import { ITokens } from '../../services/authentication/types';
import { track } from '../../services/metrics/actions';
import { METRIC_EVENTS } from '../../services/metrics/types';
import { setAuthTokens, setKeychain } from '../../services/info/actions';
import { setTimezone } from '../../services/options/actions';
import { ConnectionState } from './types';
import { API_URL, getAuthUri, LOGIN_REDIRECT_URI } from './utils';

const authUri = getAuthUri(API_URL, LOGIN_REDIRECT_URI);
const LOG_NAME = 'take tokens';
const SHOW_LOGIN_TIMEOUT = 30 * 1000;

export const Login: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();

  const [connectState, setConnectState] = useState(ConnectionState.InProgress);
  const [isKeyboard, setIsKeyboard] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  const handleShowLoginTimeout = useTimeout(() => {
    setShowLogin(true);
  }, SHOW_LOGIN_TIMEOUT);

  useEffect(() => {
    dispatch(appAuthState(AppAuthState.IN_PROGRESS));
    dispatch(appLog('redirect Uri', authUri));
  }, [dispatch]);

  const viewRef = useRef<WebView>();
  const onRef = useCallback(
    (ref) => {
      viewRef.current = ref;
    },
    [viewRef],
  );

  const onNavigationStateChange = useCallback(
    (state: WebViewNavigation) => {
      handleShowLoginTimeout.start();
      dispatch(appLog('webView state', state));
      if (state.url === authUri && !state.loading) {
        setConnectState(ConnectionState.Error);
        dispatch(appAuthState(AppAuthState.INITIAL));
        dispatch(replaceRoute(AUTH_ROUTES.MODAL_NAVIGATOR));
        dispatch(
          appRoute(AUTH_ROUTES.SOMETHING_WENT_WRONG, {
            message: TEXT_CANNOT_CONNECT_SERVER,
          }),
        );
      } else if (state.url === `${API_URL}/`) {
        if (viewRef.current) {
          viewRef.current.stopLoading();
        }
        setIsKeyboard(true);
        handleShowLoginTimeout.clean();
        setConnectState(ConnectionState.LoggedIn);

        getTokens()
          .then((tokens: ITokens | null) => {
            if (tokens) {
              const { access_token, refresh_token } = tokens;

              dispatch(setKeychain(access_token, refresh_token));
              dispatch(setAuthTokens(access_token, refresh_token));
              clearSession();
              dispatch(
                fetchPatientProfile(
                  [
                    appAuthState(AppAuthState.AUTHENTICATED),
                    setTimezone(),
                    appLoginSuccess(),
                    track(METRIC_EVENTS.LOGIN),
                    replaceRoute(AUTH_ROUTES.MODAL_NAVIGATOR),
                  ],
                  replaceRoute(AUTH_ROUTES.FORBIDDEN),
                  access_token,
                ),
              );
            }
          })
          .catch((err) => {
            dispatch(appLog(LOG_NAME, err, LogLevel.ERROR));
          });
      } else if (state.title === 'Signin') {
        setConnectState(ConnectionState.Connected);
      } else if (state.title !== 'Signin') {
        setConnectState(ConnectionState.InProgress);
      }
    },
    [dispatch, handleShowLoginTimeout],
  );

  const handleLogin = useCallback(() => {
    dispatch(appAuthState(AppAuthState.INITIAL));
    dispatch(replaceRoute(AUTH_ROUTES.MODAL_NAVIGATOR));
    dispatch(appRoute(AUTH_ROUTES.WELCOME));
  }, [dispatch]);
  return (
    <View style={styles.container}>
      <StatusBar translucent={true} hidden={true} animated={true} />
      {connectState !== ConnectionState.LoggedIn && (
        <WebView
          ref={onRef}
          source={{ uri: authUri }}
          style={styles.web}
          thirdPartyCookiesEnabled
          sharedCookiesEnabled
          useSharedProcessPool
          cacheMode={'LOAD_NO_CACHE'}
          incognito={Platform.OS === OS_ANDROID ? true : false}
          onNavigationStateChange={onNavigationStateChange}
          hideKeyboardAccessoryView={isKeyboard}
          {...testId('WebViewLoginPage')}
        />
      )}
      {(connectState === ConnectionState.InProgress ||
        connectState === ConnectionState.LoggedIn) && (
        <Text style={styles.connect}>{TEXT_CONNECTING_AUTH_SERVER}</Text>
      )}
      {connectState !== ConnectionState.Connected && showLogin && (
        <Button
          onPress={handleLogin}
          text={TEXT_RELOGIN}
          style={{
            container: styles.loginButton,
          }}
          testID={'ReLogin'}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    flexDirection: 'column',
    backgroundColor: Colors.grey,
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginBottom: 0,
  },
  web: {
    width: DEVICE_WIDTH,
    height: DEVICE_HEIGHT - 20,
    backgroundColor: Colors.grey,
  },
  connect: {
    textAlign: 'center',
    position: 'absolute',
    top: '30%',
  },
  loginButton: {
    width: 269,
    position: 'absolute',
    bottom: 10,
    alignSelf: 'center',
    backgroundColor: Colors.blue,
  },
});

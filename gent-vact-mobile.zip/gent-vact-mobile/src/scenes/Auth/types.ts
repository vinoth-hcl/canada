import { SensorType } from '../../components/Sensor/types';

export enum ConnectionState {
  InProgress,
  Connected,
  LoggedIn,
  Error,
}

export const SensorName: { [key: string]: string } = {
  [SensorType.HEART_RATE]: 'heart rate',
  [SensorType.TEMPERATURE]: 'temperature',
  [SensorType.PRESSURE]: 'pressure',
};

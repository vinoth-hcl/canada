// import config from 'react-native-config';
import config from '../../app/config';
import { API_AUTHENTICATE_ENDPOINT, API_LOGOUT_ENDPOINT } from '../../api/endpoints';

export const API_URL = config.API_URL;
export const LOGIN_REDIRECT_URI = config.LOGIN_REDIRECT_URI;
export const LOGOUT_REDIRECT_URI = config.LOGOUT_REDIRECT_URI;
export const WEB_API_URL = config.WEB_API_URL;

export function getAuthUri(url: string, redirectUrl: string): string {
  return `${url}${API_AUTHENTICATE_ENDPOINT}?redirectUrl=${redirectUrl}`;
}

export function getLogoutUri(url: string, redirectUrl: string): string {
  return `${url}${API_LOGOUT_ENDPOINT}?redirectUrl=${redirectUrl}`;
}

import { StyleSheet, Text, View } from 'react-native';
import React, { FunctionComponent, useEffect } from 'react';

import { useDispatch } from 'react-redux';
import { TEXT_CONNECTING_AUTH_SERVER } from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { getApiURL } from '../../utilities/config';
import { clearPersistedStore } from '../../app/actions';
import { clearSession } from '../../services/authentication/getTokens';
import { removeKeychain } from '../../services/info/actions';
import { getAuthUri } from './utils';

function doLogin() {
  // @ts-ignore
  window.location.assign(getAuthUri(getApiURL(), window.location.href));
}

export const Login: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(clearPersistedStore());
    dispatch(removeKeychain());
    clearSession();
    setTimeout(doLogin, 1000);
  }, [dispatch]);

  return (
    <View style={styles.container}>
      <View style={styles.connect}>
        <Text>{TEXT_CONNECTING_AUTH_SERVER}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.grey,
    marginBottom: 0,
  },
  connect: {
    textAlign: 'center',
    position: 'absolute',
    top: '30%',
  },
});

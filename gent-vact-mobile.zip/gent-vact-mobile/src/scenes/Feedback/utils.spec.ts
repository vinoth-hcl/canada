import { ButtonKind } from '../../components/Button/types';
import { getButtonKind } from './utils';

describe('Feedback utils tests', () => {
  describe('getButtonKind test', () => {
    it('should return ButtonKind.BLUE if true', () => {
      expect(getButtonKind(true)).toBe(ButtonKind.BLUE);
    });

    it('should return ButtonKind.WHITE if false', () => {
      expect(getButtonKind(false)).toBe(ButtonKind.LIGHTGREY);
    });
  });
});

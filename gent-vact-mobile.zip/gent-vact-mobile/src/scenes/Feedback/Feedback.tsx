import { FunctionComponent, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TEXT_SKIP_BUTTON, TEXT_SUBMIT_BUTTON } from '../../constants/constants';
import { MODAL_ROUTES } from '../../navigation/routes';
import { appRoute } from '../../app/actions';
import { FeedbackMockDto } from '../../services/feedback/mock/FeedbackMockDto';
import { getQuestionsFeedback, isAnswerQuestion } from '../../services/feedback/selector';
import { addAnswerFeedbackById, checkAnswerFeedback } from '../../services/feedback/actions';
import { getButtonKind } from './utils';
import { FeedbackView } from './FeedbackView';

export const Feedback: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();

  const quiz = useSelector(getQuestionsFeedback);
  const hasSubmit = useSelector(isAnswerQuestion);

  const handleButton = useCallback(() => {
    dispatch(checkAnswerFeedback(appRoute(MODAL_ROUTES.HOME)));
  }, [dispatch]);

  const buttonKind = getButtonKind(hasSubmit);
  const buttonText = hasSubmit ? TEXT_SUBMIT_BUTTON : TEXT_SKIP_BUTTON;

  const handleOnEdit = useCallback(
    (question: FeedbackMockDto) => {
      dispatch(addAnswerFeedbackById(question));
    },
    [dispatch],
  );

  return FeedbackView({ quiz, handleOnEdit, handleButton, buttonText, buttonKind });
};

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import centered from '../../../storybook/decorators/centered';
import { TEXT_SUBMIT_BUTTON } from '../../constants/constants';
import { ButtonKind } from '../../components/Button/types';
import { FeedbackView } from './FeedbackView';
import { Grade } from './types';

storiesOf('Feedback', module)
  .addDecorator(centered)
  .add('view', () => (
    <FeedbackView
      quiz={[
        {
          Id: '1',
          question: 'Do you like the application?',
          answer: Grade.HAPPY,
        },
        {
          Id: '2',
          question: 'Do you like the service?',
        },
      ]}
      handleOnEdit={action('edit')}
      handleButton={action('submit')}
      buttonText={TEXT_SUBMIT_BUTTON}
      buttonKind={ButtonKind.BLUE}
    />
  ));

import { ButtonKind } from '../../components/Button/types';

export const getButtonKind = (isAnswer: boolean): ButtonKind => {
  return isAnswer ? ButtonKind.BLUE : ButtonKind.LIGHTGREY;
};

export enum Grade {
  ANGRY = 'ANGRY',
  SAD = 'SAD',
  SCEPTIC = 'SCEPTIC',
  HAPPY = 'HAPPY',
  VERY_HAPPY = 'VERY_HAPPY',
}

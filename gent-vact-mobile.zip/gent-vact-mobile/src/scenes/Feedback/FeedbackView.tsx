import { FlatList, StyleSheet, Text, View } from 'react-native';
import React, { FunctionComponent, useCallback } from 'react';
import { Colors } from '../../utilities/design';
import { FeedbackMockDto } from '../../services/feedback/mock/FeedbackMockDto';
import { ButtonKind } from '../../components/Button/types';
import { Question } from '../../components/Question/Question';
import { TEXT_FEEDBACK_HEADER } from '../../constants/constants';
import { Button } from '../../components/Button/Button';

const keyExtractor = (item: FeedbackMockDto) => item.Id;

export interface FeedbackViewProps {
  quiz: FeedbackMockDto[];
  handleButton: () => void;
  handleOnEdit: (question: FeedbackMockDto) => void;
  buttonText: string;
  buttonKind: ButtonKind;
}

export const FeedbackView: FunctionComponent<FeedbackViewProps> = ({
  quiz,
  handleButton,
  handleOnEdit,
  buttonText,
  buttonKind,
}) => {
  const renderItem = useCallback(
    ({ item }: { item: FeedbackMockDto }) => {
      return <Question quiz={item} onEdit={handleOnEdit} />;
    },
    [handleOnEdit],
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>{TEXT_FEEDBACK_HEADER}</Text>
      <FlatList
        data={quiz}
        horizontal={false}
        showsVerticalScrollIndicator={false}
        keyExtractor={keyExtractor}
        renderItem={renderItem}
      />
      <Button
        onPress={handleButton}
        text={buttonText}
        kind={buttonKind}
        style={{
          container: styles.button,
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 56,
    paddingBottom: 44,
    paddingLeft: 54,
    paddingRight: 54,
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.lightGrey,
  },
  header: {
    width: 260,
    height: 85,
    fontWeight: '500',
    fontSize: 24,
    lineHeight: 42,
    textAlign: 'left',
    color: Colors.grey,
  },
  button: {
    marginTop: 10,
    width: 269,
  },
});

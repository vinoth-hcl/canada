import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import RNExitApp from 'react-native-exit-app';
import { Colors } from '../../utilities/design';
import { ModalSingleButton } from '../Modal/ModalSingleButton';
import { ModalType } from '../Modal/ModalContent';
import { TEXT_ROOTED_DEVICE } from '../../constants/constants';

export const DeniedAppPage: FunctionComponent<{}> = () => {
  return (
    <View style={styles.overlay}>
      <ModalSingleButton
        type={ModalType.ERROR}
        message={TEXT_ROOTED_DEVICE}
        onPress={RNExitApp.exitApp}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: Colors.greyDark,
  },
});

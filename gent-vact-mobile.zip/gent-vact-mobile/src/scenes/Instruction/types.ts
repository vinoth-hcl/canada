import React from 'react';
import { FormattedString } from '../../components/FormattedText/types';

export interface InstructionHandlers {
  handleBack: () => void;
  handleGoIt: () => void;
  handlePressCall: (numberPhone: string) => void;
  handleChangeRing: () => void;
  handleOpenApp: () => void;
  changePage: (nextPage: string) => void;
  handlePressLink: (routeName: string, params?: any) => void;
}

export interface IFAQInstruction {
  question: string;
  answer: string;
}

export interface IElementInstruction {
  description: string | FormattedString;
  descriptionAdditional?: string;
  Icon?: React.ElementType;
  backgroundColor?: string;
  link?: string;
  route?: string;
  header?: string;
  points?: string[];
  buttonLabel?: string;
}

export enum INSTRUCTION {
  CHARGE = 'CHARGE',
  CHARGE_DETAIL = 'CHARGE_DETAIL',
  CHANGE_DETAIL = 'CHANGE_DETAIL',
  SYNC = 'SYNC',
  SYNC_DETAIL = 'SYNC_DETAIL',
  INITIAL = 'INITIAL',
  ABOUT_TRIAL = 'ABOUT_TRIAL',
  FINISH = 'FINISH',
}

export interface InstructionData {
  type: INSTRUCTION;
  header: string;
  elements: IElementInstruction[];
  description?: string;
  descriptionAdditional?: string;
  Icon?: React.ElementType;
  title?: string;
  titleInstruction?: string;
  faq?: IFAQInstruction[];
}

export interface IInstructionPage {
  data: InstructionData;
  handlers: InstructionHandlers;
  contactList?: any[];
  code?: string;
}

export interface IInstructionViewDetailProps extends IInstructionPage {}

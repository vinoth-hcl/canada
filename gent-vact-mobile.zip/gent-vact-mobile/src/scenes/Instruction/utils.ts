import ChargedIn from '../../../assets/images/oura/ChargedIn.svg';
import { Colors } from '../../utilities/design';
import ChargedHalf from '../../../assets/images/oura/ChargedHalf.svg';
import ChargedFull from '../../../assets/images/oura/ChargedFull.svg';
import { TAB_ROUTES } from '../../navigation/routes';
import SyncApp from '../../../assets/images/oura/SyncApp.svg';
import SyncProcess from '../../../assets/images/oura/SyncProcess.svg';
import Ring from '../../../assets/images/oura/Ring.svg';
import SyncOura from '../../../assets/images/oura/SyncOura.svg';
import ChargingBattery from '../../../assets/images/oura/ChargingBattery.svg';
import ModalSuccess from '../../../assets/images/ModalSuccess.svg';
import {
  FAQ_CHARGING_OURA,
  FAQ_SYNCING_OURA,
  TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_FOUR,
  TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_ONE,
  TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_THREE,
  TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_TWO,
  TEXT_INSTRUCTION_ARTICLE_HEADER_FOUR,
  TEXT_INSTRUCTION_ARTICLE_HEADER_ONE,
  TEXT_INSTRUCTION_ARTICLE_HEADER_THREE,
  TEXT_INSTRUCTION_ARTICLE_HEADER_TWO,
  TEXT_INSTRUCTION_ARTICLE_THREE_POINT_FIVE,
  TEXT_INSTRUCTION_ARTICLE_THREE_POINT_FOUR,
  TEXT_INSTRUCTION_ARTICLE_THREE_POINT_ONE,
  TEXT_INSTRUCTION_ARTICLE_THREE_POINT_THREE,
  TEXT_INSTRUCTION_ARTICLE_THREE_POINT_TWO,
  TEXT_INSTRUCTION_BUTTON_CALL,
  TEXT_INSTRUCTION_BUTTON_RING_SIZE,
  TEXT_INSTRUCTION_CHANGE_RING_SIZE_FIVE,
  TEXT_INSTRUCTION_CHANGE_RING_SIZE_FOUR,
  TEXT_INSTRUCTION_CHANGE_RING_SIZE_ONE,
  TEXT_INSTRUCTION_CHANGE_RING_SIZE_THREE,
  TEXT_INSTRUCTION_CHANGE_RING_SIZE_TWO,
  TEXT_INSTRUCTION_MESSAGE_DESC_ADD,
  TEXT_INSTRUCTION_MESSAGE_DESC_ONE,
  TEXT_INSTRUCTION_MESSAGE_DESC_THREE,
  TEXT_INSTRUCTION_MESSAGE_DESC_TWO,
  TEXT_INSTRUCTION_MESSAGE_TITLE,
  TEXT_INSTRUCTION_OURA,
  TEXT_INSTRUCTION_OURA_CHANGING_DETAIL_ADD_DESCRIPTION,
  TEXT_INSTRUCTION_OURA_CHANGING_DETAIL_DESCRIPTION,
  TEXT_INSTRUCTION_OURA_CHANGING_HEADER,
  TEXT_INSTRUCTION_OURA_CHARGING_DESCRIPTION,
  TEXT_INSTRUCTION_OURA_CHARGING_DETAIL_DESCRIPTION,
  TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_ONE,
  TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_THREE,
  TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_TWO,
  TEXT_INSTRUCTION_OURA_CHARGING_HEADER,
  TEXT_INSTRUCTION_OURA_FAQ_TITLE,
  TEXT_INSTRUCTION_OURA_HOME_PAGE_CHARGING_DESCRIPTION,
  TEXT_INSTRUCTION_OURA_HOME_PAGE_LINK,
  TEXT_INSTRUCTION_OURA_HOME_PAGE_SYNCING_DESCRIPTION,
  TEXT_INSTRUCTION_OURA_OPEN_APP,
  TEXT_INSTRUCTION_OURA_RING,
  TEXT_INSTRUCTION_OURA_SYNCING_DESCRIPTION,
  TEXT_INSTRUCTION_OURA_SYNCING_DETAIL_DESCRIPTION,
  TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_DESCRIPTION_STEP_ONE,
  TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_DESCRIPTION_STEP_TWO,
  TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_LINK_STEP_ONE,
  TEXT_INSTRUCTION_OURA_SYNCING_HEADER,
  TEXT_INSTRUCTION_TRIAL_TITLE,
  TEXT_THANKS,
} from '../../constants/constants';
import { IElementInstruction, INSTRUCTION, InstructionData } from './types';

const getElementsByInstructionType = (type: INSTRUCTION): IElementInstruction[] => {
  switch (type) {
    case INSTRUCTION.CHARGE:
    case INSTRUCTION.CHARGE_DETAIL: {
      return [
        {
          description: TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_ONE,
          Icon: ChargedIn,
          backgroundColor: Colors.gold,
        },
        {
          description: TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_TWO,
          Icon: ChargedHalf,
          backgroundColor: Colors.newBlue,
        },
        {
          description: TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_THREE,
          Icon: ChargedFull,
          backgroundColor: Colors.green,
        },
      ];
    }
    case INSTRUCTION.SYNC:
    case INSTRUCTION.SYNC_DETAIL: {
      return [
        {
          description: TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_DESCRIPTION_STEP_ONE,
          Icon: SyncApp,
          backgroundColor: Colors.newBlue,
          link: TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_LINK_STEP_ONE,
          route: TAB_ROUTES.DASHBOARD,
        },
        {
          description: TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_DESCRIPTION_STEP_TWO,
          Icon: SyncProcess,
          backgroundColor: Colors.green,
        },
      ];
    }
    case INSTRUCTION.CHANGE_DETAIL: {
      return [
        {
          description: TEXT_INSTRUCTION_CHANGE_RING_SIZE_ONE,
          descriptionAdditional: TEXT_INSTRUCTION_CHANGE_RING_SIZE_TWO,
        },
        {
          description: TEXT_INSTRUCTION_CHANGE_RING_SIZE_THREE,
          buttonLabel: TEXT_INSTRUCTION_BUTTON_RING_SIZE,
        },
        {
          description: TEXT_INSTRUCTION_CHANGE_RING_SIZE_FOUR,
          descriptionAdditional: TEXT_INSTRUCTION_CHANGE_RING_SIZE_FIVE,
          buttonLabel: TEXT_INSTRUCTION_BUTTON_CALL,
          link: TEXT_INSTRUCTION_OURA_OPEN_APP,
        },
      ];
    }
    case INSTRUCTION.FINISH: {
      return [
        {
          header: TEXT_INSTRUCTION_MESSAGE_TITLE,
          description: [
            {
              text: TEXT_INSTRUCTION_MESSAGE_DESC_ONE,
            },
            { text: TEXT_INSTRUCTION_MESSAGE_DESC_TWO, isBold: true },
            {
              text: TEXT_INSTRUCTION_MESSAGE_DESC_THREE,
            },
          ],
          descriptionAdditional: TEXT_INSTRUCTION_MESSAGE_DESC_ADD,
        },
      ];
    }
    case INSTRUCTION.ABOUT_TRIAL: {
      return [
        {
          header: TEXT_INSTRUCTION_ARTICLE_HEADER_ONE,
          description: TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_ONE,
        },
        {
          header: TEXT_INSTRUCTION_ARTICLE_HEADER_TWO,
          description: TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_TWO,
        },
        {
          header: TEXT_INSTRUCTION_ARTICLE_HEADER_THREE,
          description: TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_THREE,
          points: [
            TEXT_INSTRUCTION_ARTICLE_THREE_POINT_ONE,
            TEXT_INSTRUCTION_ARTICLE_THREE_POINT_TWO,
            TEXT_INSTRUCTION_ARTICLE_THREE_POINT_THREE,
            TEXT_INSTRUCTION_ARTICLE_THREE_POINT_FOUR,
            TEXT_INSTRUCTION_ARTICLE_THREE_POINT_FIVE,
          ],
        },
        {
          header: TEXT_INSTRUCTION_ARTICLE_HEADER_FOUR,
          description: TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_FOUR,
        },
      ];
    }
    default: {
      return [
        {
          description: TEXT_INSTRUCTION_OURA_HOME_PAGE_SYNCING_DESCRIPTION,
          Icon: SyncOura,
          link: TEXT_INSTRUCTION_OURA_HOME_PAGE_LINK,
          route: INSTRUCTION.SYNC,
          header: TEXT_INSTRUCTION_OURA_SYNCING_HEADER,
        },
        {
          description: TEXT_INSTRUCTION_OURA_HOME_PAGE_CHARGING_DESCRIPTION,
          Icon: ChargingBattery,
          link: TEXT_INSTRUCTION_OURA_HOME_PAGE_LINK,
          route: INSTRUCTION.CHARGE,
          header: TEXT_INSTRUCTION_OURA_CHARGING_HEADER,
        },
      ];
    }
  }
};

export const getInstruction = (type: INSTRUCTION): InstructionData => {
  switch (type) {
    case INSTRUCTION.ABOUT_TRIAL: {
      return {
        type,
        header: TEXT_INSTRUCTION_TRIAL_TITLE,
        elements: getElementsByInstructionType(type),
      } as InstructionData;
    }
    case INSTRUCTION.CHARGE: {
      return {
        type,
        header: TEXT_INSTRUCTION_OURA_CHARGING_HEADER,
        description: TEXT_INSTRUCTION_OURA_CHARGING_DESCRIPTION,
        elements: getElementsByInstructionType(type),
      } as InstructionData;
    }
    case INSTRUCTION.SYNC: {
      return {
        type,
        header: TEXT_INSTRUCTION_OURA_SYNCING_HEADER,
        description: TEXT_INSTRUCTION_OURA_SYNCING_DESCRIPTION,
        elements: getElementsByInstructionType(type),
      } as InstructionData;
    }
    case INSTRUCTION.CHANGE_DETAIL: {
      return {
        type,
        header: TEXT_INSTRUCTION_OURA_CHANGING_HEADER,
        description: TEXT_INSTRUCTION_OURA_CHANGING_DETAIL_DESCRIPTION,
        descriptionAdditional: TEXT_INSTRUCTION_OURA_CHANGING_DETAIL_ADD_DESCRIPTION,
        elements: getElementsByInstructionType(type),
      } as InstructionData;
    }
    case INSTRUCTION.CHARGE_DETAIL: {
      return {
        type,
        header: TEXT_INSTRUCTION_OURA_CHARGING_HEADER,
        description: TEXT_INSTRUCTION_OURA_CHARGING_DETAIL_DESCRIPTION,
        title: TEXT_INSTRUCTION_OURA,
        titleInstruction: TEXT_INSTRUCTION_OURA_FAQ_TITLE,
        elements: getElementsByInstructionType(type),
        faq: FAQ_CHARGING_OURA,
      } as InstructionData;
    }
    case INSTRUCTION.SYNC_DETAIL: {
      return {
        type,
        header: TEXT_INSTRUCTION_OURA_SYNCING_HEADER,
        description: TEXT_INSTRUCTION_OURA_SYNCING_DETAIL_DESCRIPTION,
        title: TEXT_INSTRUCTION_OURA,
        titleInstruction: TEXT_INSTRUCTION_OURA_FAQ_TITLE,
        elements: getElementsByInstructionType(type),
        faq: FAQ_SYNCING_OURA,
      } as InstructionData;
    }
    case INSTRUCTION.FINISH: {
      return {
        type,
        Icon: ModalSuccess,
        header: TEXT_THANKS,
        elements: getElementsByInstructionType(type),
      } as InstructionData;
    }
    default: {
      return {
        type: INSTRUCTION.INITIAL,
        header: TEXT_INSTRUCTION_OURA_RING,
        title: TEXT_INSTRUCTION_OURA,
        Icon: Ring,
        elements: getElementsByInstructionType(type),
      } as InstructionData;
    }
  }
};

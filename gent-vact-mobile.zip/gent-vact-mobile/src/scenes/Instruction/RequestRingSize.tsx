import React, { FunctionComponent, useCallback } from 'react';
import { useDispatch } from 'react-redux';

import { appRoute, backRouteAction } from '../../app/actions';
import { MODAL_ROUTES } from '../../navigation/routes';
import { fetchChangeRingSize } from '../../services/patient/actions';
import { RingSizeUpdateRequest } from '../../api/RingSizeUpdateRequest';
import { RequestRingSizeView } from './RequestRingSizeView';

export const RequestRingSize: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();
  const handleBack = useCallback(() => {
    dispatch(backRouteAction());
  }, [dispatch]);

  const handleSubmit = useCallback(
    (size: RingSizeUpdateRequest['ringSize']) => {
      dispatch(fetchChangeRingSize(size));
      dispatch(appRoute(MODAL_ROUTES.LOADING));
    },
    [dispatch],
  );

  return <RequestRingSizeView onBack={handleBack} onSubmit={handleSubmit} />;
};

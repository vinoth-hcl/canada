import React, { FunctionComponent, useMemo } from 'react';
import { FlatList, ScrollView, StyleSheet, View } from 'react-native';
import { map } from 'lodash';

import { Colors } from '../../utilities/design';
import { GText } from '../../components/GText/GText';
import { Separator } from '../../components/Separator/Separator';
import { PlaceHolderView } from '../../components/PlaceholderView/PlaceholderView';
import { IS_OS_WEB, TEXT_INSTRUCTION_EMPTY } from '../../constants/constants';
import { TextStyles } from '../../components/GText/styles';
import { TextPage } from '../Welcome/Components/TextPage';
import { ITextElement } from '../Welcome/Components/types';
import { getContentTrial } from '../Welcome/Components/utils';
import { IFAQInstruction, IInstructionViewDetailProps, INSTRUCTION } from './types';
import { NavigationHeader } from './components/NavigationHeader';
import { InstructionViewDetailElements } from './components/InstructionViewDetailElements';
import { FAQItem } from './components/FAQItem';
import { ArticleView } from './components/ArticleView';
import { InstructionViewElements } from './components/InstructionViewElements';

const keyExtractor = (item: IFAQInstruction, index: number) => `${item.question}_${index}`;

const renderItem = ({ item, index }: { item: IFAQInstruction; index: number }) => {
  return <FAQItem item={item} index={index} />;
};

const renderPlaceHolder = () => (
  <PlaceHolderView
    text={TEXT_INSTRUCTION_EMPTY}
    style={{ container: styles.placeholderContainer }}
  />
);

const renderSeparator = () => <Separator style={{ marginLeft: 0, marginRight: 0 }} />;

export const InstructionViewDetailNative: FunctionComponent<IInstructionViewDetailProps> = ({
  data,
  contactList = [],
  code = '',
  handlers: { handleOpenApp, handleBack, handleGoIt, handlePressCall, handleChangeRing },
}) => {
  const {
    description,
    header,
    elements,
    title = '',
    titleInstruction,
    faq,
    type,
    descriptionAdditional = '',
  } = data;

  const contentTrial = useMemo(
    (): { [key: string]: ITextElement[] } => getContentTrial({ code, contactList }),
    [contactList, code],
  );

  return (
    <View style={{ backgroundColor: Colors.white }}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <NavigationHeader
          header={header}
          handleBack={handleBack}
          description={description}
          descriptionAdditional={descriptionAdditional}
        />
        {type === INSTRUCTION.ABOUT_TRIAL ? (
          <>
            <View style={StyleSheet.flatten([IS_OS_WEB && { alignItems: 'center' }])}>
              <ArticleView elements={elements} />
            </View>
            <View
              style={StyleSheet.flatten([
                styles.containerInstruction,
                IS_OS_WEB && { alignItems: 'center' },
              ])}
            >
              <View>
                {contactList.length > 0 &&
                  map(contentTrial, (item, index) => <TextPage elements={item} key={index} />)}
              </View>
            </View>
          </>
        ) : type === INSTRUCTION.CHANGE_DETAIL ? (
          <InstructionViewElements
            type={type}
            elements={elements}
            handlePressButton={handleGoIt}
            handleOpenApp={handleOpenApp}
            handleChangeRing={handleChangeRing}
            handlePressCall={handlePressCall}
          />
        ) : (
          <InstructionViewDetailElements
            handleOpenApp={handleOpenApp}
            elements={elements}
            title={title}
          />
        )}
        {faq && (
          <>
            <GText
              textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
              children={titleInstruction}
              style={styles.faqTitle}
              testID={'InstructionDescriptionViewDetailPage'}
              role={'header'}
            />
            <FlatList
              data={faq}
              renderItem={renderItem}
              keyExtractor={keyExtractor}
              style={{
                marginLeft: 16,
                marginRight: 16,
              }}
              ItemSeparatorComponent={renderSeparator}
              ListEmptyComponent={renderPlaceHolder}
            />
          </>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  faqTitle: {
    marginTop: 24,
    marginBottom: 8,
    textAlign: 'center',
    color: Colors.black,
  },
  placeholderContainer: {
    height: '100%',
  },
  containerInstruction: {
    backgroundColor: Colors.whiteGray,
    paddingTop: 24,
  },
});

import React, { FunctionComponent, useCallback } from 'react';
import { SafeAreaView, ScrollView, StyleSheet, View } from 'react-native';

import { IS_OS_WEB, SAFE_AREA_COLOR } from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { WebLayoutTemplate } from '../../components/WebLayoutTemplate/WebLayoutTemplate';
import { IInstructionPage } from './types';
import { InstructionViewElements } from './components/InstructionViewElements';
import { NavigationHeader } from './components/NavigationHeader';

interface IInstructionViewProps extends IInstructionPage {}

export const InstructionView: FunctionComponent<IInstructionViewProps> = ({
  data,
  handlers: { handleOpenApp, handleGoIt, handleChangeRing, handlePressCall, handleBack },
}) => {
  const renderComponent = useCallback(() => {
    const { description = '', header, type, elements } = data;
    return (
      <View
        style={StyleSheet.flatten([
          { backgroundColor: Colors.white },
          IS_OS_WEB && styles.wrapperWebElement,
        ])}
      >
        <ScrollView showsVerticalScrollIndicator={false}>
          <NavigationHeader
            header={header}
            description={description}
            handleBack={handleBack}
            style={StyleSheet.flatten([IS_OS_WEB && styles.containerWebElement])}
          />
          <InstructionViewElements
            elements={elements}
            type={type}
            handlePressButton={handleGoIt}
            handleOpenApp={handleOpenApp}
            handleChangeRing={handleChangeRing}
            handlePressCall={handlePressCall}
            style={StyleSheet.flatten([IS_OS_WEB && styles.containerWebElement])}
          />
        </ScrollView>
      </View>
    );
  }, [data, handleOpenApp, handleChangeRing, handleGoIt, handlePressCall, handleBack]);

  return (
    <SafeAreaView style={styles.container}>
      {IS_OS_WEB ? (
        <WebLayoutTemplate
          leftSide={[renderComponent()]}
          enableRightScroll={true}
          enableLeftScroll={true}
          enableCommonScroll={true}
        />
      ) : (
        renderComponent()
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: SAFE_AREA_COLOR,
  },
  wrapperWebElement: {
    alignItems: 'center',
  },
  containerWebElement: {
    backgroundColor: Colors.white,
    maxWidth: 560,
  },
});

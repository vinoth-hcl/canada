import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet } from 'react-native';

import { IS_OS_WEB, SAFE_AREA_COLOR } from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { BaseLayout } from '../../components/WebLayoutTemplate/BaseLayout';
import { Grid, LeftColumn, RightColumn } from '../../components/WebLayoutTemplate/BaseGrid';
import { GText } from '../../components/GText/GText';
import { TextStyles } from '../../components/GText/styles';
import { NavigationHeader } from './components/NavigationHeader';
import { InstructionViewElements } from './components/InstructionViewElements';
import { IInstructionPage } from './types';

interface IInstructionViewProps extends IInstructionPage {}

export const InstructionView: FunctionComponent<IInstructionViewProps> = ({
  data,
  handlers: { handleOpenApp, handleGoIt, handleChangeRing, handlePressCall, handleBack },
}) => {
  const renderComponent = useCallback(() => {
    const { description = '', header, type, elements } = data;
    return (
      <Grid>
        <LeftColumn
          header={
            <NavigationHeader
              header={header}
              handleBack={handleBack}
              style={StyleSheet.flatten([IS_OS_WEB && styles.containerWebElement])}
            />
          }
          style={{ flexBasis: 140 }}
        >
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
            children={description}
            testID={'NavigationHeaderDescription_0'}
          />
        </LeftColumn>
        <RightColumn>
          <InstructionViewElements
            elements={elements}
            type={type}
            handlePressButton={handleGoIt}
            handleOpenApp={handleOpenApp}
            handleChangeRing={handleChangeRing}
            handlePressCall={handlePressCall}
          />
        </RightColumn>
      </Grid>
    );
  }, [data, handleOpenApp, handleChangeRing, handleGoIt, handlePressCall, handleBack]);

  return <BaseLayout>{renderComponent()}</BaseLayout>;
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: SAFE_AREA_COLOR,
  },
  wrapperWebElement: {
    alignItems: 'center',
  },
  containerWebElement: {
    backgroundColor: Colors.white,
    maxWidth: 560,
  },
});

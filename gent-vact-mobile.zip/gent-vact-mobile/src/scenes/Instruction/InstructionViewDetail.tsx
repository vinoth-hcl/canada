import React, { FunctionComponent } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';

import { SAFE_AREA_COLOR, IS_OS_WEB } from '../../constants/constants';
import { IInstructionViewDetailProps } from './types';
import { InstructionViewDetailNative } from './InstructionViewDetailNative';

export const InstructionViewDetail: FunctionComponent<IInstructionViewDetailProps> = (props) => {
  return (
    <SafeAreaView style={styles.container}>
      <InstructionViewDetailNative {...props} />
    </SafeAreaView>
  );
};

const styles = IS_OS_WEB
  ? StyleSheet.create({
      container: {
        flex: 1,
        backgroundColor: SAFE_AREA_COLOR,
      },
    })
  : StyleSheet.create({
      container: {
        width: '100%',
        height: '100%',
        backgroundColor: SAFE_AREA_COLOR,
      },
    });

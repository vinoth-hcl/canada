import React, { FunctionComponent, useCallback, useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RouteProp } from '@react-navigation/native';
import { get } from 'lodash';

import { MODAL_ROUTES } from '../../navigation/routes';
import { appRoute, backRouteAction, makePhoneCallAction, startOuraRing } from '../../app/actions';
import { ModalStackParamList } from '../../navigation/types';
import { getProfile } from '../../services/patient/selector';
import { getSupportTrialContactsList } from '../../services/support/selectors';
import { getTrialContacts } from '../../services/support/actions';
import { InstructionHome } from './InstructionHome';
import { InstructionViewDetail } from './InstructionViewDetail';
import { InstructionView } from './InstructionView';
import { IInstructionPage, INSTRUCTION, InstructionData } from './types';
import { getInstruction } from './utils';
import { InstructionMessage } from './components/InstructionMessage';

const currentPageMap: Record<string, FunctionComponent<IInstructionPage>> = {
  [INSTRUCTION.INITIAL]: InstructionHome,
  [INSTRUCTION.SYNC]: InstructionView,
  [INSTRUCTION.CHANGE_DETAIL]: InstructionViewDetail,
  [INSTRUCTION.FINISH]: InstructionMessage,
  [INSTRUCTION.SYNC_DETAIL]: InstructionViewDetail,
  [INSTRUCTION.CHARGE]: InstructionView,
  [INSTRUCTION.CHARGE_DETAIL]: InstructionViewDetail,
  [INSTRUCTION.ABOUT_TRIAL]: InstructionViewDetail,
};

export type InstructionNavigationProp = RouteProp<ModalStackParamList, MODAL_ROUTES.INSTRUCTION>;

export interface IInstructionProps {
  route: InstructionNavigationProp;
}

export const Instruction: FunctionComponent<IInstructionProps> = ({ route }) => {
  const dispatch = useDispatch();
  const contactList = useSelector(getSupportTrialContactsList);
  const patientProfile = useSelector(getProfile);
  const patientId = get(patientProfile, 'id', '');
  const trial = get(patientProfile, 'hcpStudy.trial', {});
  const code = get(trial, 'code', '') as string;

  const type = route.params?.type ?? INSTRUCTION.INITIAL;

  const [page, setPage] = useState<INSTRUCTION>(type);
  const InstructionComponent = currentPageMap[page];

  const handleOpenApp = useCallback(() => {
    dispatch(startOuraRing());
  }, [dispatch]);

  const handleBack = useCallback(() => {
    dispatch(backRouteAction());
  }, [dispatch]);

  const handleGoIt = useCallback(() => {
    if (type === INSTRUCTION.FINISH) {
      dispatch(appRoute(MODAL_ROUTES.INSTRUCTION, { type: INSTRUCTION.CHANGE_DETAIL }));
    } else {
      handleBack();
    }
  }, [dispatch, handleBack, type]);

  const handlePressCall = useCallback(
    (numberPhone: string) => {
      dispatch(makePhoneCallAction(numberPhone));
    },
    [dispatch],
  );

  const handleChangeRing = useCallback(() => {
    dispatch(appRoute(MODAL_ROUTES.CHANGE_RING_SIZE));
  }, [dispatch]);

  const changePage = useCallback((nextPage: string) => {
    setPage(nextPage as INSTRUCTION);
  }, []);

  const handlePressLink = useCallback(
    (routeName: string, params = {}) => {
      dispatch(appRoute(routeName, params));
    },
    [dispatch],
  );

  const instruction = useMemo((): InstructionData => getInstruction(page), [page]);

  useEffect(() => {
    setPage(type);
  }, [type]);

  useEffect(() => {
    if (patientId && type === INSTRUCTION.ABOUT_TRIAL) {
      dispatch(getTrialContacts({ patientId }));
    }
  }, [dispatch, type, patientId]);

  return page ? (
    <InstructionComponent
      data={instruction}
      handlers={{
        handleBack,
        handleGoIt,
        changePage,
        handleOpenApp,
        handlePressLink,
        handlePressCall,
        handleChangeRing,
      }}
      contactList={contactList}
      code={code}
    />
  ) : null;
};

import React, { FunctionComponent } from 'react';
import { StyleSheet } from 'react-native';

import { GButton } from '../../components/GButton/GButton';
import { Colors } from '../../utilities/design';
import { RingSizeUpdateRequest } from '../../api/RingSizeUpdateRequest';

interface IRingSizeItemProps {
  size?: RingSizeUpdateRequest['ringSize'];
  selected: boolean;
  onPress: () => void;
  index: number;
}

export const RingSizeItem: FunctionComponent<IRingSizeItemProps> = ({
  size,
  selected,
  onPress,
  index,
}) => {
  return (
    <GButton
      text={size}
      onPress={onPress}
      style={{
        container: StyleSheet.flatten([
          styles.container,
          selected ? styles.selectedButton : styles.notSelectedButton,
        ]),
        textStyle: selected ? styles.selectedText : undefined,
      }}
      testID={`Ring_size_${index}`}
      role={'radio'}
      accessibilityState={{ checked: selected }}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    height: 52,
    flexBasis: '22%',
    marginTop: 8,
    marginBottom: 8,
    borderTopStartRadius: 3,
    borderTopEndRadius: 3,
    borderBottomStartRadius: 3,
    borderBottomEndRadius: 3,
  },
  notSelectedButton: {
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderTopColor: Colors.greyMedium,
    borderBottomColor: Colors.greyMedium,
    borderLeftColor: Colors.greyMedium,
    borderRightColor: Colors.greyMedium,
  },
  selectedButton: {
    backgroundColor: Colors.newBlue,
  },
  selectedText: {
    color: Colors.white,
  },
});

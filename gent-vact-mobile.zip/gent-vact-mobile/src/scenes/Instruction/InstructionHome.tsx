import React, { FunctionComponent } from 'react';
import { SafeAreaView, StyleSheet, View } from 'react-native';

import { SAFE_AREA_COLOR } from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { IInstructionPage } from './types';
import { NavigationHeader } from './components/NavigationHeader';
import { InstructionHomeElements } from './components/InstructionHomeElements';

interface IInstructionHomeProps extends IInstructionPage {}

export const InstructionHome: FunctionComponent<IInstructionHomeProps> = ({
  data,
  handlers: { handleBack, changePage },
}) => {
  const { Icon, header, title = '', elements, description } = data;

  return (
    <SafeAreaView style={styles.container}>
      <View style={{ backgroundColor: Colors.white }}>
        <NavigationHeader
          header={header}
          handleBack={handleBack}
          Icon={Icon}
          description={description}
        />
        <InstructionHomeElements title={title} changePage={changePage} elements={elements} />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: SAFE_AREA_COLOR,
  },
});

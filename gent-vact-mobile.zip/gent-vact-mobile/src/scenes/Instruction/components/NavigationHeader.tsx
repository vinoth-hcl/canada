import React, { FunctionComponent } from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';

import { BackButton } from '../../Options/components/BackButton';
import { GText } from '../../../components/GText/GText';
import { Colors } from '../../../utilities/design';
import { TextStyles } from '../../../components/GText/styles';
import { IS_OS_WEB } from '../../../constants/constants';

interface INavigationHeaderProps {
  header: string;
  handleBack: () => void;
  Icon?: React.ElementType;
  description?: string;
  descriptionAdditional?: string;
  testId?: string | number;
  style?: StyleProp<ViewStyle>;
}

export const NavigationHeader: FunctionComponent<INavigationHeaderProps> = ({
  handleBack,
  Icon,
  header,
  description,
  descriptionAdditional = '',
  testId = 0,
  style = {},
}) => {
  return (
    <View style={StyleSheet.flatten([styles.container, style])}>
      <View style={styles.backButton}>
        <BackButton onPress={handleBack} />
      </View>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_SEMIBOLD}
        children={header}
        style={styles.header}
        testID={`NavigationHeaderTitle_ ${testId}`}
        role={'header'}
      />
      {!!Icon && <Icon />}
      {!!description && (
        <View style={styles.wrapper}>
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
            children={description}
            testID={`NavigationHeaderDescription_${testId}`}
          />
        </View>
      )}
      {!!descriptionAdditional && (
        <View style={[styles.wrapper, styles.separator]}>
          <GText
            textStyle={TextStyles.SOURCE_SANS_14_16_NORMAL}
            children={descriptionAdditional}
            testID={`NavigationHeaderDescription_${testId}`}
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
    position: 'relative',
  },
  backButton: {
    position: 'absolute',
    left: 17,
    top: 25,
    zIndex: 1,
  },
  header: {
    textAlign: IS_OS_WEB ? 'left' : 'center',
    marginTop: 25,
    marginLeft: 100,
    marginRight: 80,
    color: Colors.black,
  },
  wrapper: {
    marginTop: 24,
    marginBottom: 8,
    marginLeft: 16,
    marginRight: 16,
  },
  separator: {
    marginTop: 8,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.greyLightest,
  },
});

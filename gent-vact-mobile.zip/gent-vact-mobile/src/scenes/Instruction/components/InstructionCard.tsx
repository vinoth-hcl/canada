import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet, View } from 'react-native';

import { Colors } from '../../../utilities/design';
import {
  TEXT_INSTRUCTION_BUTTON_CALL,
  TEXT_INSTRUCTION_BUTTON_RING_SIZE,
} from '../../../constants/constants';
import { IElementInstruction, InstructionHandlers } from '../types';
import { GButton } from '../../../components/GButton/GButton';
import { ButtonKind } from '../../../components/GButton/types';
import PhoneWhite from '../../../../assets/images/PhoneWhite.svg';
import { getConfigString } from '../../../utilities/config';
import { InstructionCardText } from './InstructionCardText';

interface IInstructionCardProps {
  handleOpenApp: InstructionHandlers['handleOpenApp'];
  handlePressCall: InstructionHandlers['handlePressCall'];
  handleChangeRing: InstructionHandlers['handleChangeRing'];
  item: IElementInstruction;
  index: number;
  isShadow?: boolean;
}

export const InstructionCard: FunctionComponent<IInstructionCardProps> = ({
  item: { description, link = '', descriptionAdditional = '', buttonLabel = '' },
  index,
  handleOpenApp,
  handlePressCall,
  handleChangeRing,
  isShadow = false,
}) => {
  const hasCall = buttonLabel === TEXT_INSTRUCTION_BUTTON_CALL;
  const numberPhone = getConfigString('HELP_DESC_CALL_NUMBER', '');
  const hasCangeRing = buttonLabel === TEXT_INSTRUCTION_BUTTON_RING_SIZE;
  const handlePress = useCallback(() => {
    if (hasCall && !!numberPhone) {
      handlePressCall(numberPhone);
    }
    if (hasCangeRing) {
      handleChangeRing();
    }
  }, [numberPhone, handlePressCall, handleChangeRing, hasCangeRing, hasCall]);

  return (
    <View style={StyleSheet.flatten([styles.container, isShadow && styles.shadow])}>
      <InstructionCardText
        index={index}
        link={link}
        description={description}
        descriptionAdd={descriptionAdditional}
        handleOpenApp={handleOpenApp}
      />
      {!!buttonLabel && (
        <GButton
          kind={numberPhone ? ButtonKind.BLUE : ButtonKind.DISABLED}
          text={buttonLabel}
          style={{ container: styles.button }}
          testID={`instruction_button_${buttonLabel}`}
          onPress={handlePress}
          isShadow
          Icon={hasCall ? PhoneWhite : undefined}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: 8,
    marginTop: 18,
    paddingTop: 16,
    paddingBottom: 16,
    paddingLeft: 16,
    paddingRight: 16,
  },
  shadow: {
    shadowColor: Colors.black,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3,
  },
  button: {
    marginTop: 16,
  },
});

import React from 'react';
import Slider from 'react-slick';
import { Colors } from '../../../utilities/design';
import './SliderWeb.css';

export const SwiperWeb = (props: any) => {
  const dotStyle = {
    display: 'inline-block',
    backgroundColor: Colors.greyLighter,
    width: '12px',
    height: '12px',
    borderRadius: '6px',
    margin: '3px',
    cursor: 'pointer',
  };
  const settings = {
    arrows: false,
    dots: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    customPaging(index: number): JSX.Element {
      return (
        <div>
          <a style={{ ...dotStyle }} />
        </div>
      );
    },
  };
  return <Slider {...settings}>{props.children.length && props.children}</Slider>;
};

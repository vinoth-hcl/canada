import React, { FunctionComponent, useMemo } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { Colors } from '../../../utilities/design';
import { GText } from '../../../components/GText/GText';
import { testId } from '../../../utilities/TestId';
import { IElementInstruction } from '../types';
import { IS_OS_WEB } from '../../../constants/constants';
import { TextStyles } from '../../../components/GText/styles';

interface IInstructionViewItemProps {
  handlePress: () => void;
  item: IElementInstruction;
  index: number;
  isShadow?: boolean;
}

export const InstructionViewItem: FunctionComponent<IInstructionViewItemProps> = ({
  item: { Icon = null, description, link = '', route = '', backgroundColor = Colors.white },
  index,
  handlePress,
  isShadow = false,
}) => {
  const currentNumber = useMemo((): number => index + 1, [index]);
  const isDisabled = !route && !link;

  return (
    <Pressable
      onPress={handlePress}
      style={StyleSheet.flatten([styles.container, isShadow && styles.shadow])}
      {...testId(
        `instruction_item_${route}`,
        `${currentNumber} ${description} ${link}`,
        isDisabled ? 'text' : 'link',
      )}
      disabled={isDisabled}
    >
      {!!Icon && (
        <View style={styles.iconContainer} importantForAccessibility={'no-hide-descendants'}>
          <View style={StyleSheet.flatten([styles.background, { backgroundColor }])} />
          <Icon />
        </View>
      )}
      <View style={styles.textContainer}>
        <GText
          textStyle={TextStyles.BITTER_16_24_BOLD}
          testID={`Number_Instruction_${index}`}
          children={currentNumber}
        />
        <View style={styles.description}>
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
            testID={`Number_Instruction_${index}`}
            children={description}
          />
          {!!link && (
            <GText
              textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
              style={styles.link}
              testID={`Number_Instruction_${index}`}
              children={link}
            />
          )}
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: 8,
    marginTop: 18,
    minHeight: 272,
  },
  background: {
    opacity: 0.05,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1,
    borderTopRightRadius: 8,
    borderTopLeftRadius: 8,
  },
  iconContainer: {
    paddingTop: 22,
    justifyContent: 'flex-end',
    alignItems: 'center',
    height: 192,
    position: 'relative',
  },
  textContainer: {
    paddingTop: 16,
    paddingBottom: 16,
    paddingLeft: 16,
    paddingRight: 16,
    flexDirection: 'row',
  },
  description: {
    marginLeft: 16,
    maxWidth: IS_OS_WEB ? 350 : 'auto',
  },
  link: {
    textDecorationLine: 'underline',
    color: Colors.linkDefault,
  },
  shadow: {
    shadowColor: Colors.black,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3,
  },
});

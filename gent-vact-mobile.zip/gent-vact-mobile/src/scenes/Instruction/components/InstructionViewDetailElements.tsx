import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
// import Swiper from 'react-native-swiper';
import { map } from 'lodash';

import { Colors } from '../../../utilities/design';
import { GText } from '../../../components/GText/GText';
import { IElementInstruction, InstructionHandlers } from '../types';
import { IS_OS_WEB } from '../../../constants/constants';
import { TextStyles } from '../../../components/GText/styles';
import { NonActiveDot } from './NonActiveDot';
import { ActiveDot } from './ActiveDot';
import { InstructionViewItem } from './InstructionViewItem';

import Swiper from './Swiper';
import { SwiperWeb } from './SliderWeb';

const FIRST_SLIDE = 0;

interface IInstructionViewDetailElementsProps {
  elements: IElementInstruction[];
  title: string;
  handleOpenApp: InstructionHandlers['handleOpenApp'];
}

export const InstructionViewDetailElements: FunctionComponent<IInstructionViewDetailElementsProps> = ({
  elements,
  title,
  handleOpenApp,
}) => {
  const renderInstructions = () => {
    if (elements.length) {
      return map(elements, (item: IElementInstruction, index: number) => (
        <InstructionViewItem handlePress={handleOpenApp} item={item} index={index} key={index} />
      ));
    }
  };
  return (
    <View style={styles.container}>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
        children={title}
        style={styles.title}
        testID={'InstructionDescriptionViewDetailPage'}
        role={'header'}
      />
      {IS_OS_WEB ? (
        <SwiperWeb>{renderInstructions()}</SwiperWeb>
      ) : (
        <Swiper
          showsButtons={false}
          horizontal
          loop
          index={FIRST_SLIDE}
          dot={<NonActiveDot />}
          activeDot={<ActiveDot />}
        >
          {renderInstructions()}
        </Swiper>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 419,
    backgroundColor: Colors.whiteGray,
    justifyContent: 'flex-start',
    paddingLeft: 17,
    paddingRight: 17,
  },
  title: {
    marginTop: 24,
    marginBottom: 6,
    textAlign: 'center',
    color: Colors.black,
  },
});

import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

import { IInstructionPage } from '../types';
import { Colors } from '../../../utilities/design';
import { GText } from '../../../components/GText/GText';
import { SAFE_AREA_COLOR, TEXT_INSTRUCTION_BUTTON } from '../../../constants/constants';
import { GButton } from '../../../components/GButton/GButton';
import { ButtonKind } from '../../../components/GButton/types';
import { TextStyles } from '../../../components/GText/styles';
import { BaseLayout } from '../../../components/WebLayoutTemplate/BaseLayout';
import { Grid, LeftColumn, RightColumn } from '../../../components/WebLayoutTemplate/BaseGrid';

interface IInstructionMessageProps extends IInstructionPage {}

export const InstructionMessage: FunctionComponent<IInstructionMessageProps> = ({
  data,
  handlers: { handleGoIt },
}) => {
  const { type, Icon, header, elements } = data;
  return (
    <BaseLayout>
      <Grid>
        <LeftColumn>
          <View style={styles.header}>
            {!!Icon && <Icon />}
            <View style={styles.wrapper}>
              <GText
                textStyle={TextStyles.BITTER_24_28_BOLD}
                children={header}
                testID={`NavigationFinishHeader_${header}`}
              />
            </View>
          </View>
        </LeftColumn>
        <RightColumn>
          <View style={styles.card}>
            {elements.length > 0 && (
              <View style={styles.text}>
                <GText
                  textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
                  testID={`NavigationFinishText_${elements[0].header}`}
                  style={styles.title}
                  children={elements[0].header}
                />
                <GText
                  textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
                  testID={`NavigationFinishText_${elements[0].description}`}
                  style={{
                    color: Colors.greyDark,
                    marginBottom: 16,
                    textAlign: 'left',
                  }}
                  children={elements[0].description}
                />
                {!!elements[0].descriptionAdditional && (
                  <GText
                    textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
                    testID={`NavigationFinishText_${elements[0].descriptionAdditional}`}
                    children={elements[0].descriptionAdditional}
                  />
                )}
              </View>
            )}
          </View>
          <GButton
            kind={ButtonKind.BLUE}
            text={TEXT_INSTRUCTION_BUTTON}
            style={{
              container: styles.buttonContainer,
              textFont: TextStyles.BITTER_16_24_BOLD,
            }}
            onPress={handleGoIt}
            testID={`GotIt_${type}`}
          />
        </RightColumn>
      </Grid>
    </BaseLayout>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: SAFE_AREA_COLOR,
  },
  layout: {
    height: '100%',
    backgroundColor: Colors.whiteGray,
  },
  header: {
    height: 248,
    marginBottom: 16,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
    textAlign: 'left',
  },
  wrapper: {
    marginTop: 40,
  },
  card: {
    paddingLeft: 17,
    paddingRight: 17,
    marginBottom: 32,
    width: 423,
  },
  text: {
    backgroundColor: Colors.white,
    borderRadius: 8,
    marginTop: 18,
    paddingTop: 16,
    paddingBottom: 16,
    paddingLeft: 16,
    paddingRight: 16,
    textAlign: 'left',
  },
  title: {
    color: Colors.greyDark,
    marginBottom: 16,
    textAlign: 'left',
  },
  descriptionAdditional: {
    textAlign: 'left',
  },
  buttonContainer: {
    alignSelf: 'center',
    width: 328,
  },
});

export const SwiperWeb = ({ children }: any) => {
  return children;
};

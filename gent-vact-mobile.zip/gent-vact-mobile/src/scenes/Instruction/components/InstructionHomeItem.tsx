import React, { FunctionComponent } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { Colors } from '../../../utilities/design';
import { GText } from '../../../components/GText/GText';
import { IElementInstruction } from '../types';
import { TextStyles } from '../../../components/GText/styles';

interface IInstructionHomeItemProps {
  item: IElementInstruction;
  handlePress: () => void;
  index: number;
}

export const InstructionHomeItem: FunctionComponent<IInstructionHomeItemProps> = ({
  index,
  handlePress,
  item: { Icon, header, description, route, link },
}) => {
  return (
    <Pressable onPress={handlePress} disabled={!route} style={styles.container}>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
        children={header}
        testID={`InstructionHeaderElementHomePage_${index}`}
        style={styles.header}
      />
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        children={description}
        style={styles.description}
        testID={`InstructionDescriptionElementHomePage_${index}`}
      />
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
        style={styles.link}
        children={link}
        testID={`InstructionDescriptionElementHomePage_${index}`}
      />
      {Icon && (
        <View style={styles.iconContainer}>
          <Icon opacity={0.4} />
        </View>
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    backgroundColor: Colors.white,
    marginTop: 7,
    marginBottom: 7,
    paddingLeft: 16,
    paddingRight: 16,
    paddingTop: 14,
    paddingBottom: 14,
    borderRadius: 8,
    position: 'relative',
  },
  iconContainer: {
    position: 'absolute',
    right: 16,
    top: 16,
  },
  header: {
    color: Colors.black,
  },
  description: {
    marginTop: 10,
    marginBottom: 10,
    color: Colors.black,
  },
  link: {
    color: Colors.linkDefault,
    textDecorationLine: 'underline',
  },
});

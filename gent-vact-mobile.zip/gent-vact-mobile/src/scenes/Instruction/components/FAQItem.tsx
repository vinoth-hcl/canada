import React, { FunctionComponent, useCallback, useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, View, Animated, Easing, LayoutAnimation } from 'react-native';

import { IFAQInstruction } from '../types';
import { GText } from '../../../components/GText/GText';
import { useAnimated } from '../../../utilities/hooks';
import { Colors } from '../../../utilities/design';
import Arrow from '../../../../assets/images/ArrowBlueUp.svg';
import { testId } from '../../../utilities/TestId';
import { IS_OS_WEB } from '../../../constants/constants';
import { TextStyles } from '../../../components/GText/styles';

const ANIMATION_DURATION = 300;
const UP_ARROW = 0;
const DOWN_ARROW = 1;

const getStylesArrow = (animatedValue: Animated.Value) => {
  return {
    ...styles.arrow,
    transform: [
      {
        rotate: animatedValue.interpolate({
          inputRange: [0, 0.5, 1],
          outputRange: ['0deg', '90deg', '180deg'],
        }),
      },
    ],
  };
};

interface IFAQItemProps {
  item: IFAQInstruction;
  index: number;
}

export const FAQItem: FunctionComponent<IFAQItemProps> = ({
  item: { answer, question },
  index,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const isAnimated = useRef(false);
  const animatedValue = useMemo(() => new Animated.Value(isOpen ? UP_ARROW : DOWN_ARROW), [isOpen]);

  const handlePress = useCallback(() => {
    if (isAnimated.current) {
      return;
    }
    isAnimated.current = true;
    const toValue = isOpen ? DOWN_ARROW : UP_ARROW;
    animatedValue.setValue(isOpen ? UP_ARROW : DOWN_ARROW);

    Animated.timing(animatedValue, {
      toValue,
      duration: ANIMATION_DURATION,
      easing: Easing.ease,
    }).start();

    if (!IS_OS_WEB) {
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    }

    setIsOpen(!isOpen);
    isAnimated.current = false;
  }, [animatedValue, isOpen]);

  const stylesArrow = getStylesArrow(animatedValue);

  useAnimated();

  return (
    <Pressable
      style={styles.container}
      onPress={handlePress}
      {...testId(`InstructionQuestion_button_${index}`, question)}
    >
      <View style={styles.header}>
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
          style={styles.question}
          children={question}
          testID={`InstructionQuestion_question_${index}`}
        />
        <Animated.View style={stylesArrow}>
          <Arrow />
        </Animated.View>
      </View>
      {isOpen && (
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
          style={styles.answer}
          children={answer}
          testID={`InstructionQuestion_answer_${index}`}
        />
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 16,
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingRight: 10,
  },
  question: {
    color: Colors.newBlue,
  },
  answer: {
    marginTop: 16,
  },
  arrow: {
    marginTop: 10,
    marginRight: 8,
  },
});

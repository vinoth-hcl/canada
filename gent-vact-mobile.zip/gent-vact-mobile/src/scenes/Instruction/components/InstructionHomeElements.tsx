import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { map } from 'lodash';

import { Colors } from '../../../utilities/design';
import { GText } from '../../../components/GText/GText';
import { IElementInstruction, InstructionHandlers } from '../types';
import { TextStyles } from '../../../components/GText/styles';
import { InstructionHomeItem } from './InstructionHomeItem';

interface IInstructionHomeElementsProps {
  title: string;
  changePage: InstructionHandlers['changePage'];
  elements: IElementInstruction[];
}

export const InstructionHomeElements: FunctionComponent<IInstructionHomeElementsProps> = ({
  title,
  elements,
  changePage,
}) => {
  return (
    <View style={styles.container}>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
        children={title}
        style={styles.title}
        testID={'InstructionTitleHomePage'}
      />
      {elements.length > 0 &&
        map(elements, (item: IElementInstruction, index: number) => {
          const handlePress = () => {
            if (item.route) {
              changePage(item.route);
            }
          };
          return (
            <InstructionHomeItem item={item} handlePress={handlePress} index={index} key={index} />
          );
        })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: Colors.whiteGray,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingLeft: 17,
    paddingRight: 17,
  },
  title: {
    marginTop: 24,
    marginBottom: 19,
    color: Colors.black,
  },
});

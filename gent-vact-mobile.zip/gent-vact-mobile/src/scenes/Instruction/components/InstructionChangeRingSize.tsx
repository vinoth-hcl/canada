import React, { FunctionComponent } from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import { map } from 'lodash';

import { Colors } from '../../../utilities/design';
import { IElementInstruction, INSTRUCTION, InstructionHandlers } from '../types';
import { Button } from '../../../components/Button/Button';
import { ButtonKind } from '../../../components/Button/types';
import { TEXT_INSTRUCTION_BUTTON } from '../../../constants/constants';
import { InstructionViewItem } from './InstructionViewItem';
import { InstructionCard } from './InstructionCard';

interface IInstructionViewElementsProps {
  type: INSTRUCTION;
  elements: IElementInstruction[];
  handlePressButton: () => void;
  handleOpenApp: InstructionHandlers['handleOpenApp'];
  handleChangeRing: InstructionHandlers['handleChangeRing'];
  handlePressCall: InstructionHandlers['handlePressCall'];
  style?: StyleProp<ViewStyle>;
}

export const InstructionChangeRingSize: FunctionComponent<IInstructionViewElementsProps> = ({
  type,
  elements,
  handlePressButton,
  handleOpenApp,
  handleChangeRing,
  handlePressCall,
  style = {},
}) => {
  return (
    <View style={StyleSheet.flatten([styles.container, style])}>
      {elements.length > 0 &&
        map(elements, (item: IElementInstruction, index: number) => {
          return type === INSTRUCTION.CHANGE_DETAIL ? (
            <InstructionCard
              index={index}
              item={item}
              handleOpenApp={handleOpenApp}
              handlePressCall={handlePressCall}
              handleChangeRing={handleChangeRing}
              key={index}
              isShadow
            />
          ) : (
            <InstructionViewItem
              index={index}
              item={item}
              handlePress={handleOpenApp}
              key={index}
              isShadow
            />
          );
        })}
      <Button
        kind={ButtonKind.MAIN_BLUE}
        text={TEXT_INSTRUCTION_BUTTON}
        style={{
          container: styles.buttonContainer,
          textStyle: styles.buttonText,
        }}
        onPress={handlePressButton}
        testID={`GotIt_${type}`}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.whiteGray,
    justifyContent: 'flex-start',
    paddingLeft: 17,
    paddingRight: 17,
  },
  buttonContainer: {
    elevation: 0,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 24,
    marginLeft: 0,
    marginRight: 0,
    width: 328,
    alignSelf: 'center',
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 16,
    lineHeight: 24,
    marginLeft: 12,
    marginRight: 12,
  },
});

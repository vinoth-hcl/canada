import React, { FunctionComponent, useMemo } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { GText } from '../../../components/GText/GText';
import { testId } from '../../../utilities/TestId';
import { Colors } from '../../../utilities/design';
import { IS_OS_WEB } from '../../../constants/constants';
import { FormattedString } from '../../../components/FormattedText/types';
import { TextStyles } from '../../../components/GText/styles';

interface IInstructionCardTextProps {
  index: number;
  link: string;
  description: string | FormattedString;
  descriptionAdd: string;
  handleOpenApp: () => void;
}

export const InstructionCardText: FunctionComponent<IInstructionCardTextProps> = ({
  index,
  link,
  description,
  descriptionAdd,
  handleOpenApp,
}) => {
  const currentNumber = useMemo((): number => index + 1, [index]);

  return (
    <View style={styles.container}>
      <GText
        textStyle={TextStyles.BITTER_16_24_BOLD}
        testID={`Number_Instruction_${index}`}
        style={styles.number}
        children={currentNumber}
      />
      <View style={styles.description}>
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
          testID={`Instruction_Description_${index}`}
          children={description}
        />
        {!!link && (
          <Pressable
            onPress={handleOpenApp}
            {...testId(`instruction_item_link_${currentNumber}`, link, 'link')}
          >
            <GText
              textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
              style={styles.link}
              testID={`Number_Instruction_Link_${index}`}
              children={link}
            />
          </Pressable>
        )}
        {!!descriptionAdd && (
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
            testID={`Instruction_DescriptionAdditional_${index}`}
            children={descriptionAdd}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
  },
  description: {
    marginLeft: 16,
    maxWidth: IS_OS_WEB ? 350 : 'auto',
  },
  link: {
    textDecorationLine: 'underline',
    color: Colors.linkDefault,
  },
  number: {
    color: Colors.newBlue,
  },
});

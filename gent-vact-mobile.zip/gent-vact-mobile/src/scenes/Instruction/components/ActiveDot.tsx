import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

import { Colors } from '../../../utilities/design';

export const ActiveDot: FunctionComponent<{}> = () => (
  <View style={styles.container}>
    <View style={styles.dot} />
  </View>
);

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderWidth: 3,
    borderColor: Colors.newBlue,
    width: 24,
    height: 24,
    borderRadius: 12,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dot: {
    backgroundColor: Colors.newBlue,
    width: 12,
    height: 12,
    borderRadius: 6,
  },
});

import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { GText } from '../../../components/GText/GText';
import { Colors } from '../../../utilities/design';
import { INSTRUCTION } from '../types';
import { TextStyles } from '../../../components/GText/styles';

interface IInstructionViewHeaderProps {
  header: string;
  description: string;
  type: INSTRUCTION;
}

export const InstructionViewHeader: FunctionComponent<IInstructionViewHeaderProps> = ({
  header,
  description,
  type,
}) => {
  return (
    <View style={styles.container}>
      <GText
        textStyle={TextStyles.BITTER_24_28_BOLD}
        children={header}
        style={styles.header}
        testID={`InstructionHeaderViewPage${type}`}
      />
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        children={description}
        style={styles.description}
        testID={`InstructionDescriptionViewPage${type}`}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    maxWidth: 560,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 16,
    position: 'relative',
  },
  header: {
    marginTop: 8,
    marginBottom: 8,
    color: Colors.black,
    marginLeft: 16,
    marginRight: 16,
  },
  description: {
    marginTop: 8,
    marginBottom: 8,
    color: Colors.black,
    marginLeft: 16,
    marginRight: 16,
    textAlign: 'center',
  },
});

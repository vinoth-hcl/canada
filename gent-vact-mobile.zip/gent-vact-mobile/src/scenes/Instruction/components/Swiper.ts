import Swiper from 'react-native-swiper';

export default Swiper;

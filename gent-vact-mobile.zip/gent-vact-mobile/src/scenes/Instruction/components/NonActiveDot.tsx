import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

import { Colors } from '../../../utilities/design';

export const NonActiveDot: FunctionComponent<{}> = () => <View style={styles.container} />;

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.greyLighter,
    width: 12,
    height: 12,
    borderRadius: 6,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
  },
});

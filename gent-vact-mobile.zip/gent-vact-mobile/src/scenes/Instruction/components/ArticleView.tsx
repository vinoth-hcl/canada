import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { map } from 'lodash';

import { IElementInstruction } from '../types';
import { Separator } from '../../../components/Separator/Separator';
import { IS_OS_WEB } from '../../../constants/constants';
import { ArticleItem } from './ArticleItem';

interface IArticleViewProps {
  elements: IElementInstruction[];
}

export const ArticleView: FunctionComponent<IArticleViewProps> = ({ elements }) => (
  <View style={StyleSheet.flatten([IS_OS_WEB && styles.container])}>
    {elements.length > 0 &&
      map(elements, (item: IElementInstruction, index: number) => {
        return (
          <React.Fragment key={index}>
            {index !== 0 && <Separator style={styles.separator} />}
            <ArticleItem element={item} index={index} />
          </React.Fragment>
        );
      })}
  </View>
);

const styles = StyleSheet.create({
  container: {
    maxWidth: 560,
  },
  separator: {
    marginLeft: 16,
    marginRight: 16,
  },
});

import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { GText } from '../../../components/GText/GText';
import { Colors } from '../../../utilities/design';
import { TextStyles } from '../../../components/GText/styles';

interface IPointViewProps {
  item: string;
  index?: number | string;
}

export const PointView: FunctionComponent<IPointViewProps> = ({ item, index = 0 }) => (
  <View style={styles.container}>
    <GText
      textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
      testID={`instruction_about_trial_point_${index}`}
      children={'•'}
      style={styles.point}
    />
    <GText
      textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
      testID={`instruction_about_trial_point_text_${index}`}
      children={item}
      style={styles.pointText}
    />
  </View>
);

const styles = StyleSheet.create({
  container: {
    marginTop: 8,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  point: {
    color: Colors.greyDark,
    marginRight: 10,
  },
  pointText: {
    color: Colors.greyDark,
  },
});

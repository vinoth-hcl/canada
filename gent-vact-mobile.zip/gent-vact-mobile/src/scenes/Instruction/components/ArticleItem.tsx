import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { map } from 'lodash';

import { GText } from '../../../components/GText/GText';
import { IElementInstruction } from '../types';
import { Colors } from '../../../utilities/design';
import { TextStyles } from '../../../components/GText/styles';
import { PointView } from './PointView';

interface IArticleItemProps {
  element: IElementInstruction;
  index?: number;
}

export const ArticleItem: FunctionComponent<IArticleItemProps> = ({ element, index = 0 }) => {
  const { header, description, points = [] } = element;
  return (
    <View style={styles.container}>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
        testID={`instruction_about_trial_header_${index}`}
        children={header}
        style={styles.header}
        role={'header'}
      />
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        testID={`instruction_about_trial_description_${index}`}
        children={description}
      />
      {points.length > 0 &&
        map(points, (item: string, num: number) => (
          <PointView item={item} index={num} key={`point_${num}`} />
        ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 24,
    marginBottom: 24,
    marginLeft: 16,
    marginRight: 16,
  },
  header: {
    marginBottom: 16,
    color: Colors.greyDark,
  },
});

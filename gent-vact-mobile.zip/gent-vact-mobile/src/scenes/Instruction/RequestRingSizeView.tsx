import React, { FunctionComponent, useCallback, useState } from 'react';
import { SafeAreaView, View, StyleSheet } from 'react-native';
import { map } from 'lodash';

import {
  SAFE_AREA_COLOR,
  TEXT_ENTER_SIZE,
  TEXT_ENTER_SUBMIT,
  TEXT_RING_SIZE,
  TEXT_RING_SIZE_DESC,
  TEXT_RING_SIZE_HEAD,
} from '../../constants/constants';
import { GButton } from '../../components/GButton/GButton';
import { ButtonKind } from '../../components/GButton/types';
import { GText } from '../../components/GText/GText';
import { Colors } from '../../utilities/design';
import { RingSizeUpdateRequest } from '../../api/RingSizeUpdateRequest';
import { TextStyles } from '../../components/GText/styles';
import { NavigationHeader } from './components/NavigationHeader';
import { RingSizeItem } from './RingSizeItem';

const RING_SIZE: RingSizeUpdateRequest['ringSize'][] = ['6', '7', '8', '9', '10', '11', '12', '13'];

interface IRequestRingSizeViewProps {
  onBack: () => void;
  onSubmit: (size: RingSizeUpdateRequest['ringSize']) => void;
}

export const RequestRingSizeView: FunctionComponent<IRequestRingSizeViewProps> = ({
  onBack,
  onSubmit,
}) => {
  const [sizeRing, setSizeRing] = useState<RingSizeUpdateRequest['ringSize']>();

  const handleSubmit = useCallback(() => {
    if (sizeRing) {
      onSubmit(sizeRing);
    }
  }, [onSubmit, sizeRing]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <NavigationHeader
            header={TEXT_RING_SIZE_HEAD}
            handleBack={onBack}
            description={TEXT_RING_SIZE_DESC}
          />
        </View>
        <GText
          textStyle={TextStyles.BITTER_16_24_BOLD}
          children={TEXT_RING_SIZE}
          style={styles.title}
        />
        <View style={styles.reasons}>
          {map(RING_SIZE, (size, index) => {
            const onPressItem = () => {
              if (sizeRing === size) {
                setSizeRing(undefined);
              } else {
                setSizeRing(size);
              }
            };
            return (
              <RingSizeItem
                size={size}
                selected={size === sizeRing}
                onPress={onPressItem}
                key={index}
                index={index}
              />
            );
          })}
        </View>
        <GButton
          onPress={handleSubmit}
          kind={!sizeRing ? ButtonKind.DISABLED : ButtonKind.BLUE}
          isShadow
          style={{ container: styles.buttonContainer }}
          text={!sizeRing ? TEXT_ENTER_SIZE : TEXT_ENTER_SUBMIT}
          testID={'SubmitButton'}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: SAFE_AREA_COLOR,
  },
  content: {
    flex: 1,
    position: 'relative',
    backgroundColor: Colors.greyLightest,
  },
  header: {
    backgroundColor: Colors.white,
    paddingBottom: 8,
  },
  reasons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginLeft: 16,
    marginRight: 16,
    justifyContent: 'space-between',
  },
  buttonContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 24,
  },
  title: {
    marginLeft: 16,
    marginTop: 24,
    marginBottom: 16,
  },
});

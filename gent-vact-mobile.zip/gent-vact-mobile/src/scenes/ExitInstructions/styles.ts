import { StyleSheet } from 'react-native';
import { SAFE_AREA_COLOR } from '../../constants/constants';
import { Colors } from '../../utilities/design';

export const styles = StyleSheet.create({
  safeAreaView: {
    flex: 1,
    backgroundColor: SAFE_AREA_COLOR,
  },
  container: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerView: {
    position: 'relative',
    height: 197,
  },
  headerText: {
    marginLeft: 24,
    marginTop: 32,
    marginBottom: 18,
    maxWidth: 248,
  },
  headerComment: {
    marginLeft: 24,
    marginBottom: 41,
    maxWidth: 136,
  },
  image: {
    position: 'absolute',
    top: 62,
    right: 10,
    zIndex: 1,
  },
  nextSteps: {
    marginLeft: 24,
    marginTop: 24,
    marginBottom: 16,
  },
  surveyTaken: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 16,
  },
  takenText: {
    color: Colors.greenLight,
    marginLeft: 8,
  },
});

export const InstructionData = {
  title: 'Thank you for taking part in the trial',
  comment: 'We appreciate your time and effort',
  nextSteps: 'Next steps',
  instructions: [
    {
      title: 'Your continued care',
      text:
        'Please remember that your care visits will continue after this trial, please reach out to your physician to confirm those dates.',
    },

    {
      title: 'Return your devices',
      text: 'Please return the devices provided for the trial to the following address:',
    },
    {
      title: 'Trial exit survey',
      text: 'Please take the following exit survey to provide your feedback on the trial:',
    },
  ],
  button: 'Take the exit survey',
  checked: 'Survey taken',
  buttonText: 'Take the exit survey',
  buttonWaiting: 'Waiting for exit survey',
  buttonTaken: 'Survey taken',
  labelText: 'Trial exit questionnaire complete',
};

export const returnAddress = {
  line1: 'Address line 1',
  line2: 'Address line 2',
  city: 'City',
  state: 'State',
  zipcode: 'Zipcode',
};

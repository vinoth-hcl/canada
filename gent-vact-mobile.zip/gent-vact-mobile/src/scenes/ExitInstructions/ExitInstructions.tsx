import React, { FunctionComponent, useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getExitInstructions, getTrialId } from '../../services/survey/selector';
import { blockExitInstructionsRoute, fetchExitInstructions } from '../../services/survey/actions';
import { getExitSurveyTask } from '../../services/todo/selector';
import { appRoute } from '../../app/actions';
import { MODAL_ROUTES } from '../../navigation/routes';
import { openModal } from '../../services/modal/actions';
import { fetchToDoList } from '../../services/todo/actions';
import { ExitInstructionsView } from './ExitInstructionsView';

interface IExitInstructionsProps {}

export const ExitInstructions: FunctionComponent<IExitInstructionsProps> = () => {
  const dispatch = useDispatch();
  const trailId = useSelector(getTrialId);
  const instructionsData = useSelector(getExitInstructions);
  const surveyTask = useSelector(getExitSurveyTask);

  useEffect(() => {
    dispatch(fetchToDoList());
    dispatch(fetchExitInstructions(trailId));
    dispatch(blockExitInstructionsRoute());
    dispatch(openModal({}));
  }, [trailId, dispatch]);

  const onTakeSurvey = useCallback(() => {
    if (surveyTask) {
      dispatch(
        appRoute(MODAL_ROUTES.SURVEY, {
          taskId: surveyTask.id,
          trialId: surveyTask.trialId,
          type: surveyTask.type,
        }),
      );
    }
  }, [dispatch, surveyTask]);
  return (
    <ExitInstructionsView
      onTakeSurvey={onTakeSurvey}
      instructionsData={instructionsData}
      isSurveyPresent={!!surveyTask}
    />
  );
};

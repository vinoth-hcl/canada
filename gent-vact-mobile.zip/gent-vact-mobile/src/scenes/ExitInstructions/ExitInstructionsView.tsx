import React, { FunctionComponent, useMemo } from 'react';
import { SafeAreaView, ScrollView, View, StyleSheet } from 'react-native';

import { isWebView } from '../../utilities/config';
import { useIsPortrait } from '../../hooks/breakpoints';
import { IExitInstructionsViewProps } from './types';
import { styles } from './styles';
import { ExitInstructionsHeader } from './ExitInstructionsHeader';
import { ExitInstructionsBody } from './ExitInstructionsBody';
import { ExitInstructionsHeaderWeb } from './ExitInstructionsHeaderWeb.web';

export const ExitInstructionsView: FunctionComponent<IExitInstructionsViewProps> = (props) => {
  const isPortrait = useIsPortrait();
  const style = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flexDirection: isPortrait ? 'column' : 'row',
        },
        column: {
          flexBasis: isPortrait ? 'auto' : '50%',
        },
      }),
    [isPortrait],
  );

  if (isWebView()) {
    return (
      <SafeAreaView style={[styles.safeAreaView, { alignItems: 'center' }]}>
        <ScrollView style={{ maxWidth: 1024 }}>
          <View style={style.container}>
            <View style={style.column}>
              <ExitInstructionsHeaderWeb isPortrait={isPortrait} />
            </View>
            <View style={style.column}>
              <ExitInstructionsBody {...props} />
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
  return (
    <SafeAreaView style={styles.safeAreaView}>
      <View style={styles.container}>
        <ScrollView>
          <ExitInstructionsHeader />
          <ExitInstructionsBody {...props} />
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

import { ExitInstructionsDto } from '../../api/ExitInstructionsDto';

export interface IExitInstructionsViewProps {
  instructionsData: ExitInstructionsDto[];
  onTakeSurvey?: () => void;
  isSurveyPresent: boolean;
}

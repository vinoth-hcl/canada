import React, { FunctionComponent } from 'react';
import { Platform, Pressable, View } from 'react-native';

import { useMultiTap } from '../../hooks/useMultiTap';
import { appRoute } from '../../app/actions';
import { AUTH_ROUTES } from '../../navigation/routes';
import { OS_WEB } from '../../constants/constants';
import { GText } from '../../components/GText/GText';
import { TextStyles } from '../../components/GText/styles';
import ImageInstructions from '../../../assets/images/ExitInstructions.svg';
import { styles } from './styles';
import { InstructionData } from './InstructionData';

export const ExitInstructionsHeader: FunctionComponent<{}> = () => {
  const onImageMultiTap = useMultiTap(appRoute(AUTH_ROUTES.LOGOUT));
  const imageHandler =
    Platform.OS === OS_WEB ? { onPressOut: onImageMultiTap } : { onPress: onImageMultiTap };

  return (
    <View style={styles.headerView}>
      <GText style={styles.headerText} textStyle={TextStyles.BITTER_24_28_BOLD}>
        {InstructionData.title}
      </GText>
      <GText style={styles.headerComment} textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}>
        {InstructionData.comment}
      </GText>
      <Pressable style={styles.image} {...imageHandler}>
        <ImageInstructions />
      </Pressable>
    </View>
  );
};

import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { GText } from '../../components/GText/GText';
import { Colors } from '../../utilities/design';
import { TextStyles } from '../../components/GText/styles';

interface IExitInstructionsItemProps {
  index: number;
  title: string;
  description: string;
  surveyButton?: any;
}

export const ExitInstructionsItem: FunctionComponent<IExitInstructionsItemProps> = ({
  index,
  title,
  description,
  surveyButton = null,
}) => {
  const descriptions = description.split('\\n');

  return (
    <View style={styles.instructionBlock}>
      <View style={{ flexDirection: 'row' }}>
        <GText
          textStyle={TextStyles.BITTER_16_24_BOLD}
          style={styles.itemNumber}
          children={index + 1}
          testID={`Instruction_${index + 1}`}
        />
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}
          children={title}
          style={styles.itemTitle}
          testID={`Instruction_${index + 1}`}
        />
      </View>
      {descriptions.map((descItem, itemIndex) => (
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
          style={styles.itemMain}
          children={descItem}
          testID={`Instruction_${index + 1}_${itemIndex}`}
          key={itemIndex}
        />
      ))}
      {surveyButton}
    </View>
  );
};

const styles = StyleSheet.create({
  itemNumber: {
    marginTop: 16,
    marginLeft: 16,
    color: Colors.newBlue,
  },
  itemTitle: {
    marginTop: 16,
    marginLeft: 16,
  },
  itemMain: {
    marginTop: 9,
    marginLeft: 16,
    marginBottom: 16,
  },
  instructionBlock: {
    backgroundColor: Colors.white,
    borderRadius: 8,
    marginLeft: 16,
    marginRight: 16,
    paddingLeft: 16,
    paddingRight: 16,
    marginBottom: 16,
  },
});

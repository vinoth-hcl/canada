import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

import { GText } from '../../components/GText/GText';
import { TextStyles } from '../../components/GText/styles';
import ImageInstructionsLarge from '../../../assets/images/ExitInstructionsLarge.svg';
import { InstructionData } from './InstructionData';

type IExitInstructionsHeaderWebProps = {
  isPortrait: boolean;
};

export const ExitInstructionsHeaderWeb: FunctionComponent<IExitInstructionsHeaderWebProps> = ({
  isPortrait = false,
}) => {
  return (
    <View style={StyleSheet.flatten([styles.container, isPortrait && styles.containerVertical])}>
      <View style={styles.image}>
        <ImageInstructionsLarge />
      </View>
      <View style={StyleSheet.flatten([isPortrait && styles.content])}>
        <GText
          style={StyleSheet.flatten([styles.text, isPortrait && styles.textVertical])}
          textStyle={TextStyles.BITTER_24_28_BOLD}
          children={InstructionData.title}
        />
        <GText
          style={StyleSheet.flatten([styles.text, isPortrait && styles.textVertical])}
          textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
          children={InstructionData.comment}
        />
      </View>
    </View>
  );
};

export const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flex: 1,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  containerVertical: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  image: {
    marginTop: 20,
    marginBottom: 20,
    width: 247,
    height: 268,
    marginLeft: 50,
  },
  content: {
    flex: 1,
  },
  text: {
    textAlign: 'center',
    marginLeft: 80,
    marginRight: 80,
    marginBottom: 16,
  },
  textVertical: {
    textAlign: 'left',
    marginRight: 40,
    marginLeft: 40,
  },
});

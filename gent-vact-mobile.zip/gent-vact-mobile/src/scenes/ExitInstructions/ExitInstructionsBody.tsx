import React, { FunctionComponent, useMemo } from 'react';
import { View, useWindowDimensions, StyleSheet } from 'react-native';

import { Button } from '../../components/Button/Button';
import { ButtonKind } from '../../components/Button/types';
import { Colors } from '../../utilities/design';
import { GText } from '../../components/GText/GText';
import { TextStyles } from '../../components/GText/styles';
import Confirm from '../../../assets/images/ConfirmGreen.svg';
import { getScreenModel, WebViews } from '../../components/WebLayoutTemplate/WebLayoutTemplate';
import { styles } from './styles';
import { InstructionData } from './InstructionData';
import { IExitInstructionsViewProps } from './types';
import { ExitInstructionsItem } from './ExitInstructionsItem';

const completeSurveyLabel = (
  <View style={{ flexDirection: 'row', marginBottom: 28, marginLeft: 16 }}>
    <View style={{ marginRight: 12 }}>
      <Confirm />
    </View>
    <GText textStyle={TextStyles.SOURCE_SANS_16_24_BOLD} style={{ color: Colors.greenDarker }}>
      {InstructionData.labelText}
    </GText>
  </View>
);

export const ExitInstructionsBody: FunctionComponent<IExitInstructionsViewProps> = ({
  isSurveyPresent,
  instructionsData,
  onTakeSurvey,
}) => {
  const dimensions = useWindowDimensions();
  const screenModel = useMemo(() => getScreenModel(dimensions.width), [dimensions.width]);

  const surveyButton = useMemo(() => {
    return (
      <Button
        kind={ButtonKind.MAIN_BLUE}
        isShadow
        style={buttonStyle}
        text={InstructionData.buttonText}
        testID={'SubmitButton'}
        onPress={onTakeSurvey}
      />
    );
  }, [onTakeSurvey]);

  return (
    <View
      style={StyleSheet.flatten([
        {
          backgroundColor: Colors.whiteGray,
        },
        (screenModel === WebViews.LARGE || screenModel === WebViews.MEDIUM) && {
          height: dimensions.height,
        },
      ])}
    >
      {(isSurveyPresent || instructionsData.length > 0) && (
        <GText style={styles.nextSteps} textStyle={TextStyles.SOURCE_SANS_16_24_BOLD}>
          {InstructionData.nextSteps}
        </GText>
      )}

      <ExitInstructionsItem
        index={0}
        key={0}
        title={InstructionData.instructions[2].title}
        description={InstructionData.instructions[2].text}
        surveyButton={isSurveyPresent ? surveyButton : completeSurveyLabel}
      />

      {instructionsData.map((item, index) => {
        return (
          <ExitInstructionsItem
            index={index + 1}
            key={index + 1}
            title={item.title}
            description={item.description}
          />
        );
      })}
    </View>
  );
};

const buttonStyle: any = {
  container: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  textStyle: {},
};

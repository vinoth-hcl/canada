import { View, Text } from 'react-native';
import React from 'react';

export function App() {
  return (
    <View
      style={{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#44bb44',
      }}
    >
      <View>
        <Text style={{ color: '#ffffff' }}>{'Hello World'}</Text>
      </View>
    </View>
  );
}

export default App;

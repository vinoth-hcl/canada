// console.log('__CONFIG__', process.env.__CONFIG__)
const config = process.env.__CONFIG__;

export default config;

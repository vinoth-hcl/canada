import React, { FunctionComponent, useMemo } from 'react';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';

import { Platform } from 'react-native';
import { backgroundFcm, useFcm, fcmNotifications } from '../services/notifications/firebase/saga';
import { RootNavigator } from '../navigation/RootNavigator';
import { DeniedAppPage } from '../scenes/DeniedAppPage/DeniedAppPage';
import { isAppForbidden } from '../utilities/app';
import { useStatusBar } from '../hooks/useSatusBar';
import { initLocalPushNotifications } from '../services/notifications/localNotification';
import Feather from './Feather';
import { configureStore } from './configure-store';

import { LogBox } from './LogBox';

Feather.loadFont();

if (__DEV__) {
  import('./ReactotronConfig').then(() => {
    // eslint-disable-next-line no-console
    console.log('Reactotron Configured');
  });
}

LogBox.ignoreLogs(['Setting a timer']);
LogBox.ignoreLogs(['Remote debugger']);
LogBox.ignoreLogs(['currentlyFocusedField']);
LogBox.ignoreAllLogs();

const { store, persistor } = configureStore();

backgroundFcm(store, fcmNotifications);
initLocalPushNotifications(store);

export const App: FunctionComponent<{}> = () => {
  const Application = useMemo(() => {
    if (isAppForbidden()) {
      return DeniedAppPage;
    }

    return () => (
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <RootNavigator />
        </PersistGate>
      </Provider>
    );
  }, []);

  useFcm(store, fcmNotifications);

  useStatusBar(Platform.OS);

  return <Application />;
};

module.exports = App;

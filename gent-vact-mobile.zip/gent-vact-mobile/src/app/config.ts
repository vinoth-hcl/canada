import config from 'react-native-config';

export default config;

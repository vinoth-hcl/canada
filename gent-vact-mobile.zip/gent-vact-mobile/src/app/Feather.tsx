import Feather from 'react-native-vector-icons/Feather';

export default Feather;

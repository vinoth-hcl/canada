import { noop } from 'lodash';

export const requestPermissions = noop;

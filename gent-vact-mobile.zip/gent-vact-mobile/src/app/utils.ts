export const makeNestedParams = ({
  routes,
  index = 0,
  params = {},
}: {
  routes: string[];
  index?: number;
  params?: any;
}): { screen: string; params: any } => {
  if (routes.length > index) {
    return {
      screen: routes[index],
      params: makeNestedParams({ routes, index: index + 1, params }),
    };
  }
  return params;
};

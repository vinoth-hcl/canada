import { put, spawn, take, fork, select } from 'redux-saga/effects';
import { createRequestInstance, error, success, watchRequests } from 'redux-saga-requests';
import { createDriver } from 'redux-saga-requests-fetch';
import { REHYDRATE } from 'redux-persist/lib/constants';
// import config from 'react-native-config';

import { withdrawSaga } from '../services/withdraw/saga';
import { patientSaga } from '../services/patient/saga';
import { heartbeatSagas } from '../services/sensors/heartRate/saga';
import { refreshTokenSaga } from '../services/authentication/saga';
import { notificationsSaga, backgroundSaga } from '../services/notifications/saga';
// TODO: use fetchDriver to force api call timeout
// import { fetchDriver } from './entities';
import { externalAppsSaga } from '../services/externalApps/saga';
import { feedbackSaga } from '../services/feedback/saga';
import { toDoSaga } from '../services/todo/saga';
import { appointmentsSaga } from '../services/appointments/saga';
import { certificateSaga } from '../services/certificate/saga';
import { optionsSaga } from '../services/options/saga';
import { reasonSaga } from '../scenes/RescheduleAppointment/saga';
import { supportSaga } from '../services/support/saga';
import { surveySaga } from '../services/survey/saga';
import { getApiURL, getFeatureFlag } from '../utilities/config';
import { metricsSaga } from '../services/metrics/saga';
import { beacon } from '../utilities/reduxRequestBeacon';
import { keychainSaga } from '../services/info/saga';
import { FETCH_REFRESH_TOKENS, fetchRefreshTokens } from '../services/authentication/actions';
import { getRefreshTokenSelector } from '../services/info/selectors';
import { welcomeSaga } from '../scenes/Welcome/saga';
import { setTimezone } from '../services/options/actions';
import { onRequest, onSuccess, onError } from './interceptors';
import { appSaga } from './saga';
import { appInitialized } from './actions';
import { isAuthenticatedSelector } from './selectors';

const driver = {
  default: createDriver(fetch, {
    baseURL: getApiURL(),
  }),
  beacon,
};

export function* rootSaga() {
  yield spawn(backgroundSaga);
  yield spawn(metricsSaga);
  yield take(REHYDRATE);
  const conf = {
    driver,
    onRequest,
    onSuccess,
    onError,
  };
  yield createRequestInstance(conf);
  yield fork(watchRequests);

  yield spawn(refreshTokenSaga);

  yield spawn(appSaga);
  const refresh_token = yield select(getRefreshTokenSelector);
  const isAuthenticated = yield select(isAuthenticatedSelector);
  if (isAuthenticated && refresh_token) {
    yield put(fetchRefreshTokens(refresh_token));
    yield take([success(FETCH_REFRESH_TOKENS), error(FETCH_REFRESH_TOKENS)]);
    yield put(setTimezone());
  }

  yield spawn(keychainSaga);
  yield spawn(patientSaga);
  yield spawn(heartbeatSagas);
  yield spawn(externalAppsSaga);
  yield spawn(notificationsSaga);
  yield spawn(feedbackSaga);
  yield spawn(toDoSaga);
  yield spawn(appointmentsSaga);
  yield spawn(optionsSaga);
  yield spawn(reasonSaga);
  yield spawn(supportSaga);
  yield spawn(surveySaga);
  yield spawn(withdrawSaga);
  yield spawn(welcomeSaga);

  if (getFeatureFlag('useIotCertificate')) {
    yield spawn(certificateSaga);
  }

  yield put(appInitialized());
}

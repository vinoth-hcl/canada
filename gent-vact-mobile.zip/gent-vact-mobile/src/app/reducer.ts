import { success } from 'redux-saga-requests';
import { get } from 'lodash';

import schemaProfileConfig from '../api/ProfileConfig.out.json';
import schemaBackendVersion from '../api/BackendVersion.out.json';
import { TemperatureModes } from '../utilities/converter';
import { fillDefaults } from '../services/schema/fill-defaults';
import { BackendVersion } from '../api/BackendVersion';
import {
  CLOSE_MODAL,
  ICloseModalAction,
  IOpenModalAction,
  OPEN_MODAL,
} from '../services/modal/actions';
import { pathLens, replace, view } from '../services/lens/lens';
import { getConfigString } from '../utilities/config';
import { IANA_TIMEZONE_DEFAULT } from '../constants/constants';
import {
  APP_AUTH_STATE,
  APP_SAVE_FCM_TOKEN,
  CLEAR_APP_STORE,
  FETCH_BACKEND_VERSION,
  FETCH_CONFIGURATION_PROFILE,
  IAppActions,
  RESET_USER_PROFILE,
  START_VIDEO_CONF,
  IRunAppState,
  SET_COUNT_START_PAGE,
} from './actions';
import { AppAuthState, BACKGROUND, FOREGROUND, IAppState, INACTIVE, IProfileConfig } from './types';

const temperatureMode = TemperatureModes.FAHRENHEIT;
const iana = getConfigString('IANA_TIMEZONE_DEFAULT', IANA_TIMEZONE_DEFAULT);

export const profileInitialState: IProfileConfig = {
  id: '',
  name: '',
  username: '',
  roles: [],
  temperatureMode,
  profileMeasurementsConfiguration: {},
  permissions: [],
  siteName: '',
  timezone: {
    iana,
    abbreviation: '',
  },
};

export const backendVersionInitialState: BackendVersion = {
  buildVersion: '',
  buildName: '',
  buildTime: '',
};

export const initialState: IAppState = {
  authState: AppAuthState.INITIAL,
  profile: profileInitialState,
  fcmToken: '',
  backendVersion: backendVersionInitialState,
  isModalOpen: false,
  startPage: {},
  isShowStartPage: false,
  activeVideoCallAppointmentId: '',
  appState: BACKGROUND,
};

export function app(
  state: IAppState = initialState,
  action: IAppActions | IOpenModalAction | ICloseModalAction | IRunAppState,
) {
  switch (action.type) {
    case CLEAR_APP_STORE: {
      return { ...initialState, backendVersion: state.backendVersion, startPage: state.startPage };
    }
    case APP_AUTH_STATE: {
      const { authState } = action;
      return {
        ...state,
        authState,
      };
    }
    case APP_SAVE_FCM_TOKEN: {
      const { fcmToken } = action;

      return {
        ...state,
        fcmToken,
      };
    }

    case success(FETCH_BACKEND_VERSION): {
      const response = get(action, 'response.data', backendVersionInitialState);
      const schemaResponse = fillDefaults(schemaBackendVersion)(response);
      return {
        ...state,
        backendVersion: schemaResponse,
      };
    }

    case success(FETCH_CONFIGURATION_PROFILE): {
      const response = get(action, 'response.data', profileInitialState);
      const schemaResponse = fillDefaults(schemaProfileConfig)(response);
      return {
        ...state,
        profile: { ...schemaResponse, temperatureMode },
      };
    }
    case RESET_USER_PROFILE: {
      const schemaResponse = fillDefaults(schemaProfileConfig)(profileInitialState);
      return {
        ...state,
        profile: { ...schemaResponse, temperatureMode },
      };
    }
    case OPEN_MODAL: {
      return { ...state, isModalOpen: true };
    }
    case CLOSE_MODAL: {
      return { ...state, isModalOpen: false };
    }
    case SET_COUNT_START_PAGE: {
      const { id } = action.payload;
      const startPageById = view(pathLens('startPage'), state);
      const currentCount = view(pathLens(`startPage.${id}.count`), state);

      const isShowStartPage = true;
      const count = currentCount ? currentCount + 1 : 1;
      const result = { ...startPageById, [id]: { count } };

      return replace(
        pathLens('isShowStartPage'),
        isShowStartPage,
        replace(pathLens('startPage'), result, state),
      );
    }
    case START_VIDEO_CONF: {
      const activeVideoCallAppointmentId = action?.payload?.appointmentId;

      return { ...state, activeVideoCallAppointmentId };
    }
    case BACKGROUND: {
      return {
        ...state,
        appState: BACKGROUND,
      };
    }
    case FOREGROUND: {
      return {
        ...state,
        appState: FOREGROUND,
      };
    }
    case INACTIVE: {
      return {
        ...state,
        appState: INACTIVE,
      };
    }
    default:
      return state;
  }
}

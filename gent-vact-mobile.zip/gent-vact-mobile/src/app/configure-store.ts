import { applyMiddleware, compose, createStore } from 'redux';
import { persistStore, persistReducer, createTransform } from 'redux-persist';
import createSagaMiddleware from 'redux-saga';
import { createLogger } from 'redux-logger';
import applyAppStateListener from 'redux-enhancer-react-native-appstate';
import { get } from 'lodash';

// import AsyncStorage from '@react-native-community/async-storage';
import hardSet from 'redux-persist/es/stateReconciler/hardSet';
// import config from 'react-native-config';

// @ts-ignore
import { omitDeep } from '../utilities/omitDeep';
import { predefineNestedProperties } from '../utilities/configureStore';
import { getApiURL } from '../utilities/config';
import { KEY_REFRESH_TKN, KEY_TKN } from '../services/info/saga';
import { pathLens, replace } from '../services/lens/lens';
import { KEY_CERTIFICATE } from '../services/certificate/saga';
import storage from './storage';
import VersionNumber from './VersionNumber';

import { rootSaga } from './root-saga';
import rootReducer from './root-reducer';
import KeychainStorage from './KeychainStorage';

const omitFlags = (flags: string[], keys?: (string | number | symbol)[]) => {
  return createTransform((inboundState: any, key) => {
    if (Array.isArray(keys) && !keys.includes(key)) {
      return inboundState;
    }
    return omitDeep(inboundState, flags);
  });
};

const migrate = async (state: any, version: number) => {
  const prevVersion = get(state, '_persist.version');
  const result = version === prevVersion ? state : rootReducer({}, { type: 'UNKNOWN' });
  const access_token = await KeychainStorage.getItem({
    key: KEY_TKN,
  });

  const refresh_token = await KeychainStorage.getItem({
    key: KEY_REFRESH_TKN,
  });

  const certificate = await KeychainStorage.getItem({
    key: KEY_CERTIFICATE,
  });

  const data = certificate ? await JSON.parse(certificate) : {};
  const isShowStartPage = false;

  return replace(
    pathLens('app.isShowStartPage'),
    isShowStartPage,
    replace(
      pathLens('certificateData.data'),
      data,
      replace(pathLens('info'), { access_token, refresh_token }, result),
    ),
  );
};

const persistConfig = {
  timeout: 0,
  key: 'root',
  storage,
  whitelist: ['app', 'patient', 'notifications'],
  blacklist: [],
  version: 11,
  migrate,
  stateReconciler: hardSet,
  transforms: [
    omitFlags(['pending']),
    predefineNestedProperties({
      app: [{ path: 'isModalOpen', value: false }],
      notifications: [
        { path: 'activeNotification', value: {} },
        { path: 'areEnabled', value: true },
      ],
    }),
  ],
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

const sagaMiddleware = createSagaMiddleware();

const middlewares = [];
middlewares.push(sagaMiddleware);

if (process.env.NODE_ENV === 'development') {
  const logger = createLogger({
    collapsed: true,
    diff: true,
  });
  middlewares.push(logger);
}

const enhancer = applyMiddleware(...middlewares);

const store = createStore(persistedReducer, compose(applyAppStateListener(), enhancer));

sagaMiddleware.run(rootSaga);

if (process.env.NODE_ENV === 'development') {
  // eslint-disable-next-line no-console
  console.log('FrontendVersion', VersionNumber.appVersion);
  // eslint-disable-next-line no-console
  console.log('ApiURL', getApiURL());
}

export function configureStore() {
  return {
    store: {
      ...store,
      runSaga: sagaMiddleware.run,
    },
    get persistor() {
      return persistStore(store);
    },
  };
}

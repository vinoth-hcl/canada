import { Action, AnyAction } from 'redux';
import { IApiAction } from '../services/redux/ApiAction';
import { GET_BACKEND_VERSION_ENDPOINT, GET_CONFIGURATION_PROFILE } from '../api/endpoints';
import { AppAuthState, RunAppStateType, LogLevel } from './types';
import { APP_INITIALIZED } from './actionsTypes';

export const RESET_USER_PROFILE = 'RESET_USER_PROFILE';
export interface IResetUserProfile {
  type: typeof RESET_USER_PROFILE;
}
export function resetUserProfile(): IResetUserProfile {
  return {
    type: RESET_USER_PROFILE,
  };
}

export const FETCH_CONFIGURATION_PROFILE = 'FETCH_CONFIGURATION_PROFILE';
export const FETCH_BACKEND_VERSION = 'FETCH_BACKEND_VERSION';
export const CLEAR_APP_STORE = 'CLEAR_APP_STORE';
export const CLEAR_PERSISTED_STORE = 'CLEAR_PERSISTED_STORE';
export const START_OURA_APP = 'START_OURA_APP';
export const MAKE_PHONE_CALL = 'MAKE_PHONE_CALL';
export const START_TEAMS_APP = 'START_TEAMS_APP';
export const SET_COUNT_START_PAGE = 'SET_COUNT_START_PAGE';
export const START_VIDEO_CONF = 'START_VIDEO_CONF';
export const MODAL_ROUTE_LOADED = 'MODAL_ROUTE_LOADED';
export const IS_CONNECT_NETWORK = 'IS_CONNECT_NETWORK';

export interface IClearPersistedStore extends AnyAction {
  type: typeof CLEAR_PERSISTED_STORE;
}

export function clearPersistedStore(): IClearPersistedStore {
  return {
    type: CLEAR_PERSISTED_STORE,
  };
}

export interface IClearAppStore extends AnyAction {
  type: typeof CLEAR_APP_STORE;
}

export function clearAppStore(): IClearAppStore {
  return {
    type: CLEAR_APP_STORE,
  };
}

export const APP_LOG = 'APP_LOG';
export interface IAppLog extends Action {
  type: typeof APP_LOG;
  name: string;
  payload: any;
  level: LogLevel;
}
export function appLog(name: string, payload: any, level = LogLevel.INFO): IAppLog {
  return {
    type: APP_LOG,
    name,
    payload,
    level,
  };
}

export const APP_ROUTE = 'APP_ROUTE';
export interface IAppRoute extends Action {
  type: typeof APP_ROUTE;
  route: string;
  params: any;
  key: string;
}
export function appRoute(route: string, params?: any, key?: any): IAppRoute {
  return {
    type: APP_ROUTE,
    route,
    params,
    key,
  };
}

export const REPLACE_ROUTE = 'REPLACE_ROUTE';
export interface IReplaceRoute extends Action {
  type: typeof REPLACE_ROUTE;
  route: string;
  params: any;
}
export function replaceRoute(route: string, params?: any): IReplaceRoute {
  return {
    type: REPLACE_ROUTE,
    route,
    params,
  };
}

export const BACK_ROUTE = 'BACK_ROUTE';
export interface IBackRouteAction extends Action {
  type: typeof BACK_ROUTE;
}
export function backRouteAction(): IBackRouteAction {
  return {
    type: BACK_ROUTE,
  };
}

export const APP_AUTH_STATE = 'APP_AUTH_STATE';
export interface IAppAuthState extends Action {
  type: typeof APP_AUTH_STATE;
  authState: AppAuthState;
}
export function appAuthState(authState: AppAuthState): IAppAuthState {
  return {
    type: APP_AUTH_STATE,
    authState,
  };
}

export const APP_LOGIN_SUCCESS = 'APP_LOGIN_SUCCESS';
export interface IAppLoginSuccess extends Action {
  type: typeof APP_LOGIN_SUCCESS;
}
export function appLoginSuccess(): IAppLoginSuccess {
  return {
    type: APP_LOGIN_SUCCESS,
  };
}

export interface IAppInitalized extends Action {
  type: typeof APP_INITIALIZED;
}
export function appInitialized(): IAppInitalized {
  return {
    type: APP_INITIALIZED,
  };
}

export const APP_SAVE_FCM_TOKEN = 'APP_SAVE_FCM_TOKEN';
export interface IAppSaveToken extends Action {
  type: typeof APP_SAVE_FCM_TOKEN;
  fcmToken: string;
}
export function appSaveFCMToken(fcmToken: string): IAppSaveToken {
  return {
    type: APP_SAVE_FCM_TOKEN,
    fcmToken,
  };
}

export interface IFetchConfigurationAction extends IApiAction {
  type: typeof FETCH_CONFIGURATION_PROFILE;
}

export function fetchConfigurationProfile(): IFetchConfigurationAction {
  return {
    type: FETCH_CONFIGURATION_PROFILE,
    request: {
      method: 'GET',
      url: GET_CONFIGURATION_PROFILE,
    },
  };
}

export interface IFetchBackendVersionAction extends IApiAction {
  type: typeof FETCH_BACKEND_VERSION;
}

export function fetchBackendVersion(): IFetchBackendVersionAction {
  return {
    type: FETCH_BACKEND_VERSION,
    request: {
      method: 'GET',
      url: GET_BACKEND_VERSION_ENDPOINT,
    },
    meta: {
      noAuth: true,
    },
  };
}

export interface IExecuteOura extends AnyAction {
  type: typeof START_OURA_APP;
  payload: {
    taskId?: string;
  };
}

export function startOuraRing(taskId?: string): IExecuteOura {
  return {
    type: START_OURA_APP,
    payload: {
      taskId,
    },
  };
}

export interface IMakePhoneCall extends AnyAction {
  type: typeof MAKE_PHONE_CALL;
}

export function makePhoneCallAction(number: string, contactTitle: string): IMakePhoneCall {
  return {
    type: MAKE_PHONE_CALL,
    number,
    contactTitle,
  };
}

export interface IExecuteTeams extends AnyAction {
  type: typeof START_TEAMS_APP;
}

export interface IRunAppState extends Action {
  type: RunAppStateType;
}

export function startTeams(connection: string): IExecuteTeams {
  return {
    type: START_TEAMS_APP,
    connection,
  };
}

export interface IStartVideoConf extends AnyAction {
  type: typeof START_VIDEO_CONF;
}

export function startVideoConf(
  connection: string,
  appointmentId: string | undefined,
): IStartVideoConf {
  return {
    type: START_VIDEO_CONF,
    payload: { connection, appointmentId },
  };
}

export interface ISetCountStartPage extends AnyAction {
  type: typeof SET_COUNT_START_PAGE;
  payload: {
    id: string;
  };
}

export function setCountStartPage(id: string): ISetCountStartPage {
  return {
    type: SET_COUNT_START_PAGE,
    payload: { id },
  };
}

export interface IModalRouteLoaded extends Action {
  type: typeof MODAL_ROUTE_LOADED;
}

export function modalRouteLoaded(): IModalRouteLoaded {
  return {
    type: MODAL_ROUTE_LOADED,
  };
}

export interface IIsConnectNetwork extends Action {
  type: typeof IS_CONNECT_NETWORK;
  payload: {
    isConnected: boolean;
  };
}

export function isConnectNetwork(isConnected: boolean): IIsConnectNetwork {
  return {
    type: IS_CONNECT_NETWORK,
    payload: { isConnected },
  };
}

export type IAppActions =
  | IResetUserProfile
  | IAppLog
  | IAppRoute
  | IReplaceRoute
  | IAppAuthState
  | IAppSaveToken
  | IFetchConfigurationAction
  | IFetchBackendVersionAction
  | IClearAppStore
  | ISetCountStartPage
  | IExecuteOura
  | IMakePhoneCall
  | IStartVideoConf
  | IModalRouteLoaded;

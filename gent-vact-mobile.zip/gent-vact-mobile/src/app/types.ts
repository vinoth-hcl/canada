import { IWithdrawState } from '../services/withdraw/types';
import { IPatientState } from '../services/patient/types';
import { ProfileConfig } from '../api/ProfileConfig';
import { TemperatureModes } from '../utilities/converter';
import { BackendVersion } from '../api/BackendVersion';
import { IToDoListState } from '../services/todo/reducer';
import { INotificationsState } from '../services/notifications/reducer';
import { TCurrentTab as TCurrentTabState } from '../services/navigation/actions';
import { TCertificateState } from '../services/certificate/reducers';
import { IAppointmentsState } from '../services/appointments/types';
import { ISurveyState } from '../services/survey/types';
import { ISupportState } from '../services/support/types';
import { IInfoState } from '../services/info/reducer';

export enum LogLevel {
  INFO = 'INFO',
  WARNING = 'WARNING',
  ERROR = 'ERROR',
}

export type RunAppStateType = typeof FOREGROUND | typeof BACKGROUND | typeof INACTIVE;

export enum AppAuthState {
  INITIAL = 'INITIAL',
  IN_PROGRESS = 'IN_PROGRESS',
  AUTHENTICATED = 'AUTHENTICATED',
  REFRESH_IN_PROGRESS = 'REFRESH_IN_PROGRESS',
  ERROR = 'ERROR',
}

export interface IProfileConfig extends ProfileConfig {
  temperatureMode: TemperatureModes;
}

export interface IAppState {
  authState: AppAuthState;
  profile: IProfileConfig;
  fcmToken: string;
  backendVersion: BackendVersion;
  isModalOpen: boolean;
  startPage: { [key: string]: { count: number } };
  isShowStartPage: boolean;
  activeVideoCallAppointmentId: string;
  appState: RunAppStateType;
}

export type IStoreState = {
  app: IAppState;
  info: IInfoState;
  patient: IPatientState;
  toDoList: IToDoListState;
  notifications: INotificationsState;
  currentTab: TCurrentTabState;
  certificateData: TCertificateState;
  appointments: IAppointmentsState;
  survey: ISurveyState;
  support: ISupportState;
  withdraw: IWithdrawState;
};

export const BACKGROUND = 'APP_STATE.BACKGROUND';
export const FOREGROUND = 'APP_STATE.FOREGROUND';
export const INACTIVE = 'APP_STATE.INACTIVE';

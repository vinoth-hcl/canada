import { delay, call, debounce, put, select, take, takeEvery } from 'redux-saga/effects';
import { Platform } from 'react-native';
import 'react-native-get-random-values';
import { v4 as uuidv4 } from 'uuid';
import { get } from 'lodash';
import NetInfo from '@react-native-community/netinfo';

import { back, navigate, replace } from '../navigation/NavigationService';
import { getCurrentTab } from '../services/navigation/selectors';
import { logToggleTab } from '../services/navigation/actions';
import { clearPatientStore, fetchPatientProfile } from '../services/patient/actions';
import { clearCertificateStore } from '../services/certificate/actions';
import {
  cancelOwnNotification,
  clearNotificationsStore,
  createOwnNotification,
} from '../services/notifications/actions';
import {
  executeOura,
  executeOuraIos,
  executeTeams,
  openURL,
  makePhoneCall,
} from '../services/externalApps/utils';
import { getAppStatus } from '../services/externalApps/selector';
import { ExternalApps } from '../services/externalApps/types';
import {
  DEFAULT_OURA_RING_CHARGE_DURATION,
  TEXT_OURA_CHARGE_COMPLETE,
  OS_ANDROID,
  OS_WEB,
  OURA_NOT_INSTALLED,
  TEAMS_NOT_INSTALLED,
  OS_IOS,
  TEXT_NO_NET_CONNECT,
  OURA_NOT_AVAILABLE_WEB,
  TEXT_OK,
  getMakePhoneCallMessage,
} from '../constants/constants';
import { AUTH_ROUTES, MODAL_ROUTES } from '../navigation/routes';
import { ModalType } from '../scenes/Modal/ModalContent';
import { getConfigNumber, getFeatureFlag } from '../utilities/config';
import { OWN_NOTIFICATION_TYPES, TOwnNotification } from '../services/notifications/types';
import { removeKeychain } from '../services/info/actions';
import { completeToDoTask } from '../services/todo/actions';
import { putAuth } from '../utilities/effects';
import {
  APP_ROUTE,
  appAuthState,
  appRoute,
  BACK_ROUTE,
  CLEAR_PERSISTED_STORE,
  clearAppStore,
  fetchBackendVersion,
  IAppRoute,
  IExecuteOura,
  IExecuteTeams,
  IIsConnectNetwork,
  IMakePhoneCall,
  IS_CONNECT_NETWORK,
  isConnectNetwork,
  IStartVideoConf,
  MAKE_PHONE_CALL,
  REPLACE_ROUTE,
  START_OURA_APP,
  START_TEAMS_APP,
  START_VIDEO_CONF,
} from './actions';
import { AppAuthState } from './types';
import { appSelector, isModalOpenSelector } from './selectors';
import { APP_INITIALIZED } from './actionsTypes';
import { makeNestedParams } from './utils';

const DEBOUNCE = 3000;
const DELAY = 5000;

export function* onRoute(action: IAppRoute) {
  const { route, params, key } = action;
  const currentTab = yield select(getCurrentTab);
  const routes = route.split(':');

  if (currentTab) {
    yield put(logToggleTab(''));
  }

  if (routes.length > 1) {
    navigate(routes[0], makeNestedParams({ routes, index: 1, params }), key);
  } else {
    navigate(route, params, key);
  }
}

export function* onReplaceRoute(action: IAppRoute) {
  const { route, params } = action;

  const routes = route.split(':');

  if (routes.length > 1) {
    replace(routes[0], makeNestedParams({ routes, index: 1, params }));
  } else {
    replace(route, params);
  }
}

export function* backRoute() {
  back();
}

function getOuraChargeNotificationData(): TOwnNotification {
  return {
    id: uuidv4(),
    description: TEXT_OURA_CHARGE_COMPLETE,
    createdAt: new Date().toString(),
    notificationType: OWN_NOTIFICATION_TYPES.OURA_RING_CHARGE_COMPLETE,
  };
}

function* scheduleOuraChargeNotification(notification: TOwnNotification) {
  const chargeDuration = getConfigNumber(
    'OURA_RING_CHARGE_DURATION',
    DEFAULT_OURA_RING_CHARGE_DURATION,
  );

  yield put(createOwnNotification(notification, chargeDuration));
}

export function* onStartOura({ payload: { taskId } }: IExecuteOura) {
  // Create notification for the dashboard tasks only (excluding Oura call from the settings tab)
  switch (Platform.OS) {
    case OS_WEB:
      yield put(
        appRoute(MODAL_ROUTES.MODAL_MESSAGE, {
          type: ModalType.ERROR,
          message: OURA_NOT_AVAILABLE_WEB,
        }),
      );
      return;
    case OS_ANDROID:
      const isInstalledOura = yield select(getAppStatus(ExternalApps.OURA));

      if (isInstalledOura) {
        if (taskId) {
          const notification = getOuraChargeNotificationData();

          yield* scheduleOuraChargeNotification(notification);
          yield put(completeToDoTask(taskId));
        }

        executeOura();
      } else {
        yield put(
          appRoute(MODAL_ROUTES.MODAL_MESSAGE, {
            type: ModalType.ERROR,
            message: OURA_NOT_INSTALLED,
          }),
        );
      }

      return;
    case OS_IOS:
    default:
      const notification = getOuraChargeNotificationData();

      if (taskId) {
        yield* scheduleOuraChargeNotification(notification);
      }

      const error = yield call(executeOuraIos);

      if (error === 1) {
        yield put(
          appRoute(MODAL_ROUTES.MODAL_MESSAGE, {
            type: ModalType.ERROR,
            message: OURA_NOT_INSTALLED,
          }),
        );

        if (taskId) {
          yield put(cancelOwnNotification(notification));
        }
      } else if (taskId) {
        yield put(completeToDoTask(taskId));
      }
      return;
  }
}

export function* onClearPersistedStore() {
  yield put(clearAppStore());
  yield put(clearPatientStore());
  yield put(clearCertificateStore());
  yield put(clearNotificationsStore());
  yield put(removeKeychain());
}

export function* onMakeCall(action: IMakePhoneCall) {
  if (getFeatureFlag('makePhoneCall')) {
    if (Platform.OS === OS_WEB) {
      window.open(`tel:${action.number}`, '_blank');
    } else {
      makePhoneCall(action.number);
    }
  } else {
    yield put(
      appRoute(MODAL_ROUTES.MODAL_MESSAGE, {
        type: ModalType.YELLOW,
        message: getMakePhoneCallMessage(action.number, action.contactTitle),
        buttons: [{ text: TEXT_OK }],
      }),
    );
  }
}

export function* onStartTeams(action: IExecuteTeams) {
  if (Platform.OS === OS_ANDROID) {
    const isInstalledTeams = yield select(getAppStatus(ExternalApps.TEAMS));
    if (isInstalledTeams) {
      executeTeams(action.connection);
    } else {
      yield put(
        appRoute(MODAL_ROUTES.MODAL_MESSAGE, {
          type: ModalType.ERROR,
          message: TEAMS_NOT_INSTALLED,
        }),
      );
    }
  } else {
    openURL(action.connection);
  }
}

export function* onStartVideoConf({ payload }: IStartVideoConf) {
  openURL(payload.connection);
}

export function* onAppInitialized() {
  yield checkIsConnectNetwork();
  yield putAuth(fetchPatientProfile());
}

export function* checkIsConnectNetwork() {
  let isConnected: boolean = true;
  const setIsConnected = (status = false) => {
    isConnected = status;
  };

  yield NetInfo.fetch().then((state) => {
    setIsConnected(state.isConnected);
  });

  if (!isConnected) {
    yield put(isConnectNetwork(isConnected));
  }
}

export function* handleConnectionNetwork(action: IIsConnectNetwork) {
  const isConnected = get(action, ['payload', 'isConnected'], false);
  const isOpenModal = yield select(isModalOpenSelector);
  if (!isConnected && getFeatureFlag('checkNetInfo')) {
    if (!isOpenModal) {
      yield put(
        appRoute(AUTH_ROUTES.MODAL_MESSAGE, {
          type: ModalType.NO_NET_CONNECT,
          message: TEXT_NO_NET_CONNECT,
        }),
      );
    }
    yield delay(DELAY);
    yield checkIsConnectNetwork();
  }
}

export function* appSaga() {
  yield takeEvery(APP_ROUTE, onRoute);
  yield takeEvery(REPLACE_ROUTE, onReplaceRoute);
  yield takeEvery(BACK_ROUTE, backRoute);
  yield takeEvery(CLEAR_PERSISTED_STORE, onClearPersistedStore);
  yield takeEvery(START_OURA_APP, onStartOura);
  yield takeEvery(MAKE_PHONE_CALL, onMakeCall);
  yield takeEvery(START_TEAMS_APP, onStartTeams);
  yield takeEvery(START_VIDEO_CONF, onStartVideoConf);
  yield takeEvery(APP_INITIALIZED, onAppInitialized);

  yield debounce(DEBOUNCE, IS_CONNECT_NETWORK, handleConnectionNetwork);

  yield take(APP_INITIALIZED);
  yield put(fetchBackendVersion());

  const { authState } = yield select(appSelector);
  if (authState !== AppAuthState.AUTHENTICATED) {
    yield put(appAuthState(AppAuthState.INITIAL));
  }
}

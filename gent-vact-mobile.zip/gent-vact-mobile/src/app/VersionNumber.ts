import VersionNumber from 'react-native-version-number';

export default VersionNumber;

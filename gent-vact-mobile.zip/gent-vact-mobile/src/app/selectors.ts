import { get } from 'lodash';

import { createSelector } from 'reselect';
import { TimezoneDto } from '../api/TimezoneDto';
import { getPatientId } from '../services/patient/selector';
import { TemperatureModes } from '../utilities/converter';
import { getConfigNumber } from '../utilities/config';
import { AppAuthState, IStoreState } from './types';

const SHOW_LIMIT_START_PAGE = 4;

export const appSelector = (state: IStoreState) => state.app;

export const authInProgressSelector = createSelector(
  appSelector,
  ({ authState }): boolean =>
    authState === AppAuthState.IN_PROGRESS || authState === AppAuthState.REFRESH_IN_PROGRESS,
);

export const isAuthenticatedSelector = createSelector(
  appSelector,
  ({ authState }): boolean => authState === AppAuthState.AUTHENTICATED,
);

export const isAuthInitialSelector = createSelector(
  appSelector,
  ({ authState }): boolean => authState === AppAuthState.INITIAL,
);

export const isAuthInRefreshSelector = createSelector(
  appSelector,
  ({ authState }): boolean => authState === AppAuthState.REFRESH_IN_PROGRESS,
);

export const isModalOpenSelector = createSelector(
  appSelector,
  ({ isModalOpen }): boolean => isModalOpen,
);

export const temperatureModeSelector = createSelector(
  appSelector,
  (state): TemperatureModes => get(state, ['profile', 'temperatureMode']),
);

export const backendVersionSelector = createSelector(appSelector, (state): string =>
  get(state, ['backendVersion', 'buildVersion'], ''),
);

export const getPatientTimezone = createSelector(
  appSelector,
  (state): TimezoneDto =>
    get(state, ['profile', 'timezone'], {
      iana: '',
      abbreviation: '',
    }) as TimezoneDto,
);

export const getIsShowStartPageByUserId = createSelector(
  appSelector,
  getPatientId,
  (state, id): boolean =>
    get(state, ['startPage', `${id}`, 'count'], 0) <
      getConfigNumber('limitShowStartPage', SHOW_LIMIT_START_PAGE) &&
    !get(state, ['isShowStartPage'], false),
);

export const getActiveVideoCallAppointmentId = (state: IStoreState) =>
  state.app?.activeVideoCallAppointmentId;

export const getAppRunState = (state: IStoreState) => state.app?.appState;

import { PermissionsAndroid } from 'react-native';

export const requestPermissions = async () => {
  try {
    const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.BODY_SENSORS, {
      title: 'The Compass mobile Permission',
      message: 'The Compass mobile needs access to body sensors ' + 'so you can monitor values.',
      buttonNeutral: 'Ask Me Later',
      buttonNegative: 'Cancel',
      buttonPositive: 'OK',
    });
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      // eslint-disable-next-line no-console
      console.log('You can use the body sensors');
    } else {
      // eslint-disable-next-line no-console
      console.log('Body sensors permission denied');
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.warn(err);
  }
};

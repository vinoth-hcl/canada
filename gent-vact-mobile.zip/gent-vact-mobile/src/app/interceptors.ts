import { Action } from 'redux';
import { get } from 'lodash';
import { RequestAction } from 'redux-saga-requests';
import { put, select } from 'redux-saga/effects';
import { Platform } from 'react-native';

import { IApiRequest } from '../services/redux/ApiAction';
import { AUTH_ROUTES } from '../navigation/routes';
import { getFeatureFlag } from '../utilities/config';
import { OS_WEB } from '../constants/constants';
import {
  getIsRefreshSelector,
  getRefreshTokenSelector,
  getTokenSelector,
} from '../services/info/selectors';
import { REFRESH_TOKENS_ENDPOINT } from '../api/endpoints';
import { fetchRefreshTokens } from '../services/authentication/actions';
import { AppAuthState, LogLevel } from './types';
import { appAuthState, appLog, appRoute } from './actions';
import { isAuthenticatedSelector } from './selectors';

export const makeAuthRequest = (
  request: IApiRequest,
  access_token: string,
  isAuthenticated: boolean,
) => {
  const credentials = Platform.OS === OS_WEB ? {} : { credentials: 'include' };

  return {
    ...request,
    url: request.url,
    headers: {
      'Content-Type': get(request, 'headers.contentType', 'application/json'),
      ...request.headers,
      ...(isAuthenticated ? { Authorization: `Bearer ${access_token}` } : {}),
    },
    ...credentials,
  };
};

export function* onRequest(request: IApiRequest, action: Action) {
  const isAuthenticated = yield select(isAuthenticatedSelector);
  const access_token = yield select(getTokenSelector);
  const metaAccessToken = get(action, 'meta.access_token', '');
  const noAuth = get(action, 'meta.noAuth', false);
  const isAuth = isAuthenticated || !!metaAccessToken;
  const token = metaAccessToken || access_token;
  return makeAuthRequest(request, token, !noAuth && isAuth);
}

const ignore504 = getFeatureFlag('ignore504');

function skipError(status: number) {
  return status === 504 && ignore504;
}

function processError(action: any) {
  return getFeatureFlag('noErrorProcessing') || get(action, 'meta.noError', false);
}

let lastRefreshTime: any;

const MIN_REFRESH_INTERVAL = 2000;

// eslint-disable-next-line redux-complexity/redux-complexity
export function* onError(error: any, action: RequestAction): any {
  const status: number = error.status;
  const message = get(error, 'data.message');
  const detailedMessage = get(error, 'data.detailedMessage');
  const timestamp = get(error, 'data.timestamp');
  const method = get(action, 'request.method', 'GET');
  const url = error.url;
  const params = { status, message, url, timestamp, detailedMessage, method };
  const requestUrl = get(action, 'request.url');

  yield put(appLog('API error', { error, action }, LogLevel.ERROR));
  if (skipError(status)) {
    return { error };
  }

  if (status === 401) {
    if (requestUrl === REFRESH_TOKENS_ENDPOINT) {
      yield put(appAuthState(AppAuthState.INITIAL));
      yield put(appRoute(AUTH_ROUTES.WELCOME));
      return { error };
    }

    const isRefresh = yield select(getIsRefreshSelector);
    const no401Error = get(action, 'meta.no401Error', false);

    if (!isRefresh && !no401Error) {
      const now = Date.now();
      if (!lastRefreshTime || now - lastRefreshTime > MIN_REFRESH_INTERVAL) {
        const refresh_token = yield select(getRefreshTokenSelector);
        yield put(fetchRefreshTokens(refresh_token));
        lastRefreshTime = now;
      }
    }
    return { error };
  }

  if (processError(action)) {
    return { error };
  }

  if (status === 403) {
    yield put(appAuthState(AppAuthState.INITIAL));
    yield put(appRoute(AUTH_ROUTES.FORBIDDEN, params));
  } else if (status === 422) {
    // should be handled in reducer
  } else {
    yield put(appRoute(AUTH_ROUTES.SOMETHING_WENT_WRONG, params));
  }
  return { error };
}

export function* onSuccess(response: any, action: Action) {
  return response;
}

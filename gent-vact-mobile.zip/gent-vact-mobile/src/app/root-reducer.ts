import { Reducer } from 'redux';
import combineSectionReducers from 'combine-section-reducers';

import { sensors } from '../services/sensors/reducer';
import { patient } from '../services/patient/reducer';
import { externalApps } from '../services/externalApps/reducer';
import { feedback } from '../services/feedback/reducer';
import { toDoList } from '../services/todo/reducer';
import { appointments } from '../services/appointments/reducer';
import { notifications } from '../services/notifications/reducer';
import { currentTab } from '../services/navigation/reducers';
import { certificateData } from '../services/certificate/reducers';
import { options } from '../services/options/reducer';
import { survey } from '../services/survey/reducer';
import { support } from '../services/support/reducer';
import { withdraw } from '../services/withdraw/reducer';
import { info } from '../services/info/reducer';
import { app } from './reducer';

const rootReducer: Reducer = combineSectionReducers({
  app,
  info,
  sensors,
  patient,
  feedback,
  appointments,
  externalApps,
  toDoList,
  notifications,
  currentTab,
  certificateData,
  options,
  survey,
  support,
  withdraw,
});

export default rootReducer;

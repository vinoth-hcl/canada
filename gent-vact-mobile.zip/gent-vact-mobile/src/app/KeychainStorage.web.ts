import storage from 'redux-persist/lib/storage';

export interface IKeychain {
  key: string;
  value?: string;
}

const KeychainStorage = {
  async getItem({ key }: IKeychain) {
    return storage.getItem(key);
  },
  async setItem({ key, value = '' }: IKeychain) {
    return storage.setItem(key, value);
  },
  async removeItem({ key }: IKeychain) {
    return storage.removeItem(key);
  },
};

export default KeychainStorage;

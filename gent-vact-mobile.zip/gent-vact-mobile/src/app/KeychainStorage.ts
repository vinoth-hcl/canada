import {
  getGenericPassword,
  resetGenericPassword,
  setGenericPassword,
  STORAGE_TYPE,
} from 'react-native-keychain';

export interface IKeychain {
  key: string;
  value?: string;
}

const KeychainStorage = {
  async getItem({ key }: IKeychain) {
    const sharedWebCredentials = await getGenericPassword({
      service: key,
      storage: STORAGE_TYPE.AES,
    });
    if (typeof sharedWebCredentials === 'boolean') {
      return '';
    }
    const { password } = sharedWebCredentials;
    return password;
  },
  async setItem({ key, value = '' }: IKeychain) {
    await setGenericPassword('user', value, { service: key, storage: STORAGE_TYPE.AES });
  },
  async removeItem({ key }: IKeychain) {
    await resetGenericPassword({ service: key, storage: STORAGE_TYPE.AES });
  },
};

export default KeychainStorage;

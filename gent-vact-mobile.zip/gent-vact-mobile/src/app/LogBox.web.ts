import { noop } from 'lodash';

export const LogBox = {
  ignoreLogs: noop,
  ignoreAllLogs: noop,
};

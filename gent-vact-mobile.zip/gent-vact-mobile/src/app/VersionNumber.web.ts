import { version } from '../../package.json';

export default {
  appVersion: version,
  buildVersion: version,
  bundleIdentifier: 'GeneVA',
};

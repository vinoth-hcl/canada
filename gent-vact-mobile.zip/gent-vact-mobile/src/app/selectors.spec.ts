import deepFreeze from 'deep-freeze';

import { TemperatureModes } from '../utilities/converter';
import { TimezoneDto } from '../api/TimezoneDto';
import { IANA_TIMEZONE_DEFAULT } from '../constants/constants';
import { initialState } from './reducer';
import {
  authInProgressSelector,
  backendVersionSelector,
  getIsShowStartPageByUserId,
  getPatientTimezone,
  isAuthenticatedSelector,
  isAuthInitialSelector,
  isAuthInRefreshSelector,
  isModalOpenSelector,
  temperatureModeSelector,
} from './selectors';
import { AppAuthState, IAppState, IProfileConfig } from './types';

describe('App selectors tests', () => {
  describe('authInProgressSelector selector test', () => {
    it('should return "true" if authState: AppAuthState.IN_PROGRESS', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.IN_PROGRESS };
      const newState = deepFreeze(app) as IAppState;
      expect(authInProgressSelector.resultFunc(newState)).toBeTruthy();
    });

    it('should return "true" if authState: AppAuthState.REFRESH_IN_PROGRESS', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.REFRESH_IN_PROGRESS };
      const newState = deepFreeze(app) as IAppState;
      expect(authInProgressSelector.resultFunc(newState)).toBeTruthy();
    });

    it('should return "false" if authState: AppAuthState.INITIAL', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.INITIAL };
      const newState = deepFreeze(app) as IAppState;
      expect(authInProgressSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "false" if authState: AppAuthState.AUTHENTICATED', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.AUTHENTICATED };
      const newState = deepFreeze(app) as IAppState;
      expect(authInProgressSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "false" if authState: AppAuthState.ERROR', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.ERROR };
      const newState = deepFreeze(app) as IAppState;
      expect(authInProgressSelector.resultFunc(newState)).toBeFalsy();
    });
  });

  describe('isAuthenticatedSelector selector test', () => {
    it('should return "false" if authState: AppAuthState.IN_PROGRESS', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.IN_PROGRESS };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthenticatedSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "false" if authState: AppAuthState.REFRESH_IN_PROGRESS', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.REFRESH_IN_PROGRESS };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthenticatedSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "false" if authState: AppAuthState.INITIAL', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.INITIAL };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthenticatedSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "true" if authState: AppAuthState.AUTHENTICATED', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.AUTHENTICATED };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthenticatedSelector.resultFunc(newState)).toBeTruthy();
    });

    it('should return "false" if authState: AppAuthState.ERROR', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.ERROR };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthenticatedSelector.resultFunc(newState)).toBeFalsy();
    });
  });

  describe('isAuthInitialSelector selector test', () => {
    it('should return "false" if authState: AppAuthState.IN_PROGRESS', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.IN_PROGRESS };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInitialSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "false" if authState: AppAuthState.REFRESH_IN_PROGRESS', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.REFRESH_IN_PROGRESS };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInitialSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "true" if authState: AppAuthState.INITIAL', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.INITIAL };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInitialSelector.resultFunc(newState)).toBeTruthy();
    });

    it('should return "false" if authState: AppAuthState.AUTHENTICATED', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.AUTHENTICATED };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInitialSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "false" if authState: AppAuthState.ERROR', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.ERROR };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInitialSelector.resultFunc(newState)).toBeFalsy();
    });
  });

  describe('isAuthInRefreshSelector selector test', () => {
    it('should return "false" if authState: AppAuthState.IN_PROGRESS', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.IN_PROGRESS };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInRefreshSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "true" if authState: AppAuthState.REFRESH_IN_PROGRESS', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.REFRESH_IN_PROGRESS };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInRefreshSelector.resultFunc(newState)).toBeTruthy();
    });

    it('should return "false" if authState: AppAuthState.INITIAL', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.INITIAL };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInRefreshSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "false" if authState: AppAuthState.AUTHENTICATED', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.AUTHENTICATED };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInRefreshSelector.resultFunc(newState)).toBeFalsy();
    });

    it('should return "false" if authState: AppAuthState.ERROR', () => {
      const app: IAppState = { ...initialState, authState: AppAuthState.ERROR };
      const newState = deepFreeze(app) as IAppState;
      expect(isAuthInRefreshSelector.resultFunc(newState)).toBeFalsy();
    });
  });

  describe('isModalOpenSelector selector test', () => {
    it('should return "true"', () => {
      const app: IAppState = { ...initialState, isModalOpen: true };
      const newState = deepFreeze(app) as IAppState;
      expect(isModalOpenSelector.resultFunc(newState)).toBeTruthy();
    });

    it('should return "false"', () => {
      const app: IAppState = { ...initialState, isModalOpen: false };
      const newState = deepFreeze(app) as IAppState;
      expect(isModalOpenSelector.resultFunc(newState)).toBeFalsy();
    });
  });

  describe('temperatureModeSelector selector test', () => {
    it('should return default TemperatureModes.FAHRENHEIT', () => {
      const newState = deepFreeze(initialState) as IAppState;
      expect(temperatureModeSelector.resultFunc(newState)).toBe(TemperatureModes.FAHRENHEIT);
    });

    it('should return TemperatureModes.FAHRENHEIT', () => {
      const profile = { temperatureMode: TemperatureModes.FAHRENHEIT } as IProfileConfig;
      const app: IAppState = { ...initialState, profile };
      const newState = deepFreeze(app) as IAppState;
      expect(temperatureModeSelector.resultFunc(newState)).toBe(TemperatureModes.FAHRENHEIT);
    });

    it('should return TemperatureModes.PRESSURE', () => {
      const profile = { temperatureMode: TemperatureModes.PRESSURE } as IProfileConfig;
      const app: IAppState = { ...initialState, profile };
      const newState = deepFreeze(app) as IAppState;
      expect(temperatureModeSelector.resultFunc(newState)).toBe(TemperatureModes.PRESSURE);
    });

    it('should return TemperatureModes.CELSIUS', () => {
      const profile = { temperatureMode: TemperatureModes.CELSIUS } as IProfileConfig;
      const app: IAppState = { ...initialState, profile };
      const newState = deepFreeze(app) as IAppState;
      expect(temperatureModeSelector.resultFunc(newState)).toBe(TemperatureModes.CELSIUS);
    });
  });

  describe('backendVersionSelector selector test', () => {
    it('should return default ""', () => {
      const newState = deepFreeze(initialState) as IAppState;
      expect(backendVersionSelector.resultFunc(newState)).toBe('');
    });

    it('should return "string"', () => {
      const newState = deepFreeze({
        ...initialState,
        backendVersion: { buildVersion: 'string' },
      }) as IAppState;
      expect(backendVersionSelector.resultFunc(newState)).toBe('string');
    });
  });

  describe('getPatientTimezone selector test', () => {
    it('should return default Timezone', () => {
      const newState = deepFreeze(initialState) as IAppState;
      expect(getPatientTimezone.resultFunc(newState)).toEqual({
        iana: IANA_TIMEZONE_DEFAULT,
        abbreviation: '',
      });
    });

    it('should return default Timezone if state === undefined', () => {
      const profile = {} as IProfileConfig;
      const newState = deepFreeze({ ...initialState, profile }) as IAppState;
      expect(getPatientTimezone.resultFunc(newState)).toEqual({
        iana: '',
        abbreviation: '',
      });
    });

    it('should return Timezone', () => {
      const timezone = { iana: 'iana', abbreviation: 'abbreviation' } as TimezoneDto;
      const profile = {
        timezone,
      } as IProfileConfig;
      const newState = deepFreeze({ ...initialState, profile }) as IAppState;
      expect(getPatientTimezone.resultFunc(newState)).toEqual(timezone);
    });
  });

  describe('getIsShowStartPageByUserId selector test', () => {
    const id = '123';

    it('should return "isShown = true" startPage by other id', () => {
      const app: IAppState = { ...initialState, startPage: {}, isShowStartPage: false };
      const newState = deepFreeze(app) as IAppState;
      expect(getIsShowStartPageByUserId.resultFunc(newState, id)).toBeTruthy();
    });

    it('should return "isShown = true" startPage by userId if count = 1 && isShowStartPage: false', () => {
      const app: IAppState = {
        ...initialState,
        startPage: { [id]: { count: 1 } },
        isShowStartPage: false,
      };
      const newState = deepFreeze(app) as IAppState;
      expect(getIsShowStartPageByUserId.resultFunc(newState, id)).toBeTruthy();
    });

    it('should return "isShown = false" startPage by userId if count = 1 && isShowStartPage: true', () => {
      const app: IAppState = {
        ...initialState,
        startPage: { [id]: { count: 1 } },
        isShowStartPage: true,
      };
      const newState = deepFreeze(app) as IAppState;
      expect(getIsShowStartPageByUserId.resultFunc(newState, id)).toBeFalsy();
    });

    it('should return "isShown = true" startPage by other id if count = 3 && isShowStartPage: false', () => {
      const app: IAppState = {
        ...initialState,
        startPage: { [id]: { count: 3 } },
        isShowStartPage: false,
      };
      const newState = deepFreeze(app) as IAppState;
      expect(getIsShowStartPageByUserId.resultFunc(newState, id)).toBeTruthy();
    });

    it('should return "isShown = false" startPage by userId if count = 4 && isShowStartPage: false', () => {
      const app: IAppState = {
        ...initialState,
        startPage: { [id]: { count: 4 } },
        isShowStartPage: false,
      };
      const newState = deepFreeze(app) as IAppState;
      expect(getIsShowStartPageByUserId.resultFunc(newState, id)).toBeFalsy();
    });
  });
});

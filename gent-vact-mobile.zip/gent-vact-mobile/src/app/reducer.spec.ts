import deepFreeze from 'deep-freeze';

import { TemperatureModes } from '../utilities/converter';
import { app, initialState, profileInitialState } from './reducer';
import { IAppState, IProfileConfig } from './types';
import { resetUserProfile, setCountStartPage } from './actions';

describe('tests app reducer', () => {
  describe('RESET_USER_PROFILE', () => {
    it('should reset user profile', () => {
      const profile: IProfileConfig = {
        username: 'Tom',
        roles: ['patient'],
        temperatureMode: TemperatureModes.CELSIUS,
        profileMeasurementsConfiguration: {},
      } as IProfileConfig;
      const state = deepFreeze({ ...initialState, profile }) as IAppState;
      const newState = app(state, resetUserProfile());
      expect(newState.profile).toEqual(profileInitialState);
    });
  });

  describe('SET_IS_SHOW_START_PAGE', () => {
    const id = '123';
    it('should set "isShow: true" by id', () => {
      const state = deepFreeze(initialState) as IAppState;
      const newState = app(state, setCountStartPage(id));
      expect(newState.startPage[id].count).toBe(1);
      expect(newState.isShowStartPage).toBeTruthy();

      const nextState = app(newState, setCountStartPage(id));
      expect(nextState.startPage[id].count).toBe(2);
    });
  });
});

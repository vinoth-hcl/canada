import { makeNestedParams } from './utils';

describe('App utils tests', () => {
  describe('makeNestedParams test', () => {
    it('should return correct params', () => {
      const params = { id: '123' };
      const routes = ['route0', 'route1', 'route2', 'route3', 'route4'];
      const result = {
        screen: routes[0],
        params: {
          screen: routes[1],
          params: {
            screen: routes[2],
            params: {
              screen: routes[3],
              params: {
                screen: routes[4],
                params,
              },
            },
          },
        },
      };

      expect(makeNestedParams({ routes, params })).toEqual(result);
      expect(makeNestedParams({ routes, params, index: 3 })).toEqual(result.params.params.params);
    });
  });
});

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import dayjs from 'dayjs';
import centered from '../../../storybook/decorators/centered';
import { SensorType } from '../Sensor/types';
import { TemperatureModes } from '../../utilities/converter';
import { SensorList } from './SensorList';

const date1 = dayjs().subtract(1, 'hour').toString();
const date2 = dayjs().subtract(3, 'hour').toString();

storiesOf('SensorList', module)
  .addDecorator(centered)
  .add('view', () => (
    <SensorList
      temperatureMode={TemperatureModes.FAHRENHEIT}
      measurements={{
        [SensorType.HEART_RATE]: {
          value: 120,
          attentionLevel: 'CRITICAL',
          isNew: true,
          alertMessage: 'tachycardia',
          createdAt: date1,
        },
        [SensorType.TEMPERATURE]: {
          value: 102,
          attentionLevel: 'MIDDLE',
          isNew: true,
          alertMessage: 'fiber',
          createdAt: date2,
        },
      }}
      onPress={action('onPress')}
      sensorsState={{
        [SensorType.HEART_RATE]: { isActive: true, currentValue: 120, date: date1 },
        [SensorType.TEMPERATURE]: { isActive: true, currentValue: 102, date: date2 },
        sentData: [{ body: '', result: 200 }],
      }}
    />
  ));

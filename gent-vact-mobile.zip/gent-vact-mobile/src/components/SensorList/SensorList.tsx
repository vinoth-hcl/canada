import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { includes, map, get } from 'lodash';

import { Sensor } from '../Sensor/Sensor';
import { MeasurementElementDto } from '../../api/MeasurementElementDto';
import { SensorType } from '../Sensor/types';
import { ISensorsListProps } from './types';

export const SensorList: FunctionComponent<ISensorsListProps> = ({
  temperatureMode,
  onPress,
  measurements,
  sensorsState,
}) => {
  return (
    <View style={styles.container}>
      {map(measurements, (sensor: MeasurementElementDto, sensorType: SensorType) => {
        const isView = sensor.value && includes(SensorType, sensorType);
        const isActive = get(sensorsState, sensorType, 'isActive');
        if (isView) {
          return (
            <Sensor
              sensorType={sensorType}
              key={sensorType}
              onPress={onPress}
              value={sensor.value}
              measurementDate={sensor.createdAt}
              temperatureMode={temperatureMode}
              isActive={isActive}
            />
          );
        }
        return null;
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 80,
  },
});

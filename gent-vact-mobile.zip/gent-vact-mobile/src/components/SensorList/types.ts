import { SensorType } from '../Sensor/types';
import { PatientDto } from '../../api/PatientDto';
import { TemperatureModes } from '../../utilities/converter';
import { ISensorsState } from '../../services/sensors/types';

type IMeasurement = PatientDto['lastAggregatedMeasurements']['measurements'];

export interface ISensorsListProps {
  onPress: (isActive: boolean, sensorType: SensorType) => void;
  measurements: IMeasurement;
  temperatureMode: TemperatureModes;
  sensorsState: ISensorsState;
}

import dayjs from 'dayjs';
import { GOOD_AFTERNOON, GOOD_EVENING, GOOD_MORNING } from '../../constants/constants';
import { getGreeting } from './utils';

describe('test getGreeting', () => {
  const time1 = '2020-09-01T17:59:00';
  const time2 = '2020-09-01T18:00:00';
  const time3 = '2020-09-01T01:00:00';
  const time4 = '2020-09-01T05:00:00';
  const time5 = '2020-09-01T11:59:00';
  const time6 = '2020-09-01T12:00:00';
  it('test 1 ', () => {
    expect(getGreeting(dayjs(time1))).toEqual(GOOD_AFTERNOON);
  });
  it('test 2 ', () => {
    expect(getGreeting(dayjs(time2))).toEqual(GOOD_EVENING);
  });
  it('test 3 ', () => {
    expect(getGreeting(dayjs(time3))).toEqual(GOOD_EVENING);
  });
  it('test 4 ', () => {
    expect(getGreeting(dayjs(time4))).toEqual(GOOD_MORNING);
  });
  it('test 5 ', () => {
    expect(getGreeting(dayjs(time5))).toEqual(GOOD_MORNING);
  });
  it('test 6 ', () => {
    expect(getGreeting(dayjs(time6))).toEqual(GOOD_AFTERNOON);
  });
});

import React, { FunctionComponent, useCallback, useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import dayjs from 'dayjs';

import { Colors } from '../../utilities/design';
import { GREETING_CHECK_INTERVAL, MOCK_HEADER_TEXT } from '../../constants/constants';
import { useInterval } from '../../hooks/useInterval';
import { GText } from '../GText/GText';
import { FormattedString } from '../FormattedText/types';
import { ToDoDto } from '../../api/ToDoDto';
import { TextStyles } from '../GText/styles';
import { getGreeting } from './utils';

export interface IHeaderProps {
  userName: string;
  currentTestDay: string;
  tasks: ToDoDto[];
}

export const Header: FunctionComponent<IHeaderProps> = ({
  userName,
  currentTestDay,
  tasks = [],
}) => {
  const [greeting, setGreeting] = useState(getGreeting(dayjs()));

  const checkGreeting = useCallback(() => {
    const newGreeting = getGreeting(dayjs());
    if (greeting !== newGreeting) {
      setGreeting(newGreeting);
    }
  }, [greeting]);

  useInterval(checkGreeting, GREETING_CHECK_INTERVAL, []);

  const headerTestDay = useMemo(
    (): FormattedString => [
      {
        text: MOCK_HEADER_TEXT[0],
      },
      {
        text: currentTestDay,
        isBold: true,
      },
      {
        text: MOCK_HEADER_TEXT[1],
      },
    ],
    [currentTestDay],
  );

  return (
    <View style={styles.container}>
      <GText
        textStyle={TextStyles.BITTER_24_28_BOLD}
        children={`${greeting}`}
        style={styles.headerText}
        testID={'headerGreeting'}
        role={'header'}
      />
      <View style={styles.headerSubtext}>
        {!!currentTestDay && (
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
            style={styles.tasks}
            children={headerTestDay}
            testID={'currentTaskDay'}
          />
        )}
        {tasks.length > 0 && (
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
            style={styles.tasks}
            children={MOCK_HEADER_TEXT[2]}
            testID={'tasksHeader'}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flexDirection: 'column',
    backgroundColor: Colors.white,
  },
  headerText: {
    color: Colors.greyDark,
    textAlign: 'center',
    marginTop: 24,
    marginLeft: 16,
    marginRight: 16,
  },
  tasks: {
    color: Colors.middleBlack,
    textAlign: 'center',
  },
  headerSubtext: {
    marginTop: 16,
    marginBottom: 16,
    marginLeft: 23,
    marginRight: 23,
  },
});

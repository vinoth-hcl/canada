import { Dayjs } from 'dayjs';
import { GOOD_AFTERNOON, GOOD_EVENING, GOOD_MORNING } from '../../constants/constants';

export const getGreeting = (day: Dayjs) => {
  const hour = day.hour();
  if (hour >= 18 || hour < 5) {
    return GOOD_EVENING;
  }
  if (hour >= 5 && hour < 12) {
    return GOOD_MORNING;
  }
  return GOOD_AFTERNOON;
};

import React from 'react';
import { View, Text, ViewStyle, StyleSheet } from 'react-native';

import styles from './styles';

export type IStepIndicatorProps = {
  stepCount: number;
  activeStep: number;
  showLabel?: boolean;
  componentStyle?: ViewStyle;
  completeStyle?: ViewStyle;
  incompleteStyle?: ViewStyle;
};

export const StepIndicator = ({
  stepCount,
  activeStep,
  showLabel = true,
  componentStyle = {},
  completeStyle = {},
  incompleteStyle = {},
}: IStepIndicatorProps) => {
  return Number.isInteger(stepCount) && Number.isInteger(activeStep) ? (
    <View style={styles.container}>
      <View style={[styles.indicator, componentStyle]}>
        {Array.from({ length: stepCount }, (el, index) => (
          <View
            key={index}
            style={[
              styles.step,
              index < activeStep
                ? StyleSheet.flatten([styles.complete, completeStyle])
                : StyleSheet.flatten([styles.incomplete, incompleteStyle]),
            ]}
          />
        ))}
      </View>
      {showLabel && (
        <View style={styles.labelContainer}>
          <Text style={styles.label}>
            {activeStep} of {stepCount}
          </Text>
        </View>
      )}
    </View>
  ) : null;
};

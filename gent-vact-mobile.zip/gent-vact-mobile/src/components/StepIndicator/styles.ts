import { StyleSheet } from 'react-native';
import { Colors } from '../../utilities/design';
import { Font } from '../../style/font';

export default StyleSheet.create({
  container: {
    justifyContent: 'center',
    paddingTop: 10,
  },
  indicator: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'nowrap',
    height: 4,
    marginBottom: 10,
    marginLeft: -5,
    marginRight: -5,
  },
  step: {
    flexGrow: 1,
    borderRadius: 2,
    marginLeft: 5,
    marginRight: 5,
  },
  labelContainer: {
    paddingTop: 9,
    paddingBottom: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  label: {
    ...Font.Primary,
    textAlign: 'center',
    fontWeight: '600',
    lineHeight: 20,
  },
  complete: {
    backgroundColor: Colors.primary,
  },
  incomplete: {
    backgroundColor: Colors.primaryAltLightest,
  },
});

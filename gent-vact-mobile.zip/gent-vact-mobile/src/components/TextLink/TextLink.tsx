import { StyleSheet, Text, TouchableOpacity, View, ViewStyle } from 'react-native';
import React, { FunctionComponent, useCallback } from 'react';

interface ITextLinkProps {
  text: string;
  color?: string;
  onPress?: () => void;
  style?: ViewStyle;
  containerStyle?: ViewStyle | ViewStyle[];
  disabled?: boolean;
}

export const TextLink: FunctionComponent<ITextLinkProps> = ({
  color = 'white',
  text,
  onPress = () => {},
  style = {},
  containerStyle = {},
  children,
  disabled = false,
}) => {
  const ContainerView = useCallback(
    (props) => {
      if (disabled) {
        return <View {...props}>{props.children}</View>;
      }

      return (
        <TouchableOpacity
          onPress={onPress}
          delayPressIn={0}
          {...props}
          accessible={true}
          accessibilityLabel={text}
          accessibilityRole={'link'}
        >
          {props.children}
        </TouchableOpacity>
      );
    },
    [onPress, disabled, text],
  );

  return (
    <ContainerView style={[{ height: 30 }, containerStyle]}>
      {children || (
        <Text style={[styles.link, style, { color }, disabled ? styles.disabled : null]}>
          {text}
        </Text>
      )}
    </ContainerView>
  );
};

const styles = StyleSheet.create({
  link: {
    marginBottom: 30,
    fontStyle: 'normal',
    textAlign: 'center',
    fontSize: 15,
    lineHeight: 18,
    textDecorationLine: 'underline',
    color: 'white',
  },
  disabled: {
    opacity: 0.5,
  },
});

import React, { FunctionComponent } from 'react';
import { View, StyleSheet, Text } from 'react-native';

import { Colors } from '../../utilities/design';
import { mockText } from './mock';
import { IQuestionProps } from './types';
import { ButtonGrade } from './ButtonGrade';

export const Question: FunctionComponent<IQuestionProps> = ({ quiz, onEdit }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>{mockText}</Text>
      <ButtonGrade quiz={quiz} onEdit={onEdit} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  text: {
    fontSize: 17,
    lineHeight: 30,
    fontWeight: 'normal',
    color: Colors.middleBlack,
  },
});

import { FeedbackMockDto } from '../../services/feedback/mock/FeedbackMockDto';
import { Grade } from '../../scenes/Feedback/types';

export interface IQuestionProps {
  quiz: FeedbackMockDto;
  onEdit: (question: FeedbackMockDto) => void;
}

export interface IButtonGradeProps {
  quiz: FeedbackMockDto;
  onEdit: (question: FeedbackMockDto) => void;
}

export interface IQuestionStatusProps {
  typeButton: Grade;
  onPress: Function;
  disabled?: boolean;
}

export interface IRenderIconProps {
  grade: Grade;
  onPress: (grade: Grade) => void;
}

export interface IIconProps {
  grade: Grade;
}

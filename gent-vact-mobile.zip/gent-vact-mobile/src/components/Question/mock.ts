export const mockText: string = 'Will be here text question';

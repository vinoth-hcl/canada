import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Button } from '../Button/Button';
import { TEXT_EDIT_BUTTON } from '../../constants/constants';
import { ButtonKind } from '../Button/types';
import { Icon } from './Icon';
import { IQuestionStatusProps } from './types';

export const QuestionStatus: FunctionComponent<IQuestionStatusProps> = ({
  typeButton,
  onPress,
  disabled = false,
}) => {
  const handlePress = useCallback(() => {
    onPress(undefined);
  }, [onPress]);

  return (
    <View style={styles.container}>
      <View style={styles.status}>
        <Icon grade={typeButton} />
        <Text style={styles.text}>{typeButton}</Text>
      </View>
      <Button
        onPress={handlePress}
        text={TEXT_EDIT_BUTTON}
        kind={ButtonKind.TRANSPARENT_BLUE}
        disabled={disabled}
        testID={'EditButton'}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 269,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  status: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  text: {
    marginLeft: 10,
  },
});

import React, { FunctionComponent } from 'react';

import Angry from '../../../assets/images/Angry.svg';
import Sad from '../../../assets/images/Sad.svg';
import Sceptic from '../../../assets/images/Sceptic.svg';
import Happy from '../../../assets/images/Happy.svg';
import VeryHappy from '../../../assets/images/VeryHappy.svg';
import { Grade } from '../../scenes/Feedback/types';
import { IIconProps } from './types';

export const Icon: FunctionComponent<IIconProps> = ({ grade }) => {
  switch (grade) {
    case Grade.ANGRY: {
      return <Angry />;
    }
    case Grade.SAD: {
      return <Sad />;
    }
    case Grade.SCEPTIC: {
      return <Sceptic />;
    }
    case Grade.HAPPY: {
      return <Happy />;
    }
    case Grade.VERY_HAPPY: {
      return <VeryHappy />;
    }
    default: {
      return null;
    }
  }
};

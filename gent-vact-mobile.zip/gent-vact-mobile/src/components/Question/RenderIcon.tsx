import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet } from 'react-native';

import { Button } from '../Button/Button';
import { Icon } from './Icon';
import { IRenderIconProps } from './types';

export const RenderIcon: FunctionComponent<IRenderIconProps> = ({ grade, onPress }) => {
  const handlePress = useCallback(() => {
    onPress(grade);
  }, [grade, onPress]);

  return (
    <Button onPress={handlePress} style={{ container: styles.buttonContainer }}>
      <Icon grade={grade} />
    </Button>
  );
};

const styles = StyleSheet.create({
  buttonContainer: {
    minWidth: 0,
  },
});

import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet, View } from 'react-native';
import { map } from 'lodash';

import { BUTTON_VARIABLE } from '../../constants/constants';

import { Grade } from '../../scenes/Feedback/types';
import { IButtonGradeProps } from './types';
import { QuestionStatus } from './QuestionStatus';
import { RenderIcon } from './RenderIcon';

export const ButtonGrade: FunctionComponent<IButtonGradeProps> = ({ quiz, onEdit }) => {
  const handlePress = useCallback(
    (answer: Grade) => {
      onEdit({ ...quiz, answer });
    },
    [onEdit, quiz],
  );

  return quiz.answer ? (
    <QuestionStatus onPress={handlePress} typeButton={quiz.answer} />
  ) : (
    <View style={styles.container}>
      {map(BUTTON_VARIABLE, (grade: Grade) => {
        return <RenderIcon key={grade} grade={grade} onPress={handlePress} />;
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 269,
    marginTop: 10,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});

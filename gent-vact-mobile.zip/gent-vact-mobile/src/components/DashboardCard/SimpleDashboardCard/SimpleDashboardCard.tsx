import React, { FunctionComponent, useCallback } from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import { SvgProps } from 'react-native-svg';
import { Action } from 'redux';
import { IDashboardCardAction } from '../types';
import { Colors } from '../../../utilities/design';
import { TextLink } from '../../TextLink/TextLink';
import { GText } from '../../GText/GText';
import { TextStyles } from '../../GText/styles';

export interface ISimpleDashboardProps {
  Icon: React.FunctionComponent<SvgProps>;
  title?: string;
  actions: IDashboardCardAction[];
  backgroundColor?: string;
  data: any;
  isListPending: boolean;
  isPending: boolean;
  style?: StyleProp<ViewStyle>;
  onAction: (action: Action) => void;
}

export const SimpleDashboardCard: FunctionComponent<ISimpleDashboardProps> = ({
  Icon,
  title,
  actions,
  backgroundColor,
  data,
  isListPending = false,
  isPending = false,
  style,
  onAction,
}) => {
  const handlePress = useCallback(
    (onPress: IDashboardCardAction['onPress']) => () => onAction(onPress(data)),
    [data, onAction],
  );
  const isDisabled = useCallback((check) => check(data, isPending, isListPending), [
    data,
    isListPending,
    isPending,
  ]);

  return (
    <View style={[styles.container, backgroundColor ? { backgroundColor } : {}, style]}>
      <View style={styles.firstColumn}>
        <Icon />
      </View>
      <View style={styles.secondColumn}>
        {title && (
          <View style={styles.textContainer}>
            <GText
              style={styles.titleText}
              textStyle={TextStyles.SOURCE_SANS_16_20_NORMAL}
              children={title}
            />
          </View>
        )}
        <View>
          {actions.map(({ text, onPress, disable = () => false }, index) => (
            <TextLink
              key={text}
              text={text}
              disabled={isDisabled(disable)}
              onPress={handlePress(onPress)}
              containerStyle={[{ height: 'auto' }, index || title ? styles.actionMarginTop : {}]}
            >
              <GText
                style={StyleSheet.flatten([
                  styles.actionText,
                  isDisabled(disable) ? styles.disabledLink : null,
                ])}
                textStyle={TextStyles.SOURCE_SANS_16_20_BOLD}
                children={text}
              />
            </TextLink>
          ))}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    paddingLeft: 16,
    paddingTop: 16,
    paddingRight: 16,
    paddingBottom: 16,
    borderRadius: 24,
    backgroundColor: Colors.primaryAltLightestAlt,
    width: '100%',
  },
  centerVertical: {
    alignItems: 'center',
  },
  firstColumn: {
    marginRight: 16,
  },
  secondColumn: {
    alignItems: 'flex-start',
    maxWidth: '85%',
    flexDirection: 'column',
  },
  textContainer: {
    flexDirection: 'row',
  },
  actionContainer: {
    marginTop: 16,
  },
  icon: {
    marginRight: 16,
    width: 24,
    height: 24,
  },
  titleText: {
    color: Colors.greyDark,
    flexShrink: 1,
  },
  actionText: {
    textDecorationLine: 'underline',
    color: Colors.linkDefault,
    marginBottom: 0,
  },
  actionMarginTop: {
    marginTop: 16,
  },
  disabledLink: {
    opacity: 0.5,
  },
});

import React from 'react';
import { StyleSheet, View } from 'react-native';
import { storiesOf } from '@storybook/react-native';
import { withKnobs } from '@storybook/addon-knobs';
import { action } from '@storybook/addon-actions';

import centered from '../../../../storybook/decorators/centered';
import { Colors } from '../../../utilities/design';
import GreyOuraRingIcon from '../../../../assets/images/Dashboard/GreyOuraRing.svg';
import { SimpleDashboardCard } from './SimpleDashboardCard';

storiesOf('Simple dashboard card', module)
  .addDecorator(centered)
  .addDecorator(withKnobs)
  .add('small dashboard card', () => (
    <View style={styles.container}>
      <SimpleDashboardCard
        Icon={GreyOuraRingIcon}
        actions={[{ text: 'Open Oura app to start sync', onPress: action('onPress') }]}
      />
    </View>
  ))
  .add('small dashboard card with a few actions', () => (
    <View style={styles.container}>
      <SimpleDashboardCard
        Icon={GreyOuraRingIcon}
        actions={[
          { text: 'Open Oura app to start sync', onPress: action('onPress') },
          { text: 'Show me how to do it', onPress: action('onPress') },
        ]}
      />
    </View>
  ))
  .add('small dashboard card with a few actions and title', () => (
    <View style={styles.container}>
      <SimpleDashboardCard
        Icon={GreyOuraRingIcon}
        title="Do your daily sync & charge of the Oura ring."
        actions={[
          { text: 'Open Oura app to start sync', onPress: action('onPress') },
          { text: 'Show me how to do it', onPress: action('onPress') },
        ]}
      />
    </View>
  ));

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    width: '100%',
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

import { SvgProps } from 'react-native-svg';
import { Action } from 'redux';
import { ToDoDto } from '../../api/ToDoDto';

export interface IDashboardCardAction {
  Icon?: React.FunctionComponent<SvgProps>;
  text: string;
  onPress: (task: ToDoDto) => Action;
  disable?: (
    task: ToDoDto,
    isItemPending: boolean | undefined,
    isListPending: boolean | undefined,
  ) => boolean;
}

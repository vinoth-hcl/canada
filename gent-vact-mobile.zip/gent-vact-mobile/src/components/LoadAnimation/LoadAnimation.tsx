import React, { FunctionComponent, useCallback, useEffect, useRef, useState } from 'react';
import {
  View,
  StyleProp,
  StyleSheet,
  TextStyle,
  ViewStyle,
  Animated,
  Easing,
  EasingFunction,
  Text,
} from 'react-native';
import { Colors } from '../../utilities/design';
import { usePercentage } from './usePercentage';

interface ILoadAnimationProps {
  style?: {
    container?: StyleProp<ViewStyle>;
    text?: StyleProp<TextStyle>;
    circle?: StyleProp<ViewStyle>;
  };
  text?: string;
  circlesCount?: number;
  circleSize?: number | string;
  radius?: number | string;
  duration?: number;
  maxIncreaseCoeff?: number;
  timingFunc?: EasingFunction;
}

export const LoadAnimation: FunctionComponent<ILoadAnimationProps> = ({
  style,
  text = 'Loading...',
  circlesCount = 12,
  circleSize = '18%',
  maxIncreaseCoeff = 3,
  radius = '15%',
  duration = 1500,
  timingFunc = Easing.linear,
}) => {
  const [containerLayoutData, setContainerLayoutData] = useState<{ height: number }>({ height: 0 });
  const progress = useRef(new Animated.Value(0));
  const circleAngle = useRef(360 / circlesCount);
  const currentRadius = usePercentage({ value: radius, regardingFrom: containerLayoutData.height });
  const currentCircleSize = usePercentage({ value: circleSize, regardingFrom: currentRadius });

  const containerOnLayoutHandle = useCallback((e) => {
    if (e.nativeEvent.layout) {
      setContainerLayoutData({ ...e.nativeEvent.layout });
    }
  }, []);

  useEffect(() => {
    Animated.loop(
      Animated.timing(progress.current, {
        toValue: 360,
        duration,
        easing: timingFunc,
        useNativeDriver: true,
      }),
    ).start();
  }, [duration, timingFunc, progress]);

  const getCircles = useCallback(
    (item, index) => {
      const angleDeg = (index + 1) * circleAngle.current;
      const angleRad = (angleDeg * Math.PI) / 180;
      const left = currentRadius * Math.cos(angleRad) - currentCircleSize / 2;
      const top = currentRadius * Math.sin(angleRad) - currentCircleSize / 2;

      return (
        <Animated.View
          key={index}
          style={StyleSheet.flatten([
            styles.circle,
            style?.circle,
            {
              width: currentCircleSize,
              height: currentCircleSize,
              left,
              top,
              transform: [
                {
                  scale: progress.current.interpolate({
                    inputRange: [angleDeg - 1, angleDeg, 360],
                    outputRange: [1, maxIncreaseCoeff, 1],
                    extrapolate: 'clamp',
                  }),
                },
              ],
            },
          ])}
        />
      );
    },
    [currentRadius, currentCircleSize, maxIncreaseCoeff, progress, style],
  );

  return (
    <View
      style={StyleSheet.flatten([styles.container, style?.container])}
      pointerEvents="none"
      onLayout={containerOnLayoutHandle}
    >
      {currentRadius && currentCircleSize ? (
        <View style={styles.circlesContainer}>
          {new Array(circlesCount).fill(10).map(getCircles)}
        </View>
      ) : null}
      {text && (
        <Text style={StyleSheet.flatten([styles.text, { top: currentRadius * 1.5 }, style?.text])}>
          {text}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: Colors.black,
    opacity: 0.8,
  },
  text: {
    position: 'relative',
    fontSize: 16,
    color: Colors.white,
  },
  circlesContainer: {
    position: 'relative',
    width: 0,
    height: 0,
    overflow: 'visible',
  },
  circle: {
    backgroundColor: Colors.white,
    position: 'absolute',
    width: 20,
    height: 20,
    borderRadius: 50,
  },
});

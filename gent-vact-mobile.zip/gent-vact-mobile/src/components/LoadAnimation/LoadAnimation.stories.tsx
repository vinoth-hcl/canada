import React from 'react';
import { storiesOf } from '@storybook/react-native';

import { View } from 'react-native';
import { Colors } from '../../utilities/design';
import centered from '../../../storybook/decorators/centered';
import { LoadAnimation } from './LoadAnimation';

storiesOf('LoadAnimation', module)
  .addDecorator(centered)
  .add('view', () => (
    <View style={{ flex: 1, position: 'relative', backgroundColor: Colors.black }}>
      <LoadAnimation
        style={{ circle: { backgroundColor: Colors.black }, text: { color: Colors.black } }}
      />
    </View>
  ));

import { useEffect, useState } from 'react';

export interface IUsePercentageProps {
  value: number | string;
  regardingFrom: number;
}

export function usePercentage({ value, regardingFrom }: IUsePercentageProps): number {
  const [convertedValue, setConvertedValue] = useState(typeof value === 'number' ? value : 0);

  useEffect(() => {
    if (typeof value === 'string' && regardingFrom) {
      setConvertedValue((regardingFrom * parseFloat(value)) / 100);
    }
  }, [regardingFrom, value]);

  return convertedValue;
}

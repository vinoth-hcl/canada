import { Notification } from '../../api/Notification';

const mockNotification = {
  id: '1',
  notificationType: 'APPOINTMENT',
  description: 'Fill in survey from last month’s appointment',
} as Notification;
export const mockData: Notification[] = [
  mockNotification,
  {
    ...mockNotification,
    id: '2',
    notificationType: 'ALERT',
    description: 'Charge Oura ring Only 10% battery left',
  },
];

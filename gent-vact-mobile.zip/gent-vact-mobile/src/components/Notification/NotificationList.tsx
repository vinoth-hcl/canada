import React, { FunctionComponent, ReactElement } from 'react';
import { map } from 'lodash';
import { StyleSheet, View } from 'react-native';

import { PlaceHolderView } from '../PlaceholderView/PlaceholderView';
import { LoadAnimation } from '../LoadAnimation/LoadAnimation';
import { NotificationItem } from './NotificationItem';
import { INotificationListProps, TNotification } from './types';

export const NotificationList: FunctionComponent<INotificationListProps> = ({
  data,
  handleSurvey,
  isPending = false,
}) => {
  let dataView: ReactElement | ReactElement[] = (
    <PlaceHolderView style={{ container: styles.placeholder }} />
  );

  if (data.length) {
    dataView = map(data, ({ description, notificationType, id }, index) => {
      const onPress = notificationType === TNotification.APPOINTMENT ? handleSurvey : undefined;
      return <NotificationItem comment={description} onPress={onPress} key={`${id}_${index}`} />;
    });
  }

  return (
    <>
      {isPending && !data.length ? (
        <View style={styles.loadView}>
          <LoadAnimation />
        </View>
      ) : (
        dataView
      )}
    </>
  );
};

const styles = StyleSheet.create({
  loadView: {
    width: '100%',
    height: 500,
    position: 'relative',
  },
  placeholder: {
    height: 500,
  },
});

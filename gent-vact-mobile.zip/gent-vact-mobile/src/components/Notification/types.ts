import { NotificationPageDto } from '../../api/NotificationPageDto';

export enum TNotification {
  ALERT = 'ALERT',
  APPOINTMENT = 'APPOINTMENT',
  REMINDER = 'REMINDER',
}

export interface INotificationListProps {
  data: NotificationPageDto['content'];
  isPending: boolean;
  handleSurvey: () => void;
}

export interface INotificationItemProps {
  icon?: JSX.Element;
  header?: string;
  comment?: string;
  onPress?: () => void;
}

import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import Pen from '../../../assets/images/Pen/white.svg';
import { Button } from '../Button/Button';
import { Colors } from '../../utilities/design';
import { ButtonKind } from '../Button/types';
import { TEXT_SURVEY_BUTTON } from '../../constants/constants';
import { INotificationItemProps } from './types';

export const NotificationItem: FunctionComponent<INotificationItemProps> = ({
  icon = null,
  header = '',
  comment,
  onPress,
}) => {
  return (
    <View style={styles.container}>
      {icon && <View style={styles.icon} children={icon} />}
      <View style={styles.message}>
        {!!header && (
          <Text style={[styles.text, styles.header]} children={header} numberOfLines={1} />
        )}
        {!!comment && (
          <Text style={[styles.text, styles.comment]} children={comment} numberOfLines={2} />
        )}
        {!!onPress && (
          <Button
            Icon={Pen}
            onPress={onPress}
            text={TEXT_SURVEY_BUTTON}
            kind={ButtonKind.BLUE}
            style={{ container: styles.button, textStyle: styles.buttonText }}
            testID={'SurveyButton'}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    minHeight: 84,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: Colors.greyLighter,
  },
  icon: {
    marginLeft: 20,
  },
  message: {
    marginLeft: 25,
    marginRight: 25,
    alignItems: 'flex-start',
  },
  text: {
    fontStyle: 'normal',
    fontSize: 16,
    lineHeight: 20,
  },
  header: {
    fontWeight: 'bold',
    marginTop: 10,
  },
  comment: {
    fontWeight: 'normal',
    marginTop: 10,
    marginBottom: 10,
  },
  button: {
    flexDirection: 'row',
    marginBottom: 10,
    width: 185,
  },
  buttonText: {
    marginLeft: 10,
    marginRight: 10,
  },
});

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import centered from '../../../storybook/decorators/centered';
import BatteryLow from '../../../assets/images/BatteryLow.svg';
import Survey from '../../../assets/images/Survey.svg';
import { NotificationList } from './NotificationList';
import { NotificationItem } from './NotificationItem';
import { mockData } from './mock';

storiesOf('Notification', module)
  .addDecorator(centered)
  .add('List', () => <NotificationList data={mockData} handleSurvey={action('onPress')} />)
  .add('Item', () => (
    <NotificationItem
      header={mockData[0].description}
      comment={mockData[0].description}
      icon={<BatteryLow />}
      onPress={action('onPress')}
    />
  ))
  .add('ItemHeader', () => (
    <NotificationItem header={mockData[0].description} comment={mockData[0].description} />
  ))
  .add('ItemComment', () => <NotificationItem comment={mockData[0].description} />)
  .add('ItemIcon', () => <NotificationItem icon={<Survey />} comment={mockData[0].description} />)
  .add('ItemButton', () => (
    <NotificationItem onPress={action('onPress')} comment={mockData[0].description} />
  ));

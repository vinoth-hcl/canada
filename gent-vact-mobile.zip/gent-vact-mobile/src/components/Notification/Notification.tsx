import React, { FunctionComponent, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { appRoute } from '../../app/actions';
import { MODAL_ROUTES } from '../../navigation/routes';
import { areNotificationsPending, getNotifications } from '../../services/notifications/selectors';
import { NotificationList } from './NotificationList';

export const Notification: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();
  const notifications = useSelector(getNotifications);
  const isPending = useSelector(areNotificationsPending);
  const handleSurvey = useCallback(() => {
    dispatch(appRoute(MODAL_ROUTES.FEEDBACK));
  }, [dispatch]);

  return (
    <NotificationList data={notifications} handleSurvey={handleSurvey} isPending={isPending} />
  );
};

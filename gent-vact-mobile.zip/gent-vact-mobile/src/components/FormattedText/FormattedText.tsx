import React, { FunctionComponent } from 'react';
import { Text, TextStyle, ViewStyle } from 'react-native';
import { Colors } from '../../utilities/design';
import { testId } from '../../utilities/TestId';
import { FormattedString } from './types';

interface IFormattedTextProps {
  value: FormattedString;
  style?: ViewStyle | TextStyle;
  testID?: string;
}

export const FormattedText: FunctionComponent<IFormattedTextProps> = ({
  value,
  style,
  testID = '',
}) => {
  const accessibleString = value.reduce((acc, item) => (acc += item.text), '');

  return (
    <Text
      style={[{ textAlign: 'center' }, style]}
      {...testId(`formatted_text_${testID}`, accessibleString)}
    >
      {value.map((item, index) => {
        return (
          <Text
            style={{
              color: item.color || Colors.greyDark,
              fontWeight: item.isBold ? 'bold' : 'normal',
              fontStyle: 'normal',
              fontSize: item.size || 16,
              lineHeight: item.lineHeight || 24,
              fontFamily: item.fontFamily || 'SourceSansPro-Regular',
            }}
            key={index}
          >
            {`${item.text}${item.isBr ? '\n' : ''}`}
          </Text>
        );
      })}
    </Text>
  );
};

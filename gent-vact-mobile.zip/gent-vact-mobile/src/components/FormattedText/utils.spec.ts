import { parseFormattedString } from './utils';

describe('GText utils tests', () => {
  describe('parseFormattedString', () => {
    it('should return correct array', () => {
      const str = 'Store <b>Buy</b> string';
      expect(parseFormattedString(str)).toEqual([
        { text: 'Store ' },
        { text: 'Buy', isBold: true },
        { text: ' string' },
      ]);
    });

    it('should return only isBold', () => {
      const str = '<b>Buy</b>';
      expect(parseFormattedString(str)).toEqual([{ text: 'Buy', isBold: true }]);
    });

    it('should return no isBold', () => {
      const str = 'Buy';
      expect(parseFormattedString(str)).toEqual([{ text: 'Buy' }]);
    });

    it('should return when first isBold', () => {
      const str = '<b>Buy</b> string';
      expect(parseFormattedString(str)).toEqual([
        { text: 'Buy', isBold: true },
        { text: ' string' },
      ]);
    });

    it('should return when last isBold', () => {
      const str = 'string <b>Buy</b>';
      expect(parseFormattedString(str)).toEqual([
        { text: 'string ' },
        { text: 'Buy', isBold: true },
      ]);
    });

    it('should return when few isBold', () => {
      const str = 'string string <b>Buy</b> <b>Buy</b>';
      expect(parseFormattedString(str)).toEqual([
        { text: 'string string ' },
        { text: 'Buy', isBold: true },
        { text: ' ' },
        { text: 'Buy', isBold: true },
      ]);
    });

    it('should return when isBr', () => {
      const str =
        'Virtual Visit appointment (Video call)<br>with Dr Lisa Cuddy<br><b>Today,9:00-10:00</b>';
      expect(parseFormattedString(str)).toEqual([
        { text: 'Virtual Visit appointment (Video call)', isBr: true },
        { text: 'with Dr Lisa Cuddy', isBr: true },
        { text: 'Today,9:00-10:00', isBold: true },
      ]);
    });
  });
});

export type FormattedString = ElementFormattedString[];

export interface ElementFormattedString {
  text: string;
  color?: string;
  isBold?: boolean;
  size?: number;
  lineHeight?: number;
  fontFamily?: string;
  isBr?: boolean;
}

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import centered from '../../../storybook/decorators/centered';
import { Colors } from '../../utilities/design';
import { FormattedText } from './FormattedText';
import { FormattedString } from './types';

const value: FormattedString = [
  { text: 'Select ', size: 16, lineHeight: 24 },
  { text: 'one or more options', size: 16, lineHeight: 24, isBold: true },
  { text: ' for your second reminder', size: 16, lineHeight: 24, color: Colors.red },
];

storiesOf('FormattedText', module)
  .addDecorator(centered)
  .add('view', () => <FormattedText value={value} />);

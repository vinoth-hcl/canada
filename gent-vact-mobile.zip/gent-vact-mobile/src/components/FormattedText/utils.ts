import { FormattedString, ElementFormattedString } from './types';

function createEmptyElement(): ElementFormattedString {
  return { text: '' };
}

function getSubstr(str: string, startPos: number, endPos: number): string {
  return str.substr(startPos, endPos).toLowerCase();
}

enum CharType {
  Char = 'Char',
  Btag = 'Btag',
}

const tags = {
  b: '<b>',
  br: '<br>',
};

export function parseFormattedString(str: string): FormattedString {
  const result: FormattedString = [];
  let emptyElement: ElementFormattedString = createEmptyElement();

  if (!str) {
    result.push(emptyElement);
    return result;
  }

  let position = 0;
  const maxPosition = str.length;
  let state: CharType = CharType.Char;

  const addElement = () => {
    if (emptyElement.text) {
      result.push(emptyElement);
    }
    emptyElement = createEmptyElement();
  };

  while (position < maxPosition) {
    const ch = str[position];
    let next;

    switch (state) {
      case CharType.Char: {
        switch (ch) {
          case '<': {
            if (getSubstr(str, position, tags.b.length) === tags.b) {
              next = tags.b;
            } else if (getSubstr(str, position, tags.br.length) === tags.br) {
              next = tags.br;
            }
            if (next === tags.b) {
              position += tags.b.length;
              addElement();
              emptyElement.isBold = true;
              state = CharType.Btag;
              continue;
            } else if (next === tags.br) {
              position += tags.br.length;
              emptyElement.isBr = true;
              addElement();
              continue;
            }
            break;
          }
          default:
            emptyElement.text = `${emptyElement.text}${ch}`;
        }
        break;
      }

      case CharType.Btag: {
        switch (ch) {
          case '<': {
            next = getSubstr(str, position, 4);
            if (next === '</b>') {
              position += 4;
              addElement();
              state = CharType.Char;
              continue;
            }
            break;
          }
          default:
            emptyElement.text = `${emptyElement.text}${ch}`;
        }
        break;
      }
    }
    position++;
  }
  if (state === CharType.Char) {
    addElement();
  }
  return result;
}

const possibleTagsIsMessage = /(<b>|<\/b>|<br>)/gi;

export const isFormattedText = (text: string) => possibleTagsIsMessage.test(text);

export const makeUnformattedText = (text: string) => text.replace(possibleTagsIsMessage, '');

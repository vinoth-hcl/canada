import { Colors } from '../../utilities/design';
import { convertDegrees } from '../../utilities/converter';
import { TEXT_LAST_UPDATED } from '../../constants/constants';
import { SensorType, TUnit } from './types';

export function getUnit(sensorType: SensorType): TUnit {
  switch (sensorType) {
    case SensorType.HEART_RATE: {
      return TUnit.PULSE;
    }
    case SensorType.TEMPERATURE: {
      return TUnit.FAHRENHEIT;
    }
    case SensorType.PRESSURE: {
      return TUnit.PRESSURE;
    }
    default: {
      return TUnit.CELSIUS;
    }
  }
}

export function getUnitValue(
  value: number,
  sensorType: SensorType,
  tempMode: string = convertDegrees.modes.FAHRENHEIT,
): number | null | undefined {
  switch (sensorType) {
    case SensorType.TEMPERATURE: {
      return tempMode === convertDegrees.modes.FAHRENHEIT
        ? convertDegrees(value, convertDegrees.modes.FAHRENHEIT)
        : value;
    }
    case SensorType.PRESSURE: {
      return convertDegrees(value, convertDegrees.modes.PRESSURE);
    }
    default:
      return value;
  }
}

export function getColor(sensorType: SensorType): string {
  switch (sensorType) {
    case SensorType.TEMPERATURE: {
      return Colors.black;
    }
    case SensorType.HEART_RATE: {
      return Colors.activeRed;
    }
    default: {
      return Colors.black;
    }
  }
}

export function getSensorName(sensorType: SensorType): string {
  switch (sensorType) {
    case SensorType.TEMPERATURE: {
      return 'Temperature';
    }
    case SensorType.HEART_RATE: {
      return 'Heartbeat';
    }
    case SensorType.PRESSURE: {
      return 'Pressure';
    }
    default: {
      return 'undefined';
    }
  }
}

export function getRounding(value: number): number {
  return Math.round(value * 10) / 10;
}

export function getTextLastUpdated(time: string): string {
  return `${TEXT_LAST_UPDATED}: ${time}`;
}

import { TemperatureModes } from '../../utilities/converter';

export enum SensorType {
  HEART_RATE = 'HEART_RATE',
  TEMPERATURE = 'TEMPERATURE',
  PRESSURE = 'PRESSURE',
}

export enum TUnit {
  CELSIUS = 'C',
  FAHRENHEIT = 'F',
  PULSE = 'bpm',
  PRESSURE = 'psi',
}

export interface ISensorProps {
  sensorType: SensorType;
  onPress: (isActive: boolean, sensorType: SensorType) => void;
  value: number;
  measurementDate: string;
  temperatureMode: TemperatureModes;
  isActive: boolean;
}

export interface IUnitProps {
  type: TUnit;
  color: string;
}

import { Colors } from '../../utilities/design';
import { TemperatureModes } from '../../utilities/converter';
import { getColor, getRounding, getTextLastUpdated, getUnit, getUnitValue } from './utils';
import { SensorType, TUnit } from './types';

describe('Sensors utils tests', () => {
  describe('getColor test', () => {
    it('should return heartbeat color', () => {
      expect(getColor(SensorType.HEART_RATE)).toBe(Colors.activeRed);
    });

    it('should return temperature color', () => {
      expect(getColor(SensorType.TEMPERATURE)).toBe(Colors.black);
    });
  });

  describe('getUnit test', () => {
    it('should return bpm  for heartbeat', () => {
      expect(getUnit(SensorType.HEART_RATE)).toBe(TUnit.PULSE);
    });

    it('should return F for temperature', () => {
      expect(getUnit(SensorType.TEMPERATURE)).toBe(TUnit.FAHRENHEIT);
    });
  });

  describe('getUnitValue test', () => {
    it('should return initial for heartbeat', () => {
      expect(getUnitValue(90, SensorType.HEART_RATE)).toEqual(90);
    });

    it('should convert Celsius temperature to Fahrenheit', () => {
      expect(getUnitValue(36, SensorType.TEMPERATURE, TemperatureModes.FAHRENHEIT)).toBe(96.8);
    });

    it('should convert Pressure pa to psi', () => {
      expect(getUnitValue(100000, SensorType.PRESSURE)).toBe(14.5);
    });
  });

  describe('getRounding test', () => {
    it('should return number round', () => {
      expect(getRounding(10.888)).toBe(10.9);
      expect(getRounding(10.666)).toBe(10.7);
      expect(getRounding(10.555)).toBe(10.6);
      expect(getRounding(10.444)).toBe(10.4);
      expect(getRounding(10.222)).toBe(10.2);
    });
  });

  describe('getTextLastUpdated test', () => {
    it('should return string', () => {
      const mock: string = 'mockText';
      const result: string = `Last updated: ${mock}`;
      expect(getTextLastUpdated(mock)).toBe(result);
    });
  });
});

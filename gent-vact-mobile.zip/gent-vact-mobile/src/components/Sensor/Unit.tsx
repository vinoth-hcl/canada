import React, { FunctionComponent } from 'react';
import { StyleSheet, Text } from 'react-native';

import { TEXT_INDEX_ZERO } from '../../constants/constants';
import { IUnitProps, TUnit } from './types';

export const Unit: FunctionComponent<IUnitProps> = ({ type, color }) => {
  const style = StyleSheet.flatten([styles.sensorText, { color }]);
  const hasIndex = type === TUnit.FAHRENHEIT || type === TUnit.CELSIUS;

  return (
    <>
      {hasIndex && <Text style={style}>{TEXT_INDEX_ZERO}</Text>}
      <Text style={style}>{type}</Text>
    </>
  );
};

const styles = StyleSheet.create({
  sensorText: {
    fontWeight: 'normal',
    fontSize: 21,
    lineHeight: 25,
  },
});

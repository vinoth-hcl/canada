import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import dayjs from 'dayjs';
import relativeTimePlugin from 'dayjs/plugin/relativeTime';

import { Button } from '../Button/Button';
import { useRelativeTime } from '../../hooks/useRelativeTime';
import { Colors } from '../../utilities/design';
import { TEXT_UPDATE_BUTTON } from '../../constants/constants';
import {
  getColor,
  getUnit,
  getSensorName,
  getUnitValue,
  getRounding,
  getTextLastUpdated,
} from './utils';
import { Unit } from './Unit';
import { ISensorProps, SensorType } from './types';

dayjs.extend(relativeTimePlugin);

export const Sensor: FunctionComponent<ISensorProps> = ({
  onPress,
  sensorType,
  value,
  measurementDate = '',
  temperatureMode,
  isActive,
}) => {
  const handleUpdateSensor = useCallback(() => {
    onPress(!isActive, sensorType);
  }, [isActive, sensorType, onPress]);

  const convertTime = useCallback((timeToConvert) => dayjs(timeToConvert).fromNow(), []);
  const relativeTime = useRelativeTime(measurementDate, convertTime);
  const hasVisible: boolean = sensorType === SensorType.HEART_RATE;

  const unit = getUnit(sensorType);
  const unitValue = getUnitValue(value, sensorType, temperatureMode);
  const color = getColor(sensorType);
  const sensorName = getSensorName(sensorType);
  const textStyle = StyleSheet.flatten([
    styles.text,
    { color: isActive ? Colors.activeRed : Colors.blue },
  ]);
  const textLastUpdated = getTextLastUpdated(relativeTime);
  const valueStyle = StyleSheet.flatten([
    styles.sensorText,
    { marginLeft: 5, marginRight: 5, color },
  ]);

  return (
    <View style={styles.layout}>
      <View style={styles.container}>
        <View style={styles.sensorType}>
          <Text style={styles.sensorText}>{`${sensorName}:`}</Text>
          <View style={{ flexDirection: 'row' }}>
            {!!unitValue && <Text style={valueStyle}>{getRounding(unitValue)}</Text>}
            <Unit type={unit} color={color} />
          </View>
        </View>
        {hasVisible && (
          <Button
            onPress={handleUpdateSensor}
            text={TEXT_UPDATE_BUTTON}
            style={{
              textStyle,
              container: styles.button,
            }}
          />
        )}
      </View>
      <Text style={styles.date}>{textLastUpdated}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  layout: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  container: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 5,
    marginBottom: 5,
  },
  sensorType: {
    flexDirection: 'row',
    width: 210,
  },
  sensorText: {
    fontWeight: 'normal',
    fontSize: 21,
    lineHeight: 25,
    color: Colors.grey,
  },
  date: {
    fontWeight: 'normal',
    fontSize: 12,
    lineHeight: 16,
    color: Colors.grey,
  },
  text: {
    fontSize: 13,
    lineHeight: 15,
    fontWeight: 'normal',
  },
  button: {
    minHeight: 25,
    justifyContent: 'flex-end',
  },
});

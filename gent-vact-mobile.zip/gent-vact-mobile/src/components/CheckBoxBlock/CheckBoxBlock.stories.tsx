import React from 'react';
import { storiesOf } from '@storybook/react-native';
import centered from '../../../storybook/decorators/centered';
import { CheckBoxTypes } from './types';
import { CheckBoxView } from './CheckBoxView';

const mockData = [
  { text: 'item1', checked: false },
  { text: 'item2', checked: true },
];
storiesOf('CheckBoxBlock', module)
  .addDecorator(centered)
  .add('View', () => (
    <CheckBoxView
      type={CheckBoxTypes.SMALL_BLUE}
      values={mockData}
      itemStyle={{ marginTop: 10, marginBottom: 10 }}
    />
  ));

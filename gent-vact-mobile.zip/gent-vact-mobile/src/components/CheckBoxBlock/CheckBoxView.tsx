import React, { FunctionComponent } from 'react';
import { View, ViewStyle } from 'react-native';
import { CheckBoxItem } from './CheckBoxItem';
import { CheckBoxArray, ICheckItem } from './types';

interface ICheckBoxViewProps {
  values: CheckBoxArray;
  type: string;
  style?: ViewStyle;
  onCheck?: (params: ICheckItem) => void;
  itemStyle?: ViewStyle;
}

export const CheckBoxView: FunctionComponent<ICheckBoxViewProps> = ({
  values,
  type,
  style = {},
  itemStyle = {},
  onCheck = () => {},
}) => {
  return (
    <View style={style}>
      {values.map((item, index) => {
        return (
          <CheckBoxItem
            type={type}
            text={item.text}
            index={index}
            onCheck={onCheck}
            initialCheck={item.checked}
            style={itemStyle}
            key={`${item.text}_${index}`}
          />
        );
      })}
    </View>
  );
};

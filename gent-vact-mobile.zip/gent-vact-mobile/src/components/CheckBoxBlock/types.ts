export enum CheckBoxTypes {
  SMALL_BLUE = 'smallBlue',
  SMALL_BLACK = 'smallBlack',
  SMALL_WHITE = 'smallWhite',
  SMALL_GOLD = 'smallGold',
  MEDIUM_GOLD = 'mediumGold',
}

export type CheckBoxArray = {
  text: string;
  checked: boolean;
}[];

export interface ICheckItem {
  index: number | string;
  state: boolean;
}

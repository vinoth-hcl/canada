import { Pressable, StyleSheet, TextStyle, View, ViewStyle } from 'react-native';
import React, { FunctionComponent, useCallback, useState } from 'react';

import { Colors } from '../../utilities/design';
import { testId } from '../../utilities/TestId';
import { FormattedString } from '../FormattedText/types';
import { GText } from '../GText/GText';
import CheckIcon from '../../../assets/images/CheckIcon.svg';
import { TextStyles } from '../GText/styles';
import { CheckBoxTypes, ICheckItem } from './types';

interface CheckBoxParams {
  boxStyle: ViewStyle;
  checkedBoxStyle?: ViewStyle;
  iconStyle: {
    size: number;
    color: string;
  };
  textStyle: TextStyle;
}

export const CheckBoxType: { [key: string]: CheckBoxParams } = {
  smallBlue: {
    boxStyle: {
      backgroundColor: Colors.primary,
      width: 22,
      height: 22,
      borderRadius: 3,
      alignItems: 'center',
      justifyContent: 'center',
    },
    iconStyle: {
      size: 16,
      color: Colors.white,
    },
    textStyle: {
      color: Colors.greyDark,
      fontStyle: 'normal',
      fontWeight: 'normal',
      fontSize: 16,
      lineHeight: 24,
      marginLeft: 10,
    },
  },
  smallBlack: {
    boxStyle: {
      backgroundColor: Colors.white,
      width: 22,
      height: 22,
      borderRadius: 3,
      borderColor: Colors.almostWhite,
      borderTopWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderBottomWidth: 1,
      alignItems: 'center',
      justifyContent: 'center',
    },
    checkedBoxStyle: {
      backgroundColor: Colors.greyDark,
    },
    iconStyle: {
      size: 16,
      color: Colors.white,
    },
    textStyle: {
      color: Colors.greyDark,
      fontStyle: 'normal',
      fontWeight: 'normal',
      fontSize: 16,
      lineHeight: 24,
      marginLeft: 10,
    },
  },
  smallWhite: {
    boxStyle: {
      backgroundColor: Colors.white,
      width: 22,
      height: 22,
      borderRadius: 3,
      borderColor: Colors.almostWhite,
      borderTopWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderBottomWidth: 1,
      alignItems: 'center',
      justifyContent: 'center',
    },
    checkedBoxStyle: {
      backgroundColor: Colors.black,
    },
    iconStyle: {
      size: 16,
      color: Colors.white,
    },
    textStyle: {
      color: Colors.greyDark,
      fontStyle: 'normal',
      fontWeight: 'normal',
      fontSize: 16,
      lineHeight: 24,
      marginLeft: 10,
    },
  },
  smallGold: {
    boxStyle: {
      backgroundColor: Colors.white,
      width: 22,
      height: 22,
      borderRadius: 3,
      borderColor: Colors.greyMedium,
      borderTopWidth: 1.01,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderBottomWidth: 1,
      alignItems: 'center',
      justifyContent: 'center',
    },
    checkedBoxStyle: {
      backgroundColor: Colors.gold,
      borderTopWidth: 0,
      borderLeftWidth: 0,
      borderRightWidth: 0,
      borderBottomWidth: 0,
    },
    iconStyle: {
      size: 16,
      color: Colors.greyDark,
    },
    textStyle: {
      color: Colors.greyDark,
      fontStyle: 'normal',
      fontWeight: 'normal',
      fontSize: 16,
      lineHeight: 24,
      marginLeft: 10,
    },
  },
  mediumGold: {
    boxStyle: {
      backgroundColor: Colors.white,
      width: 32,
      height: 32,
      borderRadius: 3,
      borderColor: Colors.greyMedium,
      borderTopWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderBottomWidth: 1,
      alignItems: 'center',
      justifyContent: 'center',
    },
    checkedBoxStyle: {
      backgroundColor: Colors.gold,
      borderWidth: 0,
    },
    iconStyle: {
      size: 32,
      color: Colors.greyDark,
    },
    textStyle: {
      color: Colors.greyDark,
      fontStyle: 'normal',
      fontWeight: '400',
      fontSize: 16,
      lineHeight: 24,
      marginLeft: 10,
    },
  },
};

interface ICheckBoxItemProps {
  text: string | FormattedString;
  type: CheckBoxTypes;
  initialCheck?: boolean;
  onCheck?: (params: ICheckItem) => void;
  index: number | string;
  style?: ViewStyle;
  allViewTouchable?: boolean;
  readonly?: boolean;
}

export const CheckBoxItem: FunctionComponent<ICheckBoxItemProps> = ({
  text,
  onCheck = () => {},
  initialCheck = false,
  type,
  index,
  style = {},
  allViewTouchable = false,
  readonly = false,
}) => {
  const { iconStyle, checkedBoxStyle = {}, textStyle, boxStyle } = CheckBoxType[type];
  const [isChecked, setChecked] = useState(initialCheck);
  const onPress = useCallback(() => {
    if (readonly) {
      return;
    }
    onCheck({ index, state: !isChecked });
    setChecked(!isChecked);
  }, [isChecked, index, onCheck, readonly]);
  const iconBoxStyle = [boxStyle, isChecked && checkedBoxStyle];

  return allViewTouchable ? (
    <Pressable
      style={StyleSheet.flatten([styles.container, style])}
      onPress={onPress}
      {...testId(`check_box_pressable${index}_${text}`, text.toString(), 'checkbox')}
      accessibilityState={{ checked: isChecked }}
    >
      <View style={iconBoxStyle} importantForAccessibility={'no-hide-descendants'}>
        {isChecked && (
          <CheckIcon color={iconStyle.color} {...testId(`check_box_${index}_${text}`)} />
        )}
      </View>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        style={textStyle}
        testID={`check_box_text${index}_${text}`}
        children={text}
      />
    </Pressable>
  ) : (
    <View style={StyleSheet.flatten([styles.container, style])}>
      <Pressable
        style={iconBoxStyle}
        onPress={onPress}
        importantForAccessibility={'no-hide-descendants'}
      >
        {isChecked && (
          <CheckIcon color={iconStyle.color} {...testId(`check_box_${index}_${text}`)} />
        )}
      </Pressable>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        style={textStyle}
        testID={`check_box_text${index}_${text}`}
        children={text}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
  },
});

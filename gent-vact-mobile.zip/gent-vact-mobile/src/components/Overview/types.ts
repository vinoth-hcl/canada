export enum Progress {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  DONE = 'DONE',
}

export interface IOverviewSteps {
  id: string;
  progress: Progress;
  currentStage: number;
  comment: string;
  instruction: string;
}

export interface IMockData {
  id: string;
  title: string;
  steps: IOverviewSteps[];
}

export interface IOverviewViewProps {
  data: IMockData;
  userName: string;
}

export interface ITrialViewProps {
  data: IMockData;
}

export interface IStepProps {
  step: IOverviewSteps;
  stepsValue: number;
}

export interface IProgressIndicatorProps {
  steps: IOverviewSteps[];
}

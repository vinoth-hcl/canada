export function getSummaryText(value: number) {
  return `of ${value}`;
}

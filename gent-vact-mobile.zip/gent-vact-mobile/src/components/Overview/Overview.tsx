import React, { FunctionComponent } from 'react';
import { useSelector } from 'react-redux';

import { getProfile } from '../../services/patient/selector';
import { mockData } from './mock';
import { OverviewView } from './OverviewView';

export const Overview: FunctionComponent<{}> = () => {
  const { username, id } = useSelector(getProfile);

  return <OverviewView data={mockData} userName={username || id || ''} />;
};

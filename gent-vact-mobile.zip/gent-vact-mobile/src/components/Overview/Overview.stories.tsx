import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { View } from 'react-native';

import centered from '../../../storybook/decorators/centered';
import { OverviewView } from './OverviewView';
import { mockData } from './mock';
import { ProgressIndicator } from './ProgressIndicator';
import { TrialView } from './TrialView';
import { Step } from './Step';

storiesOf('Overview', module)
  .addDecorator(centered)
  .add('View', () => <OverviewView data={mockData} />)
  .add('TrialView', () => <TrialView data={mockData} />)
  .add('Step', () => <Step step={mockData.steps[1]} stepsValue={mockData.steps.length} />)
  .add('ProgressIndicator', () => (
    <View style={{ width: '100%' }}>
      <ProgressIndicator steps={mockData.steps} />
    </View>
  ));

import React, { FunctionComponent, useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { find } from 'lodash';

import { ProgressIndicator } from './ProgressIndicator';
import { Step } from './Step';
import { IOverviewSteps, ITrialViewProps, Progress } from './types';

export const TrialView: FunctionComponent<ITrialViewProps> = ({ data: { steps, title } }) => {
  const step = useMemo(
    (): IOverviewSteps | undefined =>
      find(steps, (item: IOverviewSteps) => item.progress === Progress.IN_PROGRESS),
    [steps],
  );

  return (
    <>
      <Text style={styles.headerText}>{title}</Text>
      <View style={styles.trialItem}>
        <ProgressIndicator steps={steps} />
        {step && <Step step={step} stepsValue={steps.length} />}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  headerText: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 17,
    lineHeight: 39,
    marginRight: 25,
  },
  trialItem: {
    flex: 1,
    marginTop: 10,
    marginBottom: 10,
  },
});

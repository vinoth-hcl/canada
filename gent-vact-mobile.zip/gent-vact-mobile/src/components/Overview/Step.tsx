import React, { FunctionComponent, useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Colors } from '../../utilities/design';
import { IStepProps } from './types';
import { getSummaryText } from './utils';

export const Step: FunctionComponent<IStepProps> = ({ step, stepsValue }) => {
  const summary = useMemo((): string => getSummaryText(stepsValue), [stepsValue]);
  return (
    <>
      <View style={styles.stepContainer}>
        <View style={styles.step}>
          <View style={styles.activeStep}>
            <Text style={styles.textActiveStep}>{step.currentStage}</Text>
          </View>
          <Text style={StyleSheet.flatten([styles.valueText, styles.stepSum])}>{summary}</Text>
        </View>
        <Text style={styles.headerText}>{step.comment}</Text>
      </View>
      <Text style={styles.valueText}>{step.instruction}</Text>
    </>
  );
};

const styles = StyleSheet.create({
  headerText: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 17,
    lineHeight: 39,
    marginRight: 25,
  },
  valueText: {
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 24,
  },
  stepContainer: {
    marginTop: 20,
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  step: {
    marginRight: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepSum: {
    marginLeft: 5,
    marginRight: 5,
  },
  activeStep: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.primary,
    borderRadius: 20,
  },
  textActiveStep: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 20,
    lineHeight: 26,
    color: Colors.white,
  },
});

import { IMockData, Progress } from './types';

export const mockData: IMockData = {
  id: '# 123 456 789',
  title: 'Trial name',
  steps: [
    {
      id: '1',
      progress: Progress.DONE,
      currentStage: 1,
      comment: 'No comment',
      instruction: 'No instruction',
    },
    {
      id: '2',
      progress: Progress.IN_PROGRESS,
      currentStage: 2,
      comment: 'Observe',
      instruction:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    },
    {
      id: '3',
      progress: Progress.OPEN,
      currentStage: 3,
      comment: 'No comment',
      instruction: 'No instruction',
    },
    {
      id: '4',
      progress: Progress.OPEN,
      currentStage: 4,
      comment: 'No comment',
      instruction: 'No instruction',
    },
    {
      id: '5',
      progress: Progress.OPEN,
      currentStage: 5,
      comment: 'No comment',
      instruction: 'No instruction',
    },
    {
      id: '6',
      progress: Progress.OPEN,
      currentStage: 6,
      comment: 'No comment',
      instruction: 'No instruction',
    },
  ],
};

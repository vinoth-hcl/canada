export default function ({ children }: any) {
  return children;
}

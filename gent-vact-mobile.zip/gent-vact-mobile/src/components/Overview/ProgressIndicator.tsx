import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { map } from 'lodash';
// import { ProgressBar } from '@react-native-community/progress-bar-android';
import { Colors } from '../../utilities/design';
import ProgressBar from './ProgressBar';

import { IOverviewSteps, IProgressIndicatorProps, Progress } from './types';

export const ProgressIndicator: FunctionComponent<IProgressIndicatorProps> = ({ steps }) => {
  return (
    <View style={styles.container}>
      {map(steps, (step: IOverviewSteps, index: number) => {
        const progress = step.progress === Progress.OPEN ? 0 : 1;
        return (
          <ProgressBar
            styleAttr={'Horizontal'}
            indeterminate={false}
            progress={progress}
            style={styles.item}
            color={Colors.primary}
            key={index}
          />
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'nowrap',
  },
  item: {
    marginTop: 5,
    marginBottom: 5,
    transform: [{ scaleY: 1.5 }],
  },
});

import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Colors } from '../../utilities/design';
import { PATIENT_ID } from '../../constants/constants';
import { TrialView } from './TrialView';
import { IOverviewViewProps } from './types';

export const OverviewView: FunctionComponent<IOverviewViewProps> = ({ data, userName }) => {
  return (
    <View style={styles.container}>
      <View style={styles.infoContainer}>
        <Text style={styles.headerText}>{PATIENT_ID}</Text>
        <Text style={styles.valueText}>{userName}</Text>
      </View>
      <TrialView data={data} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 288,
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    marginLeft: 15,
    marginRight: 15,
    marginTop: 10,
    marginBottom: 10,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerText: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 17,
    lineHeight: 39,
    marginRight: 25,
  },
  valueText: {
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 24,
  },
  trialItem: {
    flex: 1,
    marginTop: 10,
    marginBottom: 10,
  },
  textActiveStep: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 20,
    lineHeight: 26,
    color: Colors.white,
  },
});

import { Platform, StyleSheet } from 'react-native';

export enum TextStyles {
  SOURCE_SANS_14_16_NORMAL = 'SOURCE_SANS_14_16_NORMAL',
  SOURCE_SANS_14_16_BOLD = 'SOURCE_SANS_14_16_BOLD',

  SOURCE_SANS_16_20_NORMAL = 'SOURCE_SANS_16_20_NORMAL',
  SOURCE_SANS_16_20_SEMIBOLD = 'SOURCE_SANS_16_20_SEMIBOLD',
  SOURCE_SANS_16_20_BOLD = 'SOURCE_SANS_16_20_BOLD',

  SOURCE_SANS_16_24_NORMAL = 'SOURCE_SANS_16_24_NORMAL',
  SOURCE_SANS_16_24_SEMIBOLD = 'SOURCE_SANS_16_24_SEMIBOLD',
  SOURCE_SANS_16_24_BOLD = 'SOURCE_SANS_16_24_BOLD',

  SOURCE_SANS_18_20_SEMIBOLD = 'SOURCE_SANS_18_20_SEMIBOLD',

  SOURCE_SANS_20_24_NORMAL = 'SOURCE_SANS_20_24_NORMAL',
  SOURCE_SANS_20_24_SEMIBOLD = 'SOURCE_SANS_20_24_SEMIBOLD',
  SOURCE_SANS_20_24_BOLD = 'SOURCE_SANS_20_24_BOLD',

  SOURCE_SANS_20_28_SEMIBOLD = 'SOURCE_SANS_20_28_SEMIBOLD',

  BITTER_16_19_NORMAL = 'BITTER_16_19_NORMAL',
  BITTER_16_19_BOLD = 'BITTER_16_19_BOLD',

  BITTER_16_22_BOLD = 'BITTER_16_22_BOLD',

  BITTER_16_24_BOLD = 'BITTER_16_24_BOLD',

  BITTER_20_24_NORMAL = 'BITTER_20_24_NORMAL',

  BITTER_20_28_NORMAL = 'BITTER_20_28_NORMAL',
  BITTER_20_28_BOLD = 'BITTER_20_28_BOLD',

  BITTER_24_28_BOLD = 'BITTER_24_28_BOLD',

  BITTER_24_30_BOLD = 'BITTER_24_30_BOLD',
}

let weight: { regular: '400' | 'normal'; semibold: '600' | 'normal'; bold: '700' | 'normal' } = {
  regular: '400',
  semibold: '600',
  bold: '700',
};

if (Platform.OS === 'android') {
  weight = {
    regular: 'normal',
    semibold: 'normal',
    bold: 'normal',
  };
}

export const stylesSourseSansFont = StyleSheet.create({
  SOURCE_SANS_14_16_NORMAL: {
    fontFamily: 'SourceSansPro-Regular',
    fontStyle: 'normal',
    fontWeight: weight.regular,
    fontSize: 14,
    lineHeight: 16,
  },
  SOURCE_SANS_14_16_BOLD: {
    fontFamily: 'SourceSansPro-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 14,
    lineHeight: 16,
  },

  SOURCE_SANS_16_20_NORMAL: {
    fontFamily: 'SourceSansPro-Regular',
    fontStyle: 'normal',
    fontWeight: weight.regular,
    fontSize: 16,
    lineHeight: 20,
  },
  SOURCE_SANS_16_20_SEMIBOLD: {
    fontFamily: 'SourceSansPro-SemiBold',
    fontStyle: 'normal',
    fontWeight: weight.semibold,
    fontSize: 16,
    lineHeight: 20,
  },
  SOURCE_SANS_16_20_BOLD: {
    fontFamily: 'SourceSansPro-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 16,
    lineHeight: 20,
  },

  SOURCE_SANS_16_24_NORMAL: {
    fontFamily: 'SourceSansPro-Regular',
    fontStyle: 'normal',
    fontWeight: weight.regular,
    fontSize: 16,
    lineHeight: 24,
  },
  SOURCE_SANS_16_24_SEMIBOLD: {
    fontFamily: 'SourceSansPro-SemiBold',
    fontStyle: 'normal',
    fontWeight: weight.semibold,
    fontSize: 16,
    lineHeight: 24,
  },
  SOURCE_SANS_16_24_BOLD: {
    fontFamily: 'SourceSansPro-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 16,
    lineHeight: 24,
  },

  SOURCE_SANS_18_20_SEMIBOLD: {
    fontFamily: 'SourceSansPro-SemiBold',
    fontStyle: 'normal',
    fontWeight: weight.semibold,
    fontSize: 18,
    lineHeight: 20,
  },

  SOURCE_SANS_20_24_NORMAL: {
    fontFamily: 'SourceSansPro-Regular',
    fontStyle: 'normal',
    fontWeight: weight.regular,
    fontSize: 20,
    lineHeight: 24,
  },
  SOURCE_SANS_20_24_SEMIBOLD: {
    fontFamily: 'SourceSansPro-SemiBold',
    fontStyle: 'normal',
    fontWeight: weight.semibold,
    fontSize: 20,
    lineHeight: 24,
  },
  SOURCE_SANS_20_24_BOLD: {
    fontFamily: 'SourceSansPro-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 20,
    lineHeight: 24,
  },

  SOURCE_SANS_20_28_SEMIBOLD: {
    fontFamily: 'SourceSansPro-SemiBold',
    fontStyle: 'normal',
    fontWeight: weight.semibold,
    fontSize: 20,
    lineHeight: 28,
  },
});

export const stylesBitterFont = StyleSheet.create({
  BITTER_16_19_NORMAL: {
    fontFamily: 'Bitter-Regular',
    fontStyle: 'normal',
    fontWeight: weight.regular,
    fontSize: 16,
    lineHeight: 19,
  },
  BITTER_16_19_BOLD: {
    fontFamily: 'Bitter-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 16,
    lineHeight: 19,
  },

  BITTER_16_22_BOLD: {
    fontFamily: 'Bitter-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 16,
    lineHeight: 22,
  },

  BITTER_16_24_BOLD: {
    fontFamily: 'Bitter-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 16,
    lineHeight: 24,
  },

  BITTER_20_24_NORMAL: {
    fontFamily: 'Bitter-Regular',
    fontStyle: 'normal',
    fontWeight: weight.regular,
    fontSize: 20,
    lineHeight: 24,
  },

  BITTER_20_28_NORMAL: {
    fontFamily: 'Bitter-Regular',
    fontStyle: 'normal',
    fontWeight: weight.regular,
    fontSize: 20,
    lineHeight: 28,
  },
  BITTER_20_28_BOLD: {
    fontFamily: 'Bitter-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 20,
    lineHeight: 28,
  },

  BITTER_24_28_BOLD: {
    fontFamily: 'Bitter-Bold',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 24,
    lineHeight: 28,
  },

  BITTER_24_30_BOLD: {
    fontFamily: 'Bitter-Regular',
    fontStyle: 'normal',
    fontWeight: weight.bold,
    fontSize: 24,
    lineHeight: 30,
  },
});

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import centered from '../../../storybook/decorators/centered';
import { Colors } from '../../utilities/design';
import { GText } from './GText';
import { TextStyles } from './styles';

storiesOf('GText', module)
  .addDecorator(centered)
  .add('Bitter', () => (
    <GText textStyle={TextStyles.BITTER_16_24_BOLD} style={{ color: Colors.newBlue }}>
      QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm
    </GText>
  ))
  .add('Source Sans Pro', () => (
    <GText textStyle={TextStyles.SOURCE_SANS_16_20_BOLD} style={{ color: Colors.greyDark }}>
      QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm
    </GText>
  ));

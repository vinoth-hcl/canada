import React, { FunctionComponent } from 'react';
import { AccessibilityRole, Text, TextProps, TextStyle } from 'react-native';

import { FormattedText } from '../FormattedText/FormattedText';
import { FormattedString } from '../FormattedText/types';
import { testId } from '../../utilities/TestId';
import { Colors } from '../../utilities/design';
import { isFormattedText, parseFormattedString } from '../FormattedText/utils';
import { stylesBitterFont, stylesSourseSansFont, TextStyles } from './styles';

const getSpeechText = (children: any): string => {
  switch (typeof children) {
    case 'string':
      return children;
    case 'number':
      return children.toString();
    default:
      return '';
  }
};

interface IGTextProps extends TextProps {
  textStyle: TextStyles;
  style?: TextStyle;
  testID?: string;
  role?: AccessibilityRole;
  options?: any;
}

export const GText: FunctionComponent<IGTextProps> = ({
  children,
  style = { color: Colors.greyDark },
  textStyle = TextStyles.SOURCE_SANS_16_24_NORMAL,
  testID = '',
  role,
  numberOfLines,
  options,
}) => {
  const styles = {
    ...stylesSourseSansFont,
    ...stylesBitterFont,
  };
  const isChildrenWithTags = typeof children === 'string' && isFormattedText(children);

  if (isChildrenWithTags) {
    return (
      <FormattedText
        style={style}
        value={parseFormattedString(children as string) as FormattedString}
        testID={testID}
      />
    );
  }

  return Array.isArray(children) ? (
    <FormattedText style={style} value={children as FormattedString} testID={testID} />
  ) : (
    <Text
      numberOfLines={numberOfLines}
      style={[styles[textStyle], style]}
      children={children}
      {...testId(testID, getSpeechText(children), role)}
      {...options}
    />
  );
};

import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

import { Colors } from '../../utilities/design';
import Plus from '../../../assets/images/Plus.svg';
import { Separator } from '../Separator/Separator';
import { TextStyles } from '../GText/styles';
import { GButton } from '../GButton/GButton';
import { ButtonKind } from '../GButton/types';

interface IAppointmentHeaderProps {
  handlePressAddApt: () => void;
  textHeader: string;
}

export const AppointmentHeader: FunctionComponent<IAppointmentHeaderProps> = ({
  handlePressAddApt,
  textHeader,
}) => {
  return (
    <>
      <View style={styles.header}>
        <GButton
          onPress={handlePressAddApt}
          kind={ButtonKind.WHITE}
          text={textHeader}
          Icon={Plus}
          isShadow
          style={{
            container: styles.button,
            iconContainerStyle: styles.iconContainer,
            textStyle: styles.text,
            textFont: TextStyles.SOURCE_SANS_16_20_SEMIBOLD,
          }}
          testID={'AddAppointment'}
        />
      </View>
      <Separator />
    </>
  );
};

const styles = StyleSheet.create({
  header: {
    alignItems: 'center',
  },
  button: {
    width: 239,
    marginTop: 16,
    marginBottom: 16,
  },
  text: {
    color: Colors.greyDark,
  },
  iconContainer: {
    width: 24,
    height: 24,
    backgroundColor: Colors.gold,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

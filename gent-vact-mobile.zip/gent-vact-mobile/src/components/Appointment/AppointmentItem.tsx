import React, { FunctionComponent, ReactElement, useCallback } from 'react';
import { StyleSheet, View } from 'react-native';
import dayjs from 'dayjs';
import { get, map, reduce } from 'lodash';

import PInvestigator from '../../../assets/images/PInvestigator.svg';
import ArrowExpand from '../../../assets/images/ArrowExpand.svg';
import ArrowUpRect from '../../../assets/images/ArrowUpRect.svg';
import ArrowDownRect from '../../../assets/images/ArrowDownRect.svg';
import AppointmentCancelled from '../../../assets/images/AppointmentCancelled.svg';
import AppointmentPhone from '../../../assets/images/AppointmentPhone.svg';
import AppointmentPhoneActive from '../../../assets/images/AppointmentPhoneActive.svg';
import AppointmentVideo from '../../../assets/images/AppointmentVideo.svg';
import AppointmentVideoActive from '../../../assets/images/AppointmentVideoActive.svg';
import AppointmentInPerson from '../../../assets/images/InPerson.svg';
import AppointmentInPersonActive from '../../../assets/images/InPersonActive.svg';
import { Colors } from '../../utilities/design';
import { AppointmentDto } from '../../api/AppointmentDto';
import { AppointmentStatus, AppointmentType } from '../../services/appointments/types';
import { Button } from '../Button/Button';
import {
  TEXT_APPOINTMENT,
  TEXT_APPOINTMENT_WAS_CANCELLED,
  TEXT_CHOOSE_DAY_TIME,
  TEXT_CHOOSE_FREE_TIME_SLOT,
  TEXT_LIMITED_INDICATOR,
  TEXT_PREPARATION,
  TEXT_REAQUSTED_BY_YOU_ON,
  TEXT_RESCHEDULE_REQUESTED,
  TEXT_WAITING_FOR_DOCTOR_REPLY,
} from '../../constants/constants';
import {
  isAppointmentRequest,
  isAppointmentStatus,
} from '../../scenes/Appointments/components/utils';
import { AppointmentSlotDto } from '../../api/AppointmentSlotDto';
import { formatAppointmentDate } from '../../utilities/date';
import { testId } from '../../utilities/TestId';
import { TimezoneDto } from '../../api/TimezoneDto';
import { GText } from '../GText/GText';
import { FORMAT_TIME_24_ENABLED } from '../../utilities/config';
import Chevron from '../../../assets/images/Chevron.svg';
import { TextStyles } from '../GText/styles';
import { IExtendedAppointment } from './types';

const TIME_FORMAT = FORMAT_TIME_24_ENABLED ? 'MMMM Do, H:mm' : 'MMMM Do, h:mm A';
const SHORT_TIME_FORMAT = FORMAT_TIME_24_ENABLED ? 'H:mm' : 'h:mm A';

const getRightIcon = (isActive: boolean, isRequest: boolean, status: AppointmentStatus) => {
  if (isRequest) {
    return null;
  }
  if (status === AppointmentStatus.CANCELLED) {
    return null;
  }
  return <ArrowExpand style={StyleSheet.flatten(styles.icon)} />;
};

const getLeftIcon = (
  isActive: boolean,
  isRequest: boolean,
  status: AppointmentStatus,
  type: AppointmentType,
) => {
  if (isRequest) {
    return <ArrowUpRect style={StyleSheet.flatten(styles.icon)} />;
  }

  switch (status) {
    case AppointmentStatus.CANCELLED: {
      return <AppointmentCancelled />;
    }
    case AppointmentStatus.RESCHEDULED: {
      return <ArrowUpRect />;
    }
    case AppointmentStatus.PARTIAL_SCHEDULED: {
      return <ArrowDownRect />;
    }
    case AppointmentStatus.SCHEDULED: {
      break;
    }
  }

  switch (type) {
    case AppointmentType.PHONE:
      if (isActive) {
        return <AppointmentPhoneActive />;
      }
      return <AppointmentPhone />;
    case AppointmentType.VIDEO:
      if (isActive) {
        return <AppointmentVideoActive />;
      }
      return <AppointmentVideo />;
    case AppointmentType.IN_PERSON:
      if (isActive) {
        return <AppointmentInPersonActive />;
      }
      return <AppointmentInPerson />;
    default:
      return <PInvestigator />;
  }
};

const getHeaderText = (name = ''): string =>
  name ? `${TEXT_APPOINTMENT} with Dr. ${name}` : TEXT_APPOINTMENT;

const getApptTypeText = (type = ''): string => {
  switch (type) {
    case AppointmentType.VIDEO: {
      return 'Video call';
    }
    case AppointmentType.IN_PERSON: {
      return 'In Person';
    }
    case AppointmentType.PHONE: {
      return 'Phone call';
    }
    default: {
      return '';
    }
  }
};

interface IAppointmentItemProps {
  onPress: (appointment: AppointmentDto) => void;
  isHeader?: boolean;
  appointment: IExtendedAppointment;
  index: number;
  timeZonePreferences: TimezoneDto;
}

function getStyles(isActive: boolean) {
  return {
    header: isActive ? TextStyles.BITTER_16_22_BOLD : TextStyles.BITTER_16_19_NORMAL,
    phonendoscope: [styles.phonendoscope, isActive && styles.phonendoscopeActive],
    buttonContainer: [styles.container, isActive && styles.containerActive],
  };
}

function getBoldText(
  status: AppointmentStatus,
  checkList: any,
  isSameDay: boolean,
): { text: string | null; isLink: boolean } {
  if (status === AppointmentStatus.SCHEDULED && checkList && checkList.items.length > 0) {
    return { text: TEXT_PREPARATION, isLink: false };
  }

  switch (status) {
    case AppointmentStatus.NEW:
      return { text: TEXT_WAITING_FOR_DOCTOR_REPLY, isLink: false };
    case AppointmentStatus.PARTIAL_SCHEDULED:
      return isSameDay
        ? { text: TEXT_CHOOSE_FREE_TIME_SLOT, isLink: true }
        : { text: TEXT_CHOOSE_DAY_TIME, isLink: true };
    case AppointmentStatus.RESCHEDULED:
      return { text: TEXT_RESCHEDULE_REQUESTED, isLink: false };
    case AppointmentStatus.CANCELLED:
      return { text: TEXT_APPOINTMENT_WAS_CANCELLED, isLink: false };
    default:
      return { text: null, isLink: false };
  }
}

function renderDescription(
  status: AppointmentStatus,
  isActive: boolean,
  isSameDay: boolean,
  communicationType: AppointmentType,
  startTime: string,
  timeSlots: AppointmentSlotDto[] | undefined,
  localizeDate: (date: string | AppointmentSlotDto[], formatTemplate: string) => string,
  index: number,
): ReactElement[] | null {
  if (!startTime && !timeSlots) {
    return null;
  }
  const textStyle = isActive ? TextStyles.BITTER_16_22_BOLD : TextStyles.BITTER_16_19_NORMAL;
  const textTypeTimeStyle = TextStyles.SOURCE_SANS_16_20_NORMAL;
  const textAppointmentRequestStyle = TextStyles.SOURCE_SANS_16_20_NORMAL;

  switch (status) {
    case AppointmentStatus.CANCELLED: {
      return [
        <GText
          textStyle={textStyle}
          testID={`Start_time_CANCELLED_${index}`}
          children={localizeDate(startTime, TIME_FORMAT)}
        />,
      ];
    }
    case AppointmentStatus.RESCHEDULED: {
      return [
        <GText
          textStyle={textStyle}
          testID={`Start_time_RESCHEDULED_${index}`}
          children={localizeDate(startTime, TIME_FORMAT)}
        />,
      ];
    }
    case AppointmentStatus.PARTIAL_SCHEDULED: {
      const dates = timeSlots && timeSlots.length ? timeSlots : startTime;

      return [
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_20_BOLD}
          testID={`dates_PARTIAL_SCHEDULED_${index}`}
          children={localizeDate(dates, 'MMMM Do')}
        />,
      ];
    }
    case AppointmentStatus.NEW: {
      return [
        <GText
          textStyle={textAppointmentRequestStyle}
          testID={`Start_time_NEW_${index}`}
          children={`${TEXT_REAQUSTED_BY_YOU_ON} ${localizeDate(startTime, 'MMMM Do')}`}
        />,
      ];
    }
    case AppointmentStatus.SCHEDULED: {
      const timeView = (
        <>
          <GText
            textStyle={textTypeTimeStyle}
            testID={`Start_Time_SCHEDULED_${index}`}
            children={localizeDate(startTime, SHORT_TIME_FORMAT)}
          />
          <View style={styles.separator} />
          <GText
            textStyle={textTypeTimeStyle}
            testID={`communicationType_SCHEDULED_${index}`}
            children={getApptTypeText(communicationType)}
          />
        </>
      );
      if (isActive) {
        return [timeView];
      } else {
        return [
          <GText
            textStyle={textStyle}
            testID={`Start_Time_SCHEDULED_NonActive_${index}`}
            children={localizeDate(startTime, 'MMMM Do')}
          />,
          timeView,
        ];
      }
    }
    default:
      return null;
  }
}

function getIsToday(startTime: string, timeZonePreferences: TimezoneDto) {
  return !!startTime && dayjs().tz(timeZonePreferences.iana).isSame(startTime, 'day');
}

function getIsSameDay(appointment: AppointmentDto, isPartial: boolean) {
  if (!isPartial) {
    return false;
  }
  if (!appointment.timeSlots || !appointment.timeSlots.length) {
    return false;
  }
  const firstDate = dayjs(get(appointment.timeSlots, '[0].startTime'));
  return reduce(
    appointment.timeSlots,
    (acc, { startTime }) => acc && firstDate.isSame(startTime as string, 'day'),
    true,
  );
}

function getIsActive(isRequest: boolean, isPartial: boolean, isToday: boolean) {
  return !isPartial && !isRequest && isToday;
}

const getAccessibilityDescription = (description: ReactElement[] | null) => {
  const descriptionString = get(description, '0.props.children', '');
  return typeof descriptionString === 'string' ? descriptionString : '';
};

// eslint-disable-next-line redux-complexity/redux-complexity
export const AppointmentItem: FunctionComponent<IAppointmentItemProps> = ({
  isHeader = true,
  onPress,
  appointment,
  index,
  timeZonePreferences,
}) => {
  const {
    doctor: { name },
    startTime,
    timeSlots,
    checkList,
    isLimited,
  } = appointment;
  const localizeDate = useCallback(
    (date: string | AppointmentSlotDto[], formatTemplate: string): string => {
      return formatAppointmentDate(date, formatTemplate, timeZonePreferences);
    },
    [timeZonePreferences],
  );
  const status = appointment.status as AppointmentStatus;
  const communicationType = appointment.communicationType as AppointmentType;
  const textNewDate = `Today - ${localizeDate(startTime, 'MMMM Do')}`;
  const isRequest = isAppointmentRequest(appointment);
  const isPartial = isAppointmentStatus(appointment, AppointmentStatus.PARTIAL_SCHEDULED);
  const isToday = getIsToday(startTime, timeZonePreferences);
  const isActive = getIsActive(isRequest, isPartial, isToday);
  const isSameDay = getIsSameDay(appointment, isPartial);

  const headerText = getHeaderText(name);
  const style = getStyles(isActive);

  const handlePress = useCallback(() => {
    onPress(appointment);
  }, [onPress, appointment]);

  const { text: boldText, isLink } = getBoldText(status, checkList, isSameDay);
  const description = renderDescription(
    status,
    isActive,
    isSameDay,
    communicationType,
    startTime,
    timeSlots as AppointmentSlotDto[],
    localizeDate,
    index,
  );

  const leftIcon = getLeftIcon(isActive, isRequest, status, communicationType);
  const rightIcon = getRightIcon(isActive, isRequest, status);

  return (
    <View style={isHeader ? styles.wrapperWithHeader : styles.wrapper}>
      {isHeader && (
        <GText
          textStyle={TextStyles.BITTER_20_24_NORMAL}
          style={styles.title}
          testID={`Appt_header_${index}`}
          children={textNewDate}
        />
      )}
      <Button
        style={{ container: style.buttonContainer }}
        onPress={handlePress}
        testID={`Appointment_${index}`}
        title={`${headerText}, ${getAccessibilityDescription(description)}, ${boldText || ''}`}
      >
        <View
          style={style.phonendoscope}
          {...testId(`Left_Icon_${index}`)}
          importantForAccessibility={'no-hide-descendants'}
        >
          {leftIcon}
        </View>
        <View style={styles.description}>
          <GText
            textStyle={
              status === AppointmentStatus.NEW
                ? TextStyles.SOURCE_SANS_16_20_NORMAL
                : (style.header as TextStyles)
            }
            testID={`Text_header_${index}`}
            children={headerText}
          />
          {description &&
            map(description, (text, Index) => (
              <View style={styles.time} key={Index} children={text} />
            ))}

          <View style={styles.boldContainer}>
            {boldText && (
              <GText
                textStyle={TextStyles.SOURCE_SANS_16_20_BOLD}
                testID={`Text_status_${index}`}
                style={isLink ? styles.link : {}}
                children={boldText}
              />
            )}
            {isLink && (
              <View style={styles.boldLink} importantForAccessibility={'no-hide-descendants'}>
                <Chevron {...testId(`Text_Link_${index}`)} />
              </View>
            )}
          </View>
        </View>
        <View importantForAccessibility={'no-hide-descendants'}>{rightIcon}</View>
      </Button>
      {isLimited && (
        <View style={styles.limitedIndicator}>
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_20_BOLD}
            testID={`Text_Limited_${index}`}
            style={styles.limitedIndicatorText}
            children={TEXT_LIMITED_INDICATOR}
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    alignItems: 'flex-start',
    paddingLeft: 16,
    paddingRight: 8,
    paddingTop: 16,
    paddingBottom: 16,
  },
  wrapperWithHeader: {
    alignItems: 'flex-start',
    paddingLeft: 8,
    paddingRight: 8,
    paddingTop: 27,
    paddingBottom: 30,
  },
  boldContainer: {
    flexDirection: 'row',
    marginTop: 12,
  },
  link: {
    color: Colors.newBlue,
    textDecorationLine: 'underline',
  },
  boldLink: {
    marginLeft: 6,
    marginTop: 7,
  },
  title: {
    marginBottom: 16,
    marginLeft: 14,
  },
  container: {
    backgroundColor: Colors.white,
    minHeight: 75,
    width: '100%',
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 0,
    paddingRight: 0,
    paddingBottom: 0,
    paddingLeft: 0,
  },
  containerActive: {
    backgroundColor: Colors.goldPale,
    paddingTop: 11,
    paddingRight: 0,
    paddingBottom: 10,
    paddingLeft: 16,
  },
  separator: {
    marginRight: 6,
    marginLeft: 6,
    height: 16,
    bottom: -3,
    borderRightWidth: 1,
    borderRightColor: Colors.greyDark,
  },
  time: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  phonendoscope: {
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 24,
    backgroundColor: Colors.greyLightest,
    marginLeft: 0,
    marginRight: 20,
  },
  phonendoscopeActive: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderTopWidth: 0,
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderBottomWidth: 0,
    borderStyle: 'solid',
    borderColor: Colors.greyLight,
    marginLeft: 0,
    marginRight: 16,
  },
  icon: {
    marginLeft: 20,
    marginRight: 20,
  },
  description: {
    flex: 1,
  },
  limitedIndicator: {
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom: 5,
  },
  limitedIndicatorText: {
    alignSelf: 'center',
    fontSize: 60,
    lineHeight: 40,
    textAlign: 'center',
    textAlignVertical: 'center',
  },
});

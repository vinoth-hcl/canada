import { AppointmentDto } from '../../api/AppointmentDto';

export const mockAppointment: AppointmentDto = {
  startTime: '2020-09-25T16:30:00.777Z',
  communicationType: 'VIDEO',
  status: 'SCHEDULED',
  doctor: { name: 'Brown' },
} as AppointmentDto;

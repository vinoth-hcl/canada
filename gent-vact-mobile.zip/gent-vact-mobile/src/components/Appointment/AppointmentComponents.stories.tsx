import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import dayjs from 'dayjs';
import centered from '../../../storybook/decorators/centered';
import { AppointmentItem } from './AppointmentItem';
import { mockAppointment } from './mock';
import { AppointmentHeader } from './AppointmentHeader';

const TIMEZONE_PREFERENCES = { iana: 'UTC', abbreviation: 'UTC', raw: {} };

storiesOf('AppointmentHeader', module)
  .addDecorator(centered)
  .add('view', () => (
    <AppointmentHeader handlePressAddApt={action('handlePressAddApt')} textHeader={'header'} />
  ));

storiesOf('AppointmentItem', module)
  .addDecorator(centered)
  .add('SCHEDULED', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={mockAppointment}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('header PHONE', () => (
    <AppointmentItem
      isHeader={true}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, communicationType: 'PHONE' }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('PHONE', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, communicationType: 'PHONE' }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('PHONE active', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{
        ...mockAppointment,
        communicationType: 'PHONE',
        startTime: dayjs().toString(),
      }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('Header PHONE active', () => (
    <AppointmentItem
      isHeader={true}
      onPress={action('onPress')}
      appointment={{
        ...mockAppointment,
        communicationType: 'PHONE',
        startTime: dayjs().toString(),
      }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('VIDEO', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, communicationType: 'VIDEO' }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('VIDEO active', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{
        ...mockAppointment,
        communicationType: 'VIDEO',
        startTime: dayjs().toString(),
      }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('Request', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, status: 'NEW' as any }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('IN_PERSON', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, communicationType: 'IN_PERSON' }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('PARTIAL_SCHEDULED', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, status: 'PARTIAL_SCHEDULED' }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('PARTIAL_SCHEDULED same day', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{
        ...mockAppointment,
        status: 'PARTIAL_SCHEDULED',
        timeSlots: [{ startTime: dayjs().toString() }, { startTime: dayjs().toString() }],
      }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('PARTIAL_SCHEDULED different days', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{
        ...mockAppointment,
        status: 'PARTIAL_SCHEDULED',
        timeSlots: [
          { startTime: dayjs().toString() },
          { startTime: dayjs().add(1, 'day').toString() },
        ],
      }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('CANCELLED', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, status: 'CANCELLED' }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('RESCHEDULED', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, status: 'RESCHEDULED' }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ))
  .add('Check List', () => (
    <AppointmentItem
      isHeader={false}
      onPress={action('onPress')}
      appointment={{ ...mockAppointment, checkList: { items: [{ id: '1', title: 'check' }] } }}
      timeZonePreferences={TIMEZONE_PREFERENCES}
    />
  ));

import Connect from '../../../../assets/images/Connect.svg';
import VideoCall from '../../../../assets/images/VideoCallBlue.svg';

export const APPT_GET_READY_DATA = {
  BUTTON: {
    ADDITIONAL: {
      ICON: Connect,
      LABEL: 'How to add an additional caller',
      URL: 'https://mobile.va.gov/app/va-video-connect#AppFAQ',
    },
    CHECK_SETUP: {
      ICON: VideoCall,
      LABEL: 'Check your setup',
      URL:
        'https://care.va.gov/vvc-app/#/?name=Patient&join=1&media=1&escalate=1&conference=testwaitingroom@care.va.gov&pin=5678',
    },
  },
};

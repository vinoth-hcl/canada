import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet, View, Linking } from 'react-native';
import { useDispatch } from 'react-redux';
import { GText } from '../../GText/GText';
import { TextStyles } from '../../GText/styles';
import { Button } from '../../Button/Button';
import { Colors } from '../../../utilities/design';
import { appLog } from '../../../app/actions';
import { LogLevel } from '../../../app/types';
import { IButtonStyles } from '../../Button/types';
import { APPT_GET_READY_DATA } from './ApptDetailGetReadyBlock.model';

interface IOpenURLButton {
  url: string;
  children: JSX.Element;
  Icon: React.ElementType;
  style: IButtonStyles;
  accessibleTitle: string;
}

const OpenURLButton: FunctionComponent<IOpenURLButton> = ({
  url,
  children,
  Icon,
  style,
  accessibleTitle,
}) => {
  const dispatch = useDispatch();
  const handlePress = useCallback(async () => {
    const supported = await Linking.canOpenURL(url);

    if (supported) {
      await Linking.openURL(url);
    } else {
      dispatch(appLog('App error', `Don't know how to open this URL: ${url}`, LogLevel.ERROR));
    }
  }, [dispatch, url]);

  return (
    <Button
      Icon={Icon}
      onPress={handlePress}
      children={children}
      style={style}
      accessibleOptions={{ role: 'link' }}
      title={accessibleTitle}
    />
  );
};

export const ApptDetailGetReadyBlock = () => {
  return (
    <View style={styles.container}>
      <GText textStyle={TextStyles.BITTER_16_24_BOLD} style={styles.title}>
        Getting your device ready
      </GText>
      <OpenURLButton
        style={buttonStyle}
        Icon={APPT_GET_READY_DATA.BUTTON.ADDITIONAL.ICON}
        url={APPT_GET_READY_DATA.BUTTON.ADDITIONAL.URL}
        accessibleTitle={APPT_GET_READY_DATA.BUTTON.ADDITIONAL.LABEL}
      >
        <GText textStyle={TextStyles.SOURCE_SANS_16_24_SEMIBOLD} style={styles.link}>
          {APPT_GET_READY_DATA.BUTTON.ADDITIONAL.LABEL}
        </GText>
      </OpenURLButton>
      <OpenURLButton
        style={buttonStyle}
        Icon={APPT_GET_READY_DATA.BUTTON.CHECK_SETUP.ICON}
        url={APPT_GET_READY_DATA.BUTTON.CHECK_SETUP.URL}
        accessibleTitle={APPT_GET_READY_DATA.BUTTON.CHECK_SETUP.LABEL}
      >
        <GText textStyle={TextStyles.SOURCE_SANS_16_24_SEMIBOLD} style={styles.link}>
          {APPT_GET_READY_DATA.BUTTON.CHECK_SETUP.LABEL}
        </GText>
      </OpenURLButton>
    </View>
  );
};

export const styles = StyleSheet.create({
  container: {
    alignItems: 'flex-start',
    paddingTop: 32,
    paddingBottom: 16,
    paddingLeft: 16,
    paddingRight: 16,
  },
  title: {
    marginBottom: 16,
  },
  link: {
    color: Colors.newBlue,
    textDecorationLine: 'underline',
  },
  button: {
    flexDirection: 'row',
    marginBottom: 16,
    marginLeft: 16,
  },
  icon: {
    marginRight: 11,
  },
});

export const buttonStyle = {
  container: styles.button,
  iconContainerStyle: styles.icon,
};

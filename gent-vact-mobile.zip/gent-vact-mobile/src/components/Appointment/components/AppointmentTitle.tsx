import React, { FunctionComponent } from 'react';
import dayjs, { Dayjs } from 'dayjs';
import { StyleSheet, Text, View, ViewStyle } from 'react-native';
import { VIDEO_CALL_WITH } from '../../../constants/constants';
import { FORMAT_TIME_24_ENABLED } from '../../../utilities/config';

const formatDate = 'dddd, MMMM D YYYY';
const formatTime = FORMAT_TIME_24_ENABLED ? 'HH:mm' : 'hh:mm A';

interface IAppointmentTitleProps {
  name: string;
  date: string | Dayjs;
  style?: ViewStyle;
}

export const AppointmentTitle: FunctionComponent<IAppointmentTitleProps> = ({
  name,
  date,
  style = {},
}) => {
  return (
    <View style={style}>
      <Text style={styles.drName}>{VIDEO_CALL_WITH(name)}</Text>
      <Text style={styles.date}>{dayjs(date).format(formatDate)}</Text>
      <Text style={styles.date}>{dayjs(date).format(formatTime)}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  drName: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 20,
    lineHeight: 22,
  },
  date: { fontStyle: 'normal', fontWeight: 'normal', fontSize: 16, lineHeight: 24 },
});

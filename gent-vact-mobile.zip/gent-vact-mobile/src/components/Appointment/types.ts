import { AppointmentDto } from '../../api/AppointmentDto';

export interface IAppointmentViewProps {
  appointment: AppointmentDto;
  executeApp: (type: string, connectId: string) => void;
}

export interface IExtendedAppointment extends AppointmentDto {
  isLimited?: boolean;
}

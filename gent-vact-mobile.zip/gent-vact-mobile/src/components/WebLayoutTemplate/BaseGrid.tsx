import React, { FunctionComponent, useMemo } from 'react';
import { useWindowDimensions, StyleSheet, ScrollView, View } from 'react-native';
import { Colors } from '../../utilities/design';
import { getScreenModel } from './WebLayoutTemplate';

const ONE_COLUMN = ['MOBILE', 'SMALL', 'TINY'];

const usePortrait = () => {
  const dimensions = useWindowDimensions();
  const screenModel = useMemo(() => getScreenModel(dimensions.width), [dimensions.width]);

  return ONE_COLUMN.includes(screenModel);
};

const getLeftStyles = (isPortrait: boolean, style: any) =>
  isPortrait
    ? StyleSheet.create({
        container: {
          alignItems: 'center',
          flexBasis: style?.flexBasis || 200,
        },
        column: {
          width: '100%',
          maxWidth: '100%',
          height: 'auto',
        },
        content: { paddingLeft: 0, paddingRight: 0, width: 432 },
      })
    : StyleSheet.create({
        container: {
          alignItems: 'flex-end',
          flexBasis: '50%',
        },
        column: {
          width: '100%',
          maxWidth: 512,
          height: '100%',
          flex: 1,
        },
        content: { paddingLeft: 80, paddingRight: 80, width: 'auto' },
      });

const getRightStyles = (isPortrait: boolean, style: any) =>
  isPortrait
    ? StyleSheet.create({
        container: {
          flexBasis: style?.flexBasis || 'auto',
          flexGrow: 1,
          backgroundColor: Colors.whiteGray,
          alignItems: 'center',
          justifyContent: 'center',
        },
        column: {
          width: '100%',
          maxWidth: '100%',
          justifyContent: 'center',
          alignItems: 'center',
          height: 'auto',
        },
        content: { paddingLeft: 0, paddingRight: 0, width: 432 },
      })
    : StyleSheet.create({
        container: {
          flexBasis: '50%',
          flexGrow: 1,
          backgroundColor: Colors.whiteGray,
          alignItems: 'flex-start',
          justifyContent: 'center',
        },
        column: {
          flex: 1,
          maxWidth: 512,
          justifyContent: 'center',
          alignItems: 'center',
        },
        content: { paddingLeft: 40, paddingRight: 40, width: 'auto' },
      });

export const Grid: FunctionComponent = ({ children }) => {
  const isPortrait = usePortrait();

  return (
    <View
      style={{
        flexDirection: isPortrait ? 'column' : 'row',
        flex: 1,
        backgroundColor: Colors.white,
      }}
    >
      {children}
    </View>
  );
};

export const LeftColumn: FunctionComponent<{ header?: JSX.Element; style?: any }> = ({
  header,
  style,
  children,
}) => {
  const isPortrait = usePortrait();
  const styles = useMemo(() => getLeftStyles(isPortrait, style), [isPortrait, style]);

  return (
    <View style={styles.container}>
      <View style={styles.column}>
        {header}
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <View style={styles.content}>{children}</View>
        </View>
      </View>
    </View>
  );
};

export const RightColumn: FunctionComponent<{ style?: any }> = ({ style, children }) => {
  const isPortrait = usePortrait();
  const styles = useMemo(() => getRightStyles(isPortrait, style), [isPortrait, style]);
  return isPortrait ? (
    <View style={styles.container}>
      <View style={styles.column}>
        <View style={styles.content}>{children}</View>
      </View>
    </View>
  ) : (
    <View style={styles.container}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ flexGrow: 1 }}>
        <View style={styles.column}>
          <View style={styles.content}>{children}</View>
        </View>
      </ScrollView>
    </View>
  );
};

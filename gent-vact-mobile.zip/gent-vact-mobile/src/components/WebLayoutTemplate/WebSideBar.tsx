import React, { FunctionComponent } from 'react';
import { ScrollView, StyleSheet } from 'react-native';

interface IWebSideBarProps {
  items?: React.ReactElement[];
  scrollEnabled: boolean;
  height: number | string;
  center?: boolean;
}

export const WebSideBar: FunctionComponent<IWebSideBarProps> = ({
  items,
  scrollEnabled,
  height,
  center,
}) => {
  return items && items.length > 0 ? (
    <ScrollView
      style={styles.container}
      scrollEnabled={scrollEnabled}
      showsVerticalScrollIndicator={scrollEnabled}
      contentContainerStyle={[{ height }, center && styles.center]}
    >
      {items.map((item, index) => (
        <div key={index}>{item}</div>
      ))}
    </ScrollView>
  ) : null;
};

const styles = StyleSheet.create({
  container: {
    width: '50%',
  },
  center: {
    display: 'flex',
    justifyContent: 'flex-start',
    marginTop: '20%',
    alignItems: 'center',
  },
});

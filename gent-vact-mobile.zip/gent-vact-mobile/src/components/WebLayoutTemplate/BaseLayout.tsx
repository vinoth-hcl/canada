import React, { FunctionComponent } from 'react';
import { ScrollView, View } from 'react-native';
import { Colors } from '../../utilities/design';

export const BaseLayout: FunctionComponent = ({ children }) => {
  return (
    <View style={{ backgroundColor: Colors.white, flex: 1 }}>
      <ScrollView showsVerticalScrollIndicator={true} contentContainerStyle={{ flex: 1 }}>
        {children}
      </ScrollView>
    </View>
  );
};

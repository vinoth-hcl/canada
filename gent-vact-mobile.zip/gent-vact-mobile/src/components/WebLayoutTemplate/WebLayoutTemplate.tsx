import React, { FunctionComponent, useCallback, useMemo } from 'react';
import {
  Platform,
  ScrollView,
  StyleSheet,
  useWindowDimensions,
  View,
  ViewStyle,
} from 'react-native';
import { OS_WEB } from '../../constants/constants';
import { Separator } from '../Separator/Separator';
import { Colors } from '../../utilities/design';
import { WebSideBar } from './WebSideBar';

export enum WebViews {
  MOBILE = 'MOBILE',
  LARGE = 'LARGE',
  MEDIUM = 'MEDIUM',
  SMALL = 'SMALL',
  TINY = 'TINY',
}

export const getScreenModel = (width: number): WebViews => {
  if (Platform.OS !== OS_WEB) {
    return WebViews.MOBILE;
  }
  if (width > 1024) {
    return WebViews.LARGE;
  }
  if (width > 800) {
    return WebViews.MEDIUM;
  }
  if (width > 500) {
    return WebViews.SMALL;
  }
  return WebViews.TINY;
};

interface IWebLayoutTemplateProps {
  header?: React.ReactElement[];
  leftSide?: React.ReactElement[];
  rightSide?: React.ReactElement[];
  enableLeftScroll?: boolean;
  centerLeft?: boolean;
  centerRight?: boolean;
  enableRightScroll?: boolean;
  enableCommonScroll?: boolean;
  placeholder?: React.ReactElement;
  children?: any;
  enableContainer?: boolean;
  topMargin?: number;
  isSeparator?: boolean;
  button?: React.ReactElement;
  showsVerticalScroll?: boolean;
  largeContainerWidth?: number | string;
  heightColumns?: number | string;
}

export const WebLayoutTemplate: FunctionComponent<IWebLayoutTemplateProps> = ({
  header,
  leftSide,
  rightSide,
  enableLeftScroll = true,
  centerLeft = false,
  centerRight = false,
  enableRightScroll = true,
  enableCommonScroll = true,
  showsVerticalScroll = false,
  placeholder,
  children,
  enableContainer = true,
  topMargin = 40,
  isSeparator = false,
  button = null,
  largeContainerWidth = 1024,
  heightColumns,
}) => {
  const dimensions = useWindowDimensions();
  const screenModel = useMemo(() => getScreenModel(dimensions.width), [dimensions.width]);
  const styles = createStyles(topMargin, largeContainerWidth);

  const mobileRender = useCallback(() => {
    return (
      <>
        {header}
        {leftSide}
        {rightSide}
      </>
    );
  }, [header, leftSide, rightSide]);

  const tinyRender = useCallback(() => {
    return (
      <ScrollView
        style={[styles.container, styles.tinyContainer]}
        showsVerticalScrollIndicator={showsVerticalScroll}
      >
        {header && header.map((item, index) => <div key={index}>{item}</div>)}
        {leftSide && leftSide.map((item, index) => <div key={index}>{item}</div>)}
        {rightSide && rightSide.map((item, index) => <div key={index}>{item}</div>)}
      </ScrollView>
    );
  }, [header, leftSide, rightSide, styles, showsVerticalScroll]);

  const smallRender = useCallback(() => {
    return (
      <ScrollView
        scrollEnabled={enableCommonScroll}
        style={[styles.container, styles.smallContainer]}
        showsVerticalScrollIndicator={showsVerticalScroll}
        contentContainerStyle={{
          height: dimensions.height - topMargin,
        }}
      >
        {header && header.map((item, index) => <div key={index}>{item}</div>)}
        {leftSide && leftSide.map((item, index) => <div key={index}>{item}</div>)}
        {rightSide && rightSide.map((item, index) => <div key={index}>{item}</div>)}
      </ScrollView>
    );
  }, [
    dimensions.height,
    header,
    leftSide,
    rightSide,
    enableCommonScroll,
    topMargin,
    styles,
    showsVerticalScroll,
  ]);

  const getHeight = useCallback(() => {
    return heightColumns || dimensions.height - topMargin;
  }, [heightColumns, dimensions.height, topMargin]);

  const largeRender = useCallback(
    (style: ViewStyle) => {
      let containerWidth = {};
      if (!enableContainer) {
        containerWidth = { width: '100%' };
      }

      return (
        <>
          {isSeparator && (
            <div style={{ position: 'fixed', marginLeft: '50%' }}>
              <Separator
                style={StyleSheet.flatten([styles.separator, { height: dimensions.height - 168 }])}
              />
            </div>
          )}
          {button && (
            <div
              style={{
                position: 'fixed',
                width: '50%',
                maxWidth: 512,
                height: 96,
                right: dimensions.width / 2,
                bottom: 88,
                backgroundColor: Colors.white,
                zIndex: 1,
              }}
            >
              <View style={styles.button} children={button} />
            </div>
          )}
          <ScrollView
            style={[styles.container, style, containerWidth]}
            scrollEnabled={enableCommonScroll}
            showsVerticalScrollIndicator={showsVerticalScroll}
            contentContainerStyle={{
              height: dimensions.height - topMargin,
            }}
          >
            {header && header.length > 0 && (
              <View style={styles.largeSubContainer}>
                {header.map((item, index) => (
                  <div key={index} style={{ width: '100%' }}>
                    {item}
                  </div>
                ))}
              </View>
            )}
            <View style={styles.largeSubContainer}>
              <WebSideBar
                items={leftSide}
                scrollEnabled={enableLeftScroll}
                center={centerLeft}
                height={getHeight()}
              />
              <WebSideBar
                items={rightSide}
                scrollEnabled={enableRightScroll}
                height={getHeight()}
                center={centerRight}
              />
            </View>
          </ScrollView>
        </>
      );
    },
    [
      dimensions,
      isSeparator,
      button,
      header,
      leftSide,
      rightSide,
      enableRightScroll,
      enableLeftScroll,
      enableCommonScroll,
      centerLeft,
      centerRight,
      enableContainer,
      topMargin,
      styles,
      showsVerticalScroll,
      getHeight,
    ],
  );

  if (placeholder) {
    return placeholder;
  }

  if (children) {
    return children;
  }

  switch (screenModel) {
    case WebViews.MOBILE:
      return mobileRender();
    case WebViews.TINY:
      return tinyRender();
    case WebViews.SMALL:
      return smallRender();
    case WebViews.MEDIUM:
      return largeRender(styles.mediumContainer);
    default:
      return largeRender(styles.largeContainer);
  }
};

const createStyles = (marginTop: number, largeContainerWidth: number | string) => {
  return StyleSheet.create({
    container: {
      marginLeft: 0,
      marginRight: 0,
      paddingTop: marginTop,
      marginBottom: 0,
      flexDirection: 'column',
      alignSelf: 'center',
    },
    tinyContainer: {
      width: 500,
    },
    smallContainer: {
      width: '100%',
    },
    largeContainer: {
      width: largeContainerWidth,
      height: '100%',
    },
    largeSubContainer: {
      flexDirection: 'row',
    },
    mediumContainer: {
      width: '100%',
    },
    separator: {
      borderBottomWidth: 0,
      borderLeftWidth: 1,
      marginLeft: 0,
      marginRight: 0,
      position: 'absolute',
      top: 40,
    },
    button: {
      height: 96,
      backgroundColor: Colors.white,
      borderTopWidth: 1,
      borderTopColor: Colors.separatorColor,
      justifyContent: 'center',
      alignItems: 'center',
    },
  });
};

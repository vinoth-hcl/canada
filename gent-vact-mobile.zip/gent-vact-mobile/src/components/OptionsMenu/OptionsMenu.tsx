import React, { FunctionComponent } from 'react';
import { map, filter, isUndefined } from 'lodash';
import { StyleSheet, View } from 'react-native';
import { OptionsMenuType, MenuTypes } from '../../scenes/Options/types';
import { RadioButtonTypes } from '../RadioButtons/RadioButton';
import { RadioButtons } from '../RadioButtons/RadioButtons';
import { Colors } from '../../utilities/design';
import { MenuHeader } from './MenuHeader';
import { MenuButton } from './MenuButton';
import { MenuCheckButton } from './MenuCheckButton';
import { OptionsSelector } from './OptionsSelector';

interface IOptionsMenuProps {
  menu: OptionsMenuType;
}

export function getOptionsItems(menu: OptionsMenuType, keyPrefix = '') {
  return filter(
    map(menu, (item, key) => {
      switch (item.type) {
        case MenuTypes.HEADER:
          return (
            <MenuHeader
              viewStyle={item.viewStyle}
              key={`${key}${keyPrefix}`}
              text={item.text}
              level={item.level}
            />
          );
        case MenuTypes.BUTTON:
          return (
            <MenuButton
              viewStyle={item.viewStyle}
              Icon={item.icon}
              key={`${key}${keyPrefix}`}
              text={item.text}
              onPress={item.onPress}
              level={item.level}
              isDisable={item.isDisable}
            />
          );
        case MenuTypes.CHECK_BUTTON:
          return (
            <MenuCheckButton
              text={item.text}
              id={key}
              key={`${key}${keyPrefix}`}
              viewStyle={item.viewStyle}
              onPress={item.onPress}
              initialCheck={item.initialState as boolean}
            />
          );
        case MenuTypes.RADIO_BUTTONS:
          return (
            <RadioButtons
              values={item.values as string[]}
              key={`${key}${keyPrefix}`}
              itemStyle={item.viewStyle}
              type={RadioButtonTypes.SMALL_GOLD}
              onPress={item.onPress as any}
              initialIndex={item.initialState as number}
            />
          );
        case MenuTypes.SEPARATOR:
          return <View key={`${key}${keyPrefix}`} style={styles.separator} />;
        case MenuTypes.GROUP_SEPARATOR:
          return <View key={`${key}${keyPrefix}`} style={styles.groupSeparator} />;
        case MenuTypes.SINGLE_SELECT:
          return (
            <OptionsSelector
              key={`${key}${keyPrefix}`}
              text={item.text}
              multiSelect={false}
              values={item.values as any}
              onPress={item.onPress as any}
            />
          );
        case MenuTypes.MULTI_SELECT:
          return (
            <OptionsSelector
              key={`${key}${keyPrefix}`}
              text={item.text}
              multiSelect={true}
              values={item.values as any}
              onPress={item.onPress as any}
            />
          );
        default:
          return null;
      }
    }),
    (item) => !isUndefined(item),
  );
}

export const OptionsMenu: FunctionComponent<IOptionsMenuProps> = ({ menu }) => {
  return <>{getOptionsItems(menu)}</>;
};

const styles = StyleSheet.create({
  separator: {
    height: 1,
    borderTopColor: Colors.greyWarmLight,
    borderTopWidth: 1,
    marginLeft: 24,
    marginRight: 24,
    marginTop: 20,
    marginBottom: 20,
  },
  groupSeparator: {
    height: 1,
    marginTop: 32,
    marginBottom: 0,
  },
});

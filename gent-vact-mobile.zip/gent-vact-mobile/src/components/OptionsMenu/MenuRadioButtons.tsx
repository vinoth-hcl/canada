import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';

interface IMenuRadioButtonsProps {}

export const MenuRadioButtons: FunctionComponent<IMenuRadioButtonsProps> = () => {
  return <View style={styles.container} />;
};

const styles = StyleSheet.create({
  container: {},
});

import React from 'react';
import { storiesOf } from '@storybook/react-native';

import { withKnobs } from '@storybook/addon-knobs';
import { View } from 'react-native';
import centered from '../../../storybook/decorators/centered';
import { notificationsMenu, optionsMenu } from '../../scenes/Options/menu';
import { selectorValues } from '../../scenes/Options/types';
import { OptionsMenu } from './OptionsMenu';
import { OptionsSelector } from './OptionsSelector';

const values = [
  { id: 1, text: '1 Day', isSelected: false, value: 86400 },
  { id: 2, text: '2 Days', isSelected: false, value: 172800 },
  { id: 3, text: '3 Days', isSelected: false, value: 259200 },
  { id: 4, text: '4 Days', isSelected: false, value: 345600 },
  { id: 5, text: '5 Days', isSelected: false, value: 432000 },
] as selectorValues;

storiesOf('OptionsMenu', module)
  .addDecorator(centered)
  .addDecorator(withKnobs)
  .add('optionsMenu', () => (
    <View style={{ width: 400 }}>
      <OptionsMenu menu={optionsMenu} />
    </View>
  ))
  .add('notificationsMenu', () => (
    <View style={{ width: 400 }}>
      <OptionsMenu menu={notificationsMenu} />
    </View>
  ));

storiesOf('OptionsSelector', module)
  .addDecorator(centered)
  .add('single select', () => (
    <OptionsSelector text={'Options selector header '} multiSelect={false} values={values} />
  ))
  .add('milty select', () => (
    <OptionsSelector text={'Options selector header '} multiSelect={true} values={values} />
  ));

import React, { FunctionComponent } from 'react';
import { ViewStyle } from 'react-native';
import { CheckBoxItem } from '../CheckBoxBlock/CheckBoxItem';
import { CheckBoxTypes } from '../CheckBoxBlock/types';
import { FormattedString } from '../FormattedText/types';

interface IMenuCheckButtonProps {
  viewStyle?: ViewStyle;
  text?: string | FormattedString;
  id: string | number;
  onPress?: (params: any) => void;
  initialCheck?: boolean;
}

export const MenuCheckButton: FunctionComponent<IMenuCheckButtonProps> = ({
  viewStyle = {},
  text = '',
  id,
  onPress = () => {},
  initialCheck,
}) => {
  return (
    <CheckBoxItem
      text={text}
      type={CheckBoxTypes.SMALL_GOLD}
      index={id}
      key={id}
      style={viewStyle}
      allViewTouchable
      onCheck={onPress}
      initialCheck={initialCheck}
    />
  );
};

import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { Colors } from '../../utilities/design';
import { testId } from '../../utilities/TestId';
import Confirm from '../../../assets/images/Confirm.svg';
import { GText } from '../GText/GText';
import { TextStyles } from '../GText/styles';

export type IOptionsSelector = {
  id: number;
  text: string;
  isSelected: boolean;
};

interface IOptionsSelectorElementProps {
  value: IOptionsSelector;
  onPress?: (value: IOptionsSelector) => void;
  accessibleRole: 'radio' | 'checkbox';
}

export const OptionsSelectorElement: FunctionComponent<IOptionsSelectorElementProps> = ({
  value,
  onPress = () => {},
  accessibleRole,
}) => {
  const handlePress = useCallback(() => {
    const newValue = { ...value, isSelected: !value.isSelected };
    onPress(newValue);
  }, [value, onPress]);

  return (
    <TouchableOpacity
      style={[styles.container, value.isSelected && styles.checked]}
      onPress={handlePress}
      {...testId(`options_selector${value.text}`, value.text, accessibleRole)}
      accessibilityState={{ checked: value.isSelected }}
    >
      <GText
        style={styles.text}
        textStyle={TextStyles.SOURCE_SANS_16_24_SEMIBOLD}
        testID={`options_selector_text_${value.text}`}
      >
        {value.text}
      </GText>
      {value.isSelected && <Confirm />}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 48,
    borderRadius: 24,
    borderColor: Colors.greyDark,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    width: '48%',
  },
  text: {
    marginRight: 8,
  },
  checked: {
    borderWidth: 0,
    borderTopWidth: 0,
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderBottomWidth: 0,
    backgroundColor: Colors.goldLight,
  },
});

import React, { FunctionComponent } from 'react';
import { View, ViewStyle } from 'react-native';

import { GText } from '../GText/GText';
import { MenuLevel } from '../../scenes/Options/types';
import { FormattedString } from '../FormattedText/types';
import { TextStyles } from '../GText/styles';

interface IMenuHeaderProps {
  level: MenuLevel;
  viewStyle?: ViewStyle;
  text?: string | FormattedString;
}

export const MenuHeader: FunctionComponent<IMenuHeaderProps> = ({
  viewStyle = {},
  text = '',
  level,
}) => {
  const textStyle =
    level === MenuLevel.PRIMARY
      ? TextStyles.SOURCE_SANS_16_24_NORMAL
      : TextStyles.BITTER_16_24_BOLD;

  return (
    <View style={viewStyle}>
      <GText textStyle={textStyle} testID={`header_${text}`} children={text} role={'header'} />
    </View>
  );
};

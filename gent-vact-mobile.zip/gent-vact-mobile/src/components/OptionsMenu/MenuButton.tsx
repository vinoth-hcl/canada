import React, { FunctionComponent } from 'react';
import { StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';

import { testId } from '../../utilities/TestId';
import { GText } from '../GText/GText';
import { MenuLevel } from '../../scenes/Options/types';
import Arrow from '../../../assets/images/ArrowExpand.svg';
import { Colors } from '../../utilities/design';
import { FormattedString } from '../FormattedText/types';
import { TextStyles } from '../GText/styles';

interface IMenuButtonProps {
  level: MenuLevel;
  viewStyle?: ViewStyle;
  text?: string | FormattedString;
  onPress?: (item?: any) => void;
  Icon?: React.ElementType;
  isDisable?: boolean;
}

export const MenuButton: FunctionComponent<IMenuButtonProps> = ({
  level,
  viewStyle = {},
  text = '',
  onPress = () => {},
  Icon = null,
  isDisable = false,
}) => {
  const hasAdditionalIcon = level === MenuLevel.PRIMARY;

  return (
    <TouchableOpacity
      style={StyleSheet.flatten([viewStyle, isDisable && { backgroundColor: Colors.greyLighter }])}
      onPress={onPress}
      {...testId(`menu_button_${text}`, text.toString(), 'button')}
      disabled={isDisable}
      accessibilityState={{ disabled: isDisable }}
    >
      {Icon && <Icon style={{ marginRight: 11 }} />}
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        testID={`menu_button_text${text}`}
        children={text}
      />
      {hasAdditionalIcon && (
        <View
          style={{ position: 'absolute', right: 16 }}
          importantForAccessibility={'no-hide-descendants'}
        >
          <Arrow />
        </View>
      )}
    </TouchableOpacity>
  );
};

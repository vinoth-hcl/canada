import React, { FunctionComponent, useCallback, useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { FormattedString } from '../FormattedText/types';
import { GText } from '../GText/GText';
import { TextStyles } from '../GText/styles';
import { Colors } from '../../utilities/design';
import { IOptionsSelector, OptionsSelectorElement } from './OptionsSelectorElement';

interface IOptionsSelectorProps {
  multiSelect?: boolean;
  values?: IOptionsSelector[];
  text?: FormattedString | string;
  onPress?: (values: IOptionsSelector[]) => void;
}

export const OptionsSelector: FunctionComponent<IOptionsSelectorProps> = ({
  text = '',
  values = [],
  multiSelect = false,
  onPress = () => {},
}) => {
  const [state, setState] = useState(values);
  const handlePress = useCallback(
    (value) => {
      const newValues = state.map((item) => {
        if (item.id === value.id) {
          return value;
        } else {
          if (!multiSelect && value.isSelected) {
            return { ...item, isSelected: false };
          } else {
            return item;
          }
        }
      });
      onPress(newValues);
      setState(newValues);
    },
    [onPress, state, multiSelect],
  );

  return (
    <View style={styles.container}>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        testID={'options_selector_header'}
        style={{
          textAlign: 'left',
          color: Colors.greyDark,
        }}
        children={text}
      />
      <View style={styles.items}>
        {state.map((item, index) => (
          <OptionsSelectorElement
            value={item}
            onPress={handlePress}
            key={`${index}${multiSelect}`}
            accessibleRole={multiSelect ? 'checkbox' : 'radio'}
          />
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginLeft: 15,
    marginRight: 15,
  },
  items: {
    marginTop: 16,
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

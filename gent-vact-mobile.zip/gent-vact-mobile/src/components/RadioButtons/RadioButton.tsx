import React, { FunctionComponent, useCallback } from 'react';
import { Pressable, TextStyle, View, ViewStyle } from 'react-native';

import { Colors } from '../../utilities/design';
import { testId } from '../../utilities/TestId';
import { GText } from '../GText/GText';
import { TextStyles } from '../GText/styles';

export enum RadioButtonTypes {
  SMALL_GOLD = 'smallGold',
}

export const RadioButtonsStyles: {
  [k: string]: { dotStyle: ViewStyle; checkedDotStyle: ViewStyle; textStyle: TextStyle };
} = {
  smallGold: {
    dotStyle: {
      backgroundColor: 'white',
      marginLeft: 13,
      width: 28,
      height: 28,
      borderRadius: 14,
      borderColor: Colors.lightGray,
      borderTopWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderBottomWidth: 1,
      alignItems: 'center',
      justifyContent: 'center',
    },
    checkedDotStyle: {
      width: 18,
      height: 18,
      borderRadius: 9,
      backgroundColor: Colors.gold,
    },
    textStyle: {
      color: Colors.greyDark,
      marginLeft: 10,
      display: 'flex',
      flexDirection: 'row',
      flexWrap: 'wrap',
    },
  },
};

interface IRadioButtonProps {
  index: string | number;
  text: string;
  onPress?: (index: string | number) => void;
  isChecked: boolean;
  style?: ViewStyle;
  type?: RadioButtonTypes;
  allViewTouchable?: boolean;
}

export const RadioButton: FunctionComponent<IRadioButtonProps> = ({
  index,
  text,
  onPress = () => {},
  style = {},
  type = RadioButtonTypes.SMALL_GOLD,
  allViewTouchable = true,
  isChecked,
}) => {
  const { dotStyle, checkedDotStyle, textStyle } = RadioButtonsStyles[type];
  const handlePress = useCallback(() => {
    onPress(index);
  }, [index, onPress]);

  return allViewTouchable ? (
    <Pressable
      style={[{ flexDirection: 'row' }, style]}
      onPress={handlePress}
      {...testId(`radio_${index}_${text}`, text, 'radio')}
      accessibilityState={{ checked: isChecked }}
    >
      <View
        style={dotStyle}
        {...testId(`radio_dot${index}_${text}`)}
        importantForAccessibility={'no-hide-descendants'}
      >
        {isChecked && (
          <View style={checkedDotStyle} {...testId(`radio_dot_checked${index}_${text}`)} />
        )}
      </View>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        style={textStyle}
        testID={`radio_text${index}_${text}`}
        children={text}
      />
    </Pressable>
  ) : (
    <View style={[{ flexDirection: 'row' }, style]}>
      <Pressable style={dotStyle} onPress={handlePress} {...testId(`radio_${index}_${text}`)}>
        {isChecked && (
          <View
            style={checkedDotStyle}
            {...testId(`radio_dot_checked${index}_${text}`)}
            importantForAccessibility={'no'}
          />
        )}
      </Pressable>
      <GText
        textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
        style={textStyle}
        testID={`radio_text${index}_${text}`}
        children={text}
      />
    </View>
  );
};

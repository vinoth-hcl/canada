import React from 'react';
import { ViewStyle } from 'react-native';
import { storiesOf } from '@storybook/react-native';
import centered from '../../../storybook/decorators/centered';
import { Colors } from '../../utilities/design';
import { RadioButtons } from './RadioButtons';
import { RadioButtonTypes } from './RadioButton';

const values = ['Item 1', 'Item 2', 'Item 3'];

const buttonStyle: ViewStyle = {
  flexDirection: 'row',
  justifyContent: 'flex-start',
  marginLeft: 25,
  marginRight: 25,
  marginTop: 12,
  height: 47,
  alignItems: 'center',
  borderTopWidth: 1,
  borderLeftWidth: 1,
  borderRightWidth: 1,
  borderBottomWidth: 1,
  borderRadius: 10,
  borderColor: Colors.almostWhite,
};

storiesOf('RadioButtons', module)
  .addDecorator(centered)
  .add('View', () => (
    <RadioButtons
      values={values}
      itemStyle={buttonStyle}
      type={RadioButtonTypes.SMALL_BLACK}
      initialIndex={0}
    />
  ));

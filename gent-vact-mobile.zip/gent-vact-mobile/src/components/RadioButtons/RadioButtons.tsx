import React, { FunctionComponent, useCallback, useState } from 'react';
import { View, ViewStyle } from 'react-native';
import { RadioButton, RadioButtonTypes } from './RadioButton';

interface IRadioButtonsProps {
  values?: string[];
  type: RadioButtonTypes;
  style?: ViewStyle;
  itemStyle?: ViewStyle;
  onPress?: (index: number) => void;
  initialIndex?: number;
}

export const RadioButtons: FunctionComponent<IRadioButtonsProps> = ({
  values = [],
  type,
  style = {},
  itemStyle = {},
  onPress = () => {},
  initialIndex,
}) => {
  const [selected, setSelected] = useState(initialIndex);
  const handlePress = useCallback(
    (index) => {
      if (selected !== index) {
        onPress(index);
        setSelected(index);
      }
    },
    [selected, onPress],
  );

  return (
    <View style={style}>
      {values.map((item, index) => {
        return (
          <RadioButton
            type={type}
            text={item}
            index={index}
            onPress={handlePress}
            isChecked={index === selected}
            style={itemStyle}
            key={`${item}_${index}`}
          />
        );
      })}
    </View>
  );
};

import {
  AccessibilityRole,
  GestureResponderEvent,
  StyleProp,
  TextStyle,
  ViewStyle,
} from 'react-native';
import { TextStyles } from '../GText/styles';

export interface IGradient {
  start?: { x: number; y: number };
  end?: { x: number; y: number };
  location?: number[];
  colors: string[];
  baseColor?: string;
}

export interface IButtonStyles {
  container?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  textFont?: TextStyles;
  iconStyle?: StyleProp<ViewStyle>;
  iconContainerStyle?: StyleProp<ViewStyle>;
}

export interface IButtonProps {
  onPress?: (event: GestureResponderEvent) => void;
  style?: IButtonStyles;
  disabled?: boolean;
  activeOpacity?: number;
  text?: string | number;
  kind?: ButtonKind;
  Icon?: React.ElementType;
  isShadow?: boolean;
  testID?: string;
  role?: AccessibilityRole;
  accessibilityState?: { checked?: boolean; disabled?: boolean };
}

export enum ButtonKind {
  BLUE = 'BLUE',
  WHITE = 'WHITE',
  DISABLED = 'DISABLED',
  DEFAULT = 'DEFAULT',
}

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { boolean, text, withKnobs } from '@storybook/addon-knobs';
import { action } from '@storybook/addon-actions';

import centered from '../../../storybook/decorators/centered';
import ConfirmWhite from '../../../assets/images/Button/ConfirmWhite.svg';
import ConfirmBlue from '../../../assets/images/Button/ConfirmBlue.svg';
import { GButton } from './GButton';
import { ButtonKind } from './types';

storiesOf('Button', module)
  .addDecorator(centered)
  .addDecorator(withKnobs)
  .add('button: kind = BLUE', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.BLUE}
    />
  ))
  .add('button: kind = BLUE + Icon', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.BLUE}
      Icon={ConfirmWhite}
    />
  ))
  .add('button: kind = BLUE + Shadow', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.BLUE}
      isShadow
    />
  ))
  .add('button: kind = WHITE', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.WHITE}
    />
  ))
  .add('button: kind = WHITE + Icon', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.WHITE}
      Icon={ConfirmBlue}
    />
  ))
  .add('button: kind = WHITE + Shadow', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.WHITE}
      isShadow
    />
  ))
  .add('button: kind = DISABLED', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', true)}
      kind={ButtonKind.DISABLED}
    />
  ))
  .add('button: kind = DISABLED + Icon', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', true)}
      kind={ButtonKind.DISABLED}
      Icon={ConfirmWhite}
    />
  ))
  .add('button: kind = DISABLED + Shadow', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', true)}
      kind={ButtonKind.DISABLED}
      isShadow
    />
  ))
  .add('button: kind = DEFAULT', () => (
    <GButton
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.DEFAULT}
    />
  ));

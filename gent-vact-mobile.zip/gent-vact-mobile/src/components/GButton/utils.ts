import { StyleProp, StyleSheet, TextStyle, ViewStyle } from 'react-native';

import { Colors } from '../../utilities/design';
import { ButtonKind } from './types';

export const getButtonStyle = (
  kind: ButtonKind,
): {
  button: StyleProp<ViewStyle>;
  text: StyleProp<TextStyle>;
  icon?: StyleProp<TextStyle>;
} => {
  switch (kind) {
    case ButtonKind.BLUE: {
      return {
        button: [buttonStyles.default, buttonStyles.container, buttonStyles.buttonBlue],
        text: [buttonStyles.textWhite],
        icon: [buttonStyles.iconContainer],
      };
    }
    case ButtonKind.WHITE: {
      return {
        button: [buttonStyles.default, buttonStyles.container, buttonStyles.buttonWhite],
        text: [buttonStyles.textBlue],
        icon: [buttonStyles.iconContainer],
      };
    }
    case ButtonKind.DISABLED: {
      return {
        button: [buttonStyles.default, buttonStyles.container, buttonStyles.buttonGrey],
        text: [buttonStyles.textWhite],
        icon: [buttonStyles.iconContainer],
      };
    }

    default: {
      return {
        button: [buttonStyles.default, buttonStyles.buttonWhite],
        text: [buttonStyles.textGreyDark],
        icon: [buttonStyles.iconContainer],
      };
    }
  }
};

export const buttonStyles = StyleSheet.create({
  default: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    height: 48,
    borderTopStartRadius: 24,
    borderTopEndRadius: 24,
    borderBottomStartRadius: 24,
    borderBottomEndRadius: 24,
  },
  iconContainer: {
    marginRight: 12,
  },
  buttonWhite: {
    backgroundColor: Colors.white,
  },
  textWhite: {
    color: Colors.white,
  },
  textGreyDark: {
    color: Colors.greyDark,
  },
  buttonBlue: {
    backgroundColor: Colors.newBlue,
  },
  buttonGrey: {
    backgroundColor: Colors.greyLight,
  },
  textBlue: {
    color: Colors.newBlue,
  },
  shadow: {
    shadowColor: Colors.black,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 12,
  },
  shadowDisabled: {
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
  },
});

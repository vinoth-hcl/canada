import React, { FunctionComponent } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

import { testId } from '../../utilities/TestId';
import { GText } from '../GText/GText';
import { TextStyles } from '../GText/styles';
import { ButtonKind, IButtonProps } from './types';
import { buttonStyles as defaultStyles, getButtonStyle } from './utils';

function getStyleShadow(kind: ButtonKind) {
  return [defaultStyles.shadow, kind === ButtonKind.DISABLED && defaultStyles.shadowDisabled];
}

export const GButton: FunctionComponent<IButtonProps> = ({
  text,
  style = {},
  onPress,
  disabled = false,
  activeOpacity = 0.6,
  kind = ButtonKind.DEFAULT,
  Icon,
  children,
  isShadow = false,
  testID = '',
  role = 'button',
  accessibilityState,
}) => {
  const {
    container = {},
    textStyle = {},
    iconStyle = {},
    iconContainerStyle = {},
    textFont = TextStyles.SOURCE_SANS_16_24_SEMIBOLD,
  } = style;

  const styles = getButtonStyle(kind);

  const buttonStyles = StyleSheet.flatten([
    styles.button,
    isShadow && getStyleShadow(kind),
    container,
  ]);
  const textStyles = StyleSheet.flatten([styles.text, textStyle]);
  const iconContainer = StyleSheet.flatten([styles.icon, iconContainerStyle]);

  return (
    <TouchableOpacity
      activeOpacity={activeOpacity}
      onPress={disabled ? undefined : onPress}
      disabled={disabled || kind === ButtonKind.DISABLED}
      style={buttonStyles}
      {...testId(`ButtonContainer_${testID}`, `${text}`, role)}
      accessibilityState={{
        disabled: disabled,
        checked: accessibilityState && accessibilityState.checked,
      }}
    >
      {Icon && (
        <View style={iconContainer} importantForAccessibility={'no-hide-descendants'}>
          <Icon style={StyleSheet.flatten(iconStyle)} {...testId(`Icon_${testID}`)} />
        </View>
      )}
      {!!text && (
        <GText textStyle={textFont} style={textStyles} testID={`Text_${testID}`} children={text} />
      )}
      {children}
    </TouchableOpacity>
  );
};

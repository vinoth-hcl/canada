import { getButtonStyle, buttonStyles } from './utils';
import { ButtonKind } from './types';

describe('GButton utils tests', () => {
  describe('getButtonStyle test', () => {
    it('if kind = default should return default styles', () => {
      const result = {
        button: [buttonStyles.default, buttonStyles.buttonWhite],
        text: [buttonStyles.textGreyDark],
        icon: [buttonStyles.iconContainer],
      };
      expect(getButtonStyle(ButtonKind.DEFAULT)).toEqual(result);
    });

    it('if kind = blue should return blue styles', () => {
      const result = {
        button: [buttonStyles.default, buttonStyles.container, buttonStyles.buttonBlue],
        text: [buttonStyles.textWhite],
        icon: [buttonStyles.iconContainer],
      };
      expect(getButtonStyle(ButtonKind.BLUE)).toEqual(result);
    });

    it('if kind = white should return white styles', () => {
      const result = {
        button: [buttonStyles.default, buttonStyles.container, buttonStyles.buttonWhite],
        text: [buttonStyles.textBlue],
        icon: [buttonStyles.iconContainer],
      };
      expect(getButtonStyle(ButtonKind.WHITE)).toEqual(result);
    });

    it('if kind = disabled should return disabled styles', () => {
      const result = {
        button: [buttonStyles.default, buttonStyles.container, buttonStyles.buttonGrey],
        text: [buttonStyles.textWhite],
        icon: [buttonStyles.iconContainer],
      };
      expect(getButtonStyle(ButtonKind.DISABLED)).toEqual(result);
    });
  });
});

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { withKnobs } from '@storybook/addon-knobs';
import { action } from '@storybook/addon-actions';

import centered from '../../../storybook/decorators/centered';
import { ButtonBookAppointments } from './ButtonBookAppointments';

storiesOf('ButtonBookAppointments', module)
  .addDecorator(centered)
  .addDecorator(withKnobs)
  .add('button', () => (
    <ButtonBookAppointments
      openAppointments={action('navigate to')}
      isActive={true}
      onExpand={action('onExpanded')}
    />
  ));

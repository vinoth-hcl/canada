export interface IButtonBookAppointmentsProps {
  openAppointments: () => void;
  onExpand: () => void;
  isActive: boolean;
}

export const OPEN_BUTTON_RIGHT = 0;
export const CLOSE_BUTTON_RIGHT = 15;
export const DELAY = 5000;
export const DELAY_CLOSE_BOOK_APPOINTMENT_VIEW = 60000;

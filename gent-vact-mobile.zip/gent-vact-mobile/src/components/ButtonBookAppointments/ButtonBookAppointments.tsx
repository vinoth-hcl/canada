import React, { FunctionComponent, useCallback, useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { Button } from '../Button/Button';
import { ButtonKind } from '../Button/types';
import Book from '../../../assets/images/Book.svg';
import { TEXT_BOOK_APPOINTMENT, TEXT_STOP_BOOK_APPOINTMENT } from '../../constants/constants';
import { useAnimated, useTimeout } from '../../utilities/hooks';
import {
  CLOSE_BUTTON_RIGHT,
  DELAY,
  IButtonBookAppointmentsProps,
  OPEN_BUTTON_RIGHT,
} from './types';

export const ButtonBookAppointments: FunctionComponent<IButtonBookAppointmentsProps> = ({
  openAppointments,
  isActive,
  onExpand,
}) => {
  const [expanded, setExpanded] = useState<boolean>(false);
  const text = expanded ? (isActive ? TEXT_STOP_BOOK_APPOINTMENT : TEXT_BOOK_APPOINTMENT) : '';
  useAnimated();
  const handleReset = useTimeout(() => {
    setExpanded(false);
  }, DELAY);

  const right = expanded ? OPEN_BUTTON_RIGHT : CLOSE_BUTTON_RIGHT;

  const handlePress = useCallback(() => {
    if (expanded) {
      if (openAppointments) {
        openAppointments();
      }
      if (isActive) {
        handleReset.start();
        setExpanded(false);
      }
    } else {
      handleReset.start();
      setExpanded(true);
      onExpand();
    }
  }, [handleReset, openAppointments, expanded, isActive, onExpand]);

  return (
    <View style={StyleSheet.flatten([styles.container, { right }])}>
      <Button
        onPress={handlePress}
        text={text}
        kind={ButtonKind.RED}
        Icon={Book}
        activeOpacity={1}
        style={{
          container: StyleSheet.flatten([styles.buttonContainer, expanded && styles.open]),
          textStyle: styles.textContainer,
        }}
        testID={'BookAppointment'}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 15,
  },
  open: {
    width: 172,
    borderTopRightRadius: 0,
    borderBottomEndRadius: 0,
  },
  buttonContainer: {
    flexDirection: 'row',
    borderRadius: 32,
    minWidth: 0,
    width: 64,
    height: 64,
  },
  textContainer: {
    width: 85,
    marginLeft: 20,
  },
  close: {
    display: 'none',
  },
});

import React, { FunctionComponent, useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { get } from 'lodash';
import Quote from '../../../assets/images/Quote.svg';
import { GText } from '../GText/GText';
import { CHANGE_ANSWER } from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { useAnimated } from '../../utilities/hooks';
import { Separator } from '../Separator/Separator';
import { TextStyles } from '../GText/styles';
import { SurveyItem } from './types';

interface IAccordionCheckBoxViewProps {
  item: SurveyItem;
  onChangeAnswer?: () => void;
}

export const AccordionCheckBoxView: FunctionComponent<IAccordionCheckBoxViewProps> = ({
  item,
  onChangeAnswer = () => {},
}) => {
  const answer = item.answer;
  const checkBosAnswers = useMemo(() => {
    return Array.isArray(answer)
      ? answer.map((value) => {
          return get(value, 'text', '');
        })
      : [];
  }, [answer]);
  useAnimated();
  return (
    <>
      <View style={styles.question}>
        <Quote style={styles.quote} />
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
          children={item.title}
          style={{ flexWrap: 'wrap' }}
          testID={'Withdrawal_header'}
        />
      </View>
      {checkBosAnswers?.map((singleItem, index) => (
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_20_BOLD}
          children={singleItem}
          style={styles.checkBoxText}
          key={index}
          testID={`Withdrawal_answer_${index}`}
        />
      ))}
      <View style={styles.link}>
        <TouchableOpacity
          onPress={onChangeAnswer}
          accessible={true}
          accessibilityRole={'button'}
          accessibilityLabel={CHANGE_ANSWER}
        >
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
            style={styles.collapseText}
            children={CHANGE_ANSWER}
          />
        </TouchableOpacity>
      </View>
      <Separator style={styles.shortSeparator} />
    </>
  );
};

const styles = StyleSheet.create({
  quote: {
    marginTop: 5,
    marginRight: 8,
  },
  question: {
    flexDirection: 'row',
    marginLeft: 16,
    paddingRight: 34,
  },
  collapseText: {
    color: Colors.newBlue,
    textDecorationLine: 'underline',
  },
  checkBoxText: {
    flexWrap: 'wrap',
    marginTop: 16,
    marginLeft: 37,
    marginRight: 16,
  },
  link: {
    flexDirection: 'row',
    marginTop: 24,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingRight: 16,
    paddingBottom: 16,
  },
  shortSeparator: {
    marginLeft: 0,
    marginRight: 0,
  },
});

import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { TEXT_TASKS } from '../../constants/constants';
import { Colors } from '../../utilities/design';

interface IAmountElementProps {
  amount: number | undefined;
  showText?: boolean;
  color?: string;
  backgroundColor?: string;
}
export const AmountElement: FunctionComponent<IAmountElementProps> = ({
  amount,
  showText,
  color = 'black',
  backgroundColor = 'white',
}) => {
  return amount ? (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
      }}
    >
      <View style={[styles.amount, { backgroundColor }]}>
        <Text style={[styles.amountText, { color }]} numberOfLines={1}>
          {amount}
        </Text>
      </View>
      {showText ? <Text style={styles.tasksText}>{TEXT_TASKS}</Text> : null}
    </View>
  ) : null;
};

const styles = StyleSheet.create({
  amount: {
    height: 30,
    minWidth: 30,
    borderRadius: 15,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  amountText: {
    marginLeft: 5,
    marginRight: 5,
    fontSize: 20,
    lineHeight: 26,
  },
  tasksText: {
    fontSize: 15,
    lineHeight: 18,
    marginRight: 15,
    color: Colors.white,
  },
});

import React, { FunctionComponent, useCallback, useMemo, useState } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { useSelector } from 'react-redux';
import { GText } from '../GText/GText';
import { Separator } from '../Separator/Separator';
import { EXPAND_TEXT, RESPONSES_TEXT } from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { QUERY_TYPES } from '../../services/survey/types';
import { getSurveyType } from '../../services/survey/selector';
import { TextStyles } from '../GText/styles';
import { AccordionItem, SurveyItem } from './types';
import { AccordionRadioView } from './AccordionRadioView';
import { AccordionCheckBoxView } from './AccordionCheckBoxView';

const getAccordionView = ({
  item,
  idx,
  callBack,
}: {
  item: SurveyItem;
  idx: number;
  callBack: () => void;
}) => {
  switch (item.type) {
    case QUERY_TYPES.RATING:
      return <AccordionRadioView item={item} key={idx} onChangeAnswer={callBack} />;
    case QUERY_TYPES.CHECKBOX:
      return <AccordionCheckBoxView item={item} key={idx} onChangeAnswer={callBack} />;
    default:
      return null;
  }
};

interface IAccordionItemViewProps {
  page: AccordionItem;
  expanded?: boolean;
  onPressExpand: (index: number, value: boolean) => void;
  index: number;
  onChangeAnswer: (answer: string) => void;
}

export const AccordionItemView: FunctionComponent<IAccordionItemViewProps> = ({
  page,
  expanded = false,
  onPressExpand,
  index,
  onChangeAnswer,
}) => {
  const [isExpanded, setExpanded] = useState(expanded);
  const questionsCount = useMemo(() => page.questions.length, [page.questions.length]);
  const questions = useMemo(() => page.questions, [page.questions]);
  const onExpand = useCallback(() => {
    onPressExpand(index, !isExpanded);
    setExpanded(!isExpanded);
  }, [isExpanded, onPressExpand, index]);
  const surveyType = useSelector(getSurveyType);
  const postVisitSurvey = surveyType === 'POST_VISIT_SURVEY';

  return (
    <>
      {postVisitSurvey ? null : (
        <View style={styles.itemContainer}>
          <GText textStyle={TextStyles.SOURCE_SANS_16_24_BOLD} children={page.title} />
          <View style={styles.count}>
            <GText
              textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
              style={styles.countText}
            >{`${questionsCount} ${
              questionsCount < 2 ? RESPONSES_TEXT[0] : RESPONSES_TEXT[1]
            }`}</GText>
            <TouchableOpacity onPress={onExpand}>
              <GText textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL} style={styles.collapseText}>
                {isExpanded ? EXPAND_TEXT[0] : EXPAND_TEXT[1]}
              </GText>
            </TouchableOpacity>
          </View>
        </View>
      )}
      {!isExpanded && !postVisitSurvey ? (
        <Separator style={styles.separator} />
      ) : (
        <View style={postVisitSurvey ? styles.container : null}>
          {questions.map((item, idx) => {
            return getAccordionView({ item, idx, callBack: onChangeAnswer(item.name) });
          })}
        </View>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    justifyContent: 'space-between',
    minHeight: 48,
    backgroundColor: Colors.white,
    paddingLeft: 16,
    paddingRight: 16,
    paddingTop: 24,
  },
  count: {
    width: '100%',
    marginTop: 11,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  countText: {
    color: Colors.greenDarker,
  },
  collapseText: { color: Colors.newBlue, textDecorationLine: 'underline' },
  separator: { marginLeft: 0, marginRight: 0 },
  container: { paddingTop: 24 },
});

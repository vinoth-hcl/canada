import { StyleSheet, View } from 'react-native';
import React, { FunctionComponent, ReactElement } from 'react';

import { TEXT_NO_ITEMS } from '../../constants/constants';
import { useAnimated } from '../../utilities/hooks';
import { AccordionPlaceholder } from './AccordionPlaceholder';

interface ShowAccordionItemContentProps {
  isActive: boolean;
  children?: ReactElement;
  backgroundColor: string;
}
export const ShowAccordionItemContent: FunctionComponent<ShowAccordionItemContentProps> = ({
  isActive,
  children,
  backgroundColor,
}) => {
  useAnimated();
  const viewItem = children ? children : <AccordionPlaceholder text={TEXT_NO_ITEMS} />;
  return (
    <View style={[styles.itemContent, { backgroundColor }, !isActive && { height: 0.0001 }]}>
      {viewItem}
    </View>
  );
};

const styles = StyleSheet.create({
  itemContent: {
    marginBottom: 15,
    overflow: 'hidden',
  },
});

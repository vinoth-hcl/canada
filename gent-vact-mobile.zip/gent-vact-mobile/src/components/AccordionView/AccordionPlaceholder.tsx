import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

interface IAccordionPlaceholderProps {
  text: string;
}

export const AccordionPlaceholder: FunctionComponent<IAccordionPlaceholderProps> = ({ text }) => {
  return (
    <View style={styles.placeholder}>
      <Text style={styles.text}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  placeholder: {
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    height: 48,
  },
  text: { fontSize: 24, lineHeight: 28, marginLeft: 15 },
});

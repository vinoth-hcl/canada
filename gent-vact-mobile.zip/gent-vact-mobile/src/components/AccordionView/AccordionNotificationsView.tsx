import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, TouchableOpacity } from 'react-native';
import { Colors } from '../../utilities/design';
import { AmountElement } from './AmountElement';
import { ShowAccordionItemContent } from './ShowAccordionItemContent';
import { AccordionItem } from './types';

interface IAccordionNotificationsViewProps {
  isActive: boolean;
  item: AccordionItem;
  changeActiveItem: () => void;
}
export const AccordionNotificationsView: FunctionComponent<IAccordionNotificationsViewProps> = ({
  isActive,
  item,
  changeActiveItem,
}) => {
  return (
    <>
      <TouchableOpacity
        onPress={changeActiveItem}
        style={[styles.itemContainer, isActive && styles.activeContainer]}
        activeOpacity={0.9}
        delayPressIn={0}
      >
        <Text style={[styles.text, styles.notificationsText]}>{item.title}</Text>
        <AmountElement amount={item.amount} color={Colors.secondary} />
      </TouchableOpacity>
      <ShowAccordionItemContent
        children={item.children}
        isActive={isActive}
        backgroundColor={Colors.secondaryLightest}
      />
    </>
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 48,
    backgroundColor: Colors.secondary,
    marginBottom: 15,
  },
  activeContainer: {
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    marginBottom: 0,
  },
  text: { fontSize: 30, lineHeight: 41, marginLeft: 15 },
  notificationsText: { color: 'white' },
});

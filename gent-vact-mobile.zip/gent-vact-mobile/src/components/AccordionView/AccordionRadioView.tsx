import React, { FunctionComponent } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { get } from 'lodash';
import Quote from '../../../assets/images/Quote.svg';
import { GText } from '../GText/GText';
import { CHANGE_ANSWER, IS_OS_WEB } from '../../constants/constants';
import { Separator } from '../Separator/Separator';
import { Colors } from '../../utilities/design';
import { useAnimated } from '../../utilities/hooks';
import { getIcon } from '../../scenes/Survey/Survey.utils';
import { TextStyles } from '../GText/styles';
import { SurveyItem } from './types';

interface IAccordionRadioViewProps {
  item: SurveyItem;
  onChangeAnswer?: () => void;
}

export const AccordionRadioView: FunctionComponent<IAccordionRadioViewProps> = ({
  item,
  onChangeAnswer = () => {},
}) => {
  const text = get(item, ['answer', 'text'], '');
  const value = get(item, ['answer', 'value'], '');
  const title = get(item, ['title'], '');
  const Icon = getIcon(value);

  useAnimated();
  return (
    <>
      <View style={styles.question}>
        <Quote style={styles.quote} />
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
          children={title}
          style={{ flexWrap: 'wrap' }}
        />
      </View>
      <View style={styles.iconView}>
        <View style={styles.horizontal}>
          {Icon && <Icon style={styles.icon} />}
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_20_BOLD}
            style={styles.iconText}
            children={text}
          />
        </View>
        <TouchableOpacity onPress={onChangeAnswer}>
          <GText
            textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
            style={styles.collapseText}
            children={CHANGE_ANSWER}
          />
        </TouchableOpacity>
      </View>
      <Separator style={styles.shortSeparator} />
    </>
  );
};

const styles = StyleSheet.create({
  quote: { marginTop: 5, marginRight: 8 },
  iconView: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 16,
    marginBottom: 24,
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 16,
    paddingLeft: IS_OS_WEB ? 16 : 0,
  },
  iconText: {
    color: Colors.greyDark,
    marginLeft: 16,
  },
  icon: {
    marginLeft: 37,
    width: 32,
    height: 32,
  },
  horizontal: { flexDirection: 'row', alignItems: 'center' },
  question: {
    flexDirection: 'row',
    marginLeft: 16,
    paddingRight: 34,
  },
  collapseText: { color: Colors.newBlue, textDecorationLine: 'underline' },
  shortSeparator: { marginLeft: 34 },
});

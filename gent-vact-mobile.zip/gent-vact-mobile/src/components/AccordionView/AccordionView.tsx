import React, { FunctionComponent, useCallback, useEffect, useRef } from 'react';
import { FlatList } from 'react-native';
import { AccordionItem } from './types';
import { AccordionItemView } from './AccordionItemView';

interface IAccordionViewProps {
  accordionItems: AccordionItem[];
  expanded?: { [key: number]: boolean };
  scrollTo?: number;
  onExpand?: (index: number, value: boolean) => void;
  onScroll?: (e: any) => void;
  onChangeAnswer: (answer: string) => void;
}

export const AccordionView: FunctionComponent<IAccordionViewProps> = ({
  accordionItems,
  expanded = [],
  onExpand = () => {},
  onScroll = () => {},
  onChangeAnswer = () => {},
  scrollTo = 0,
}) => {
  const flatlist = useRef(null);

  useEffect(() => {
    setTimeout(() => {
      flatlist?.current?.scrollToOffset({ offset: scrollTo, animated: false });
    }, 300);
  }, [scrollTo]);

  const renderItem = useCallback(
    ({ item, index }) => {
      return (
        <AccordionItemView
          page={item}
          expanded={expanded[index]}
          onPressExpand={onExpand}
          index={index}
          onChangeAnswer={onChangeAnswer}
        />
      );
    },
    [expanded, onExpand, onChangeAnswer],
  );

  const keyExtractor = useCallback(
    (item: AccordionItem, index: number) => `${item.title}_${index}`,
    [],
  );

  return (
    <FlatList
      ref={flatlist}
      scrollEventThrottle={5}
      onScroll={onScroll}
      data={accordionItems}
      keyExtractor={keyExtractor}
      renderItem={renderItem}
      showsVerticalScrollIndicator={false}
    />
  );
};

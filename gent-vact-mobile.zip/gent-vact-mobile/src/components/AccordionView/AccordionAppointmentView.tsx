import { StyleSheet, Text, View } from 'react-native';
import React, { FunctionComponent } from 'react';
import { Colors } from '../../utilities/design';
import { AccordionItem } from './types';

interface IAccordionAppointmentViewProps {
  isActive: boolean;
  item: AccordionItem;
}
export const AccordionAppointmentView: FunctionComponent<IAccordionAppointmentViewProps> = ({
  isActive,
  item,
}) => {
  return (
    <View style={styles.appointmentContainer}>
      <Text style={[styles.text, isActive && styles.activeText]}>{item.title}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  appointmentContainer: {
    height: 163,
    backgroundColor: Colors.mint,
    borderRadius: 6,
    marginBottom: 15,
    justifyContent: 'center',
  },
  text: { fontSize: 24, lineHeight: 28, marginLeft: 15 },
  activeText: { fontWeight: 'normal' },
});

import { QUERY_TYPES } from '../../services/survey/types';

export type SurveyItem = {
  name: string;
  title: string;
  type: QUERY_TYPES;
  answer: string | number[];
  rateValues: any[];
};

export type AccordionItem = {
  name: string;
  title: string;
  questions: SurveyItem[];
};

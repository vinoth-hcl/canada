import React from 'react';
import { Text } from 'react-native';
import { storiesOf } from '@storybook/react-native';
import centered from '../../../storybook/decorators/centered';
import { PlaceHolderView } from './PlaceholderView';

storiesOf('Placeholder', module)
  .addDecorator(centered)
  .add('default placeholder', () => <PlaceHolderView />)
  .add('placeholder with text', () => <PlaceHolderView text="SOME INFO" />)
  .add('placeholder with children', () => (
    <PlaceHolderView>
      <Text>Some children text</Text>
    </PlaceHolderView>
  ))
  .add('custom styled placeholder', () => (
    <PlaceHolderView
      style={{ container: { padding: 20 }, text: { color: 'red', fontSize: 50 } }}
      text="ERROR!"
    />
  ));

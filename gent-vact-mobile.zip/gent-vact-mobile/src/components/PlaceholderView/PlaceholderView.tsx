import React, { FunctionComponent, ReactElement } from 'react';
import { View, Text, StyleProp, ViewStyle, TextStyle, StyleSheet } from 'react-native';
import { Colors } from '../../utilities/design';
import { DEVICE_HEIGHT, TEXT_DEFAULT_PLACEHOLDER } from '../../constants/constants';

export interface PlaceholderViewProps {
  text?: string;
  style?: {
    container?: StyleProp<ViewStyle>;
    text?: StyleProp<TextStyle>;
  };
  children?: ReactElement;
}

export const PlaceHolderView: FunctionComponent<PlaceholderViewProps> = ({
  text = TEXT_DEFAULT_PLACEHOLDER,
  children = null,
  style,
}) => (
  <View style={[styles.container, style?.container]}>
    {text && <Text style={[styles.text, style?.text]}>{text}</Text>}
    {children}
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: 10,
    paddingRight: 10,
    height: DEVICE_HEIGHT - 150,
    backgroundColor: Colors.white,
  },
  text: {
    textAlign: 'center',
    color: Colors.warmGrey,
    fontSize: 30,
  },
});

import React, { FunctionComponent } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

import { testId } from '../../utilities/TestId';
import { GText } from '../GText/GText';
import { TextStyles } from '../GText/styles';
import { ButtonKind, IButtonProps } from './types';
import { defaultStyles, getButtonStyle } from './utils';

export const Button: FunctionComponent<IButtonProps> = ({
  text,
  style = {},
  onPress,
  disabled = false,
  activeOpacity = 0.6,
  kind = ButtonKind.DEFAULT,
  Icon,
  children,
  isShadow = false,
  testID = '',
  title = null,
  accessibleOptions = {},
}) => {
  const { container = {}, textStyle = {}, iconStyle = {}, iconContainerStyle = {} } = style;

  const styles = getButtonStyle(kind);

  const buttonStyles = StyleSheet.flatten([
    styles.button,
    isShadow && defaultStyles.shadow,
    container,
  ]);
  const textStyles = StyleSheet.flatten([styles.text, textStyle]);
  const iconContainer = StyleSheet.flatten([styles.icon, iconContainerStyle]);
  return (
    <TouchableOpacity
      activeOpacity={activeOpacity}
      onPress={disabled ? undefined : onPress}
      disabled={disabled}
      style={buttonStyles}
      {...testId(
        `ButtonContainer_${testID}`,
        `${title || text}`,
        accessibleOptions.role || 'button',
      )}
      accessibilityState={{ disabled: disabled, checked: accessibleOptions.checked }}
    >
      {Icon && (
        <View style={iconContainer} importantForAccessibility={'no-hide-descendants'}>
          <Icon style={StyleSheet.flatten(iconStyle)} {...testId(`Icon_${testID}`)} />
        </View>
      )}
      {!!text && (
        <GText
          textStyle={TextStyles.SOURCE_SANS_16_24_NORMAL}
          style={textStyles}
          testID={`Text_${testID}`}
          children={text}
          options={{ maxFontSizeMultiplier: accessibleOptions.maxFontSizeMultiplier }}
        />
      )}
      {children}
    </TouchableOpacity>
  );
};

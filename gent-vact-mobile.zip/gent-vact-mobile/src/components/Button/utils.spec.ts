import { defaultStyles, getButtonStyle } from './utils';
import { ButtonKind } from './types';

describe('Button utils tests', () => {
  describe('getButtonStyle test', () => {
    it('if kind = default should return default styles', () => {
      const result = {
        button: [defaultStyles.button],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
      expect(getButtonStyle(ButtonKind.DEFAULT, defaultStyles)).toEqual(result);
    });

    it('if kind = blue should return blue styles', () => {
      const result = {
        button: [defaultStyles.button, defaultStyles.buttonBlue],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
      expect(getButtonStyle(ButtonKind.BLUE, defaultStyles)).toEqual(result);
    });

    it('if kind = white should return white styles', () => {
      const result = {
        button: [defaultStyles.button, defaultStyles.buttonLightGray],
        text: [defaultStyles.text, defaultStyles.textBlue],
      };
      expect(getButtonStyle(ButtonKind.LIGHTGREY, defaultStyles)).toEqual(result);
    });

    it('if kind = grey should return grey styles', () => {
      const result = {
        button: [defaultStyles.button, defaultStyles.buttonGrey],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
      expect(getButtonStyle(ButtonKind.GREY, defaultStyles)).toEqual(result);
    });
  });
});

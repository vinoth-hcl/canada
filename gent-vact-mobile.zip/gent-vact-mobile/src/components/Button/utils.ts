import { StyleProp, StyleSheet, TextStyle, ViewStyle } from 'react-native';

import { Colors } from '../../utilities/design';
import { ButtonKind } from './types';

export const getButtonStyle = (
  kind: ButtonKind,
): {
  button: StyleProp<ViewStyle>;
  text: StyleProp<TextStyle>;
  icon?: StyleProp<TextStyle>;
} => {
  switch (kind) {
    case ButtonKind.RED: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonRed],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
    }
    case ButtonKind.CIRCLE_WHITE: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonCircleWhite],
        text: [defaultStyles.text, defaultStyles.textCircleWhite],
        icon: defaultStyles.iconContainer,
      };
    }
    case ButtonKind.PRIMARY: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonPrimary],
        text: [defaultStyles.text, defaultStyles.textPrimary],
      };
    }
    case ButtonKind.BLUE: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonBlue],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
    }
    case ButtonKind.BLACK: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonBlack],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
    }
    case ButtonKind.GREY: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonGrey],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
    }
    case ButtonKind.WHITE: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonWhite],
        text: [defaultStyles.text, defaultStyles.textBlack],
      };
    }
    case ButtonKind.LIGHTGREY: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonLightGray],
        text: [defaultStyles.text, defaultStyles.textBlue],
      };
    }
    case ButtonKind.TRANSPARENT_BLUE: {
      return {
        button: [defaultStyles.button],
        text: [defaultStyles.text, defaultStyles.textBlue],
      };
    }
    case ButtonKind.TRANSPARENT_BLACK: {
      return {
        button: [defaultStyles.button],
        text: [defaultStyles.text, defaultStyles.textBlack],
      };
    }
    case ButtonKind.LINK: {
      return {
        button: [defaultStyles.button, defaultStyles.buttonLink],
        text: [defaultStyles.text, defaultStyles.textLink],
      };
    }
    case ButtonKind.BORDERED_TRANSPARENT_BLACK: {
      return {
        button: [defaultStyles.button, defaultStyles.whiteBorder],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
    }
    case ButtonKind.MAIN_WHITE: {
      return {
        button: defaultStyles.newButton,
        text: defaultStyles.newText,
        icon: defaultStyles.newIcon,
      };
    }
    case ButtonKind.MAIN_BLUE: {
      return {
        button: [defaultStyles.newButton, { backgroundColor: Colors.newBlue }],
        text: [defaultStyles.newText, { color: Colors.white }],
        icon: defaultStyles.newIcon,
      };
    }
    case ButtonKind.MAIN_DISABLED: {
      return {
        button: [defaultStyles.newButton, { borderColor: Colors.greyLighter, elevation: 0 }],
        text: [defaultStyles.newText, { color: Colors.greyLight }],
        icon: defaultStyles.newIcon,
      };
    }
    case ButtonKind.MAIN_INVERT_DISABLED: {
      return {
        button: [defaultStyles.newButton, { backgroundColor: Colors.greyLight, elevation: 0 }],
        text: [defaultStyles.newText, { color: Colors.white }],
        icon: defaultStyles.newIcon,
      };
    }
    case ButtonKind.SUPPORT_ENABLE: {
      return {
        button: defaultStyles.buttonContainer,
        text: defaultStyles.buttonLabel,
        icon: defaultStyles.supportIconContainer,
      };
    }
    case ButtonKind.SUPPORT_DISABLE: {
      return {
        button: [defaultStyles.buttonContainer, defaultStyles.disabledColor],
        text: defaultStyles.buttonLabel,
        icon: defaultStyles.supportIconContainer,
      };
    }
    default: {
      return {
        button: [defaultStyles.button],
        text: [defaultStyles.text, defaultStyles.textWhite],
      };
    }
  }
};

export const defaultStyles = StyleSheet.create({
  disabledColor: { backgroundColor: Colors.white },
  buttonContainer: {
    flexDirection: 'row',
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.newBlue,
  },
  supportIconContainer: {
    marginRight: 12,
  },
  buttonLabel: {
    color: Colors.newBlue,
  },
  button: {
    minWidth: 70,
    minHeight: 43,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 6,
  },
  text: {
    fontSize: 14,
    lineHeight: 16,
    fontWeight: 'bold',
  },
  buttonWhite: {
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: Colors.black,
  },
  buttonLightGray: {
    backgroundColor: Colors.lightGrey,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: Colors.primary,
  },
  buttonGrey: {
    backgroundColor: Colors.grey,
  },
  buttonBlue: {
    backgroundColor: Colors.primary,
  },
  buttonBlack: {
    backgroundColor: Colors.black,
  },
  buttonRed: {
    backgroundColor: Colors.secondary,
  },
  buttonCircleWhite: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: 24,
  },
  buttonLink: {
    minHeight: 0,
  },
  textLink: {
    textDecorationLine: 'underline',
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 20,
    color: Colors.linkDefault,
  },
  textCircleWhite: {
    color: Colors.black,
    marginRight: 20,
  },
  textBlue: {
    color: Colors.primary,
  },
  textBlack: {
    color: Colors.black,
  },
  textWhite: {
    color: Colors.white,
  },
  buttonPrimary: {
    backgroundColor: Colors.primary,
    borderRadius: 6,
  },
  textPrimary: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 17,
    lineHeight: 17,
    color: 'white',
  },
  whiteBorder: {
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: Colors.white,
  },
  iconContainer: {
    width: 32,
    height: 32,
    backgroundColor: Colors.gold,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
    marginRight: 8,
    marginTop: 8,
    marginBottom: 8,
  },
  shadow: {
    shadowColor: Colors.black,
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,

    elevation: 12,
  },
  newButton: {
    height: 48,
    borderTopStartRadius: 24,
    borderTopEndRadius: 24,
    borderBottomStartRadius: 24,
    borderBottomEndRadius: 24,
    marginTop: 8,
    marginBottom: 8,
    backgroundColor: Colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    elevation: 12,
    shadowColor: 'rgba(0, 0, 0, 0.2)',
  },
  newText: {
    fontWeight: '600',
    fontSize: 16,
    lineHeight: 20,
    color: Colors.newBlue,
  },
  newIcon: {
    marginRight: 12,
  },
});

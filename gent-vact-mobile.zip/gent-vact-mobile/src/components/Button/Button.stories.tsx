import React from 'react';
import { StyleSheet, View } from 'react-native';
import { storiesOf } from '@storybook/react-native';
import { boolean, text, withKnobs } from '@storybook/addon-knobs';
import { action } from '@storybook/addon-actions';

// import centered from '../../../storybook/decorators/centered';
import { Colors } from '../../utilities/design';
import CheckIcon from '../../../assets/images/Check/white.svg';
import Plus from '../../../assets/images/Plus.svg';
import { Button } from './Button';
import { ButtonKind } from './types';

storiesOf('Button', module)
  // .addDecorator(centered)
  .addDecorator(withKnobs)
  .add('button: kind = DEFAULT', () => (
    <View style={styles.container}>
      <Button
        text={text('text', 'press me')}
        onPress={action('onPress')}
        disabled={boolean('disabled', false)}
        kind={ButtonKind.DEFAULT}
      />
    </View>
  ))
  .add('button: kind = LINK', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.LINK}
    />
  ))
  .add('button: kind = RED', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.RED}
    />
  ))
  .add('button: kind = CIRCLE_WHITE', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.CIRCLE_WHITE}
      Icon={Plus}
    />
  ))
  .add('button: kind = CIRCLE_WHITE && isShadow', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.CIRCLE_WHITE}
      Icon={Plus}
      isShadow
    />
  ))
  .add('button: kind = TRANSPARENT_BLACK', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.TRANSPARENT_BLACK}
    />
  ))
  .add('button: kind = TRANSPARENT_BLUE', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.TRANSPARENT_BLUE}
    />
  ))
  .add('button: kind = WHITE', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.WHITE}
    />
  ))
  .add('button: kind = GREY', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.GREY}
    />
  ))
  .add('button: kind = BLUE', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.BLUE}
    />
  ))
  .add('button: kind = BLACK', () => (
    <Button
      text={text('text', 'press me')}
      onPress={action('onPress')}
      disabled={boolean('disabled', false)}
      kind={ButtonKind.BLACK}
    />
  ))
  .add('icon', () => (
    <Button
      text={text('text', 'press me')}
      style={{
        textStyle: styles.iconButtonText,
        container: styles.iconButton,
        iconStyle: styles.icon,
      }}
      Icon={CheckIcon}
      onPress={action('onPress')}
    />
  ));

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.grey,
    width: '100%',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconButton: {
    flexDirection: 'row',
    backgroundColor: Colors.black,
    padding: 10,
  },
  iconButtonText: {
    color: Colors.white,
  },
  icon: {
    marginRight: 10,
  },
});

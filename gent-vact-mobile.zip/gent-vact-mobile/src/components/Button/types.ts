import { GestureResponderEvent, StyleProp, TextStyle, ViewStyle } from 'react-native';

export interface IGradient {
  start?: { x: number; y: number };
  end?: { x: number; y: number };
  location?: number[];
  colors: string[];
  baseColor?: string;
}

export interface IButtonStyles {
  container?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  iconStyle?: StyleProp<ViewStyle>;
  iconContainerStyle?: StyleProp<ViewStyle>;
}

export interface IButtonProps {
  onPress?: (event: GestureResponderEvent) => void;
  style?: IButtonStyles;
  disabled?: boolean;
  activeOpacity?: number;
  text?: string | number;
  kind?: ButtonKind;
  Icon?: React.ElementType;
  isShadow?: boolean;
  testID?: string;
  title?: string | null;
  accessibleOptions?: any;
}

export enum ButtonKind {
  LIGHTGREY = 'LIGHTGREY',
  WHITE = 'WHITE',
  GREY = 'GREY',
  BLUE = 'BLUE',
  RED = 'RED',
  BLACK = 'BLACK',
  DEFAULT = 'DEFAULT',
  TRANSPARENT_BLUE = 'TRANSPARENT_BLUE',
  TRANSPARENT_BLACK = 'TRANSPARENT_BLACK',
  PRIMARY = 'PRIMARY',
  BORDERED_TRANSPARENT_BLACK = 'BORDERED_TRANSPARENT_BLACK',
  LINK = 'LINK',
  CIRCLE_WHITE = 'CIRCLE_WHITE',
  MAIN_WHITE = 'MAIN_WHITE',
  MAIN_BLUE = 'MAIN_BLUE',
  MAIN_DISABLED = 'MAIN_DISABLED',
  MAIN_INVERT_DISABLED = 'MAIN_INVERT_DISABLED',
  SUPPORT_ENABLE = 'SUPPORT_ENABLE',
  SUPPORT_DISABLE = 'SUPPORT_DISABLE',
}

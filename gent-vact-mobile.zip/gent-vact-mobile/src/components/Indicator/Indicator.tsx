import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { IIndicatorProps, IndicatorTypes } from './types';

export const Indicator: FunctionComponent<IIndicatorProps> = ({ style, type }) => (
  <View style={StyleSheet.flatten([styles.indicator, styles[type], style])} />
);

const styles = StyleSheet.create({
  indicator: {
    position: 'absolute',
  },
  [IndicatorTypes.VERTICAL]: {
    width: 10,
    top: 0,
    bottom: 0,
    left: 0,
  },
  [IndicatorTypes.HORIZONTAL]: {
    height: 10,
    left: 0,
    right: 0,
    bottom: 0,
  },
});

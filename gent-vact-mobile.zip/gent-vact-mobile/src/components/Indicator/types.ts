import { StyleProp, ViewStyle } from 'react-native';

export enum IndicatorTypes {
  VERTICAL = 'VERTICAL',
  HORIZONTAL = 'HORIZONTAL',
}

export interface IIndicatorProps {
  type: IndicatorTypes;
  style?: StyleProp<ViewStyle>;
}

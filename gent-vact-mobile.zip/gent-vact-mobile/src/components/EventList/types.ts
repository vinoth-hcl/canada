import { AlertDto } from '../../api/AlertDto';

export interface IEventsListProps {
  events: AlertDto[];
}

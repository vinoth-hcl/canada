import React, { FunctionComponent } from 'react';
import { StyleSheet, View } from 'react-native';
import { map } from 'lodash';

import { Event } from '../Event/Event';
import { IEventsListProps } from './types';

export const EventList: FunctionComponent<IEventsListProps> = ({ events }) => {
  return (
    <View style={styles.container}>
      {events.length > 0 &&
        map(events, (event, index) => {
          return <Event event={event} style={{ container: styles.eventStyle }} key={index} />;
        })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    width: 269,
  },
  eventStyle: {
    marginBottom: 10,
  },
});

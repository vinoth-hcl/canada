import React, { FunctionComponent } from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import { Colors } from '../../utilities/design';

interface ISeparatorProps {
  style?: StyleProp<ViewStyle>;
}

export const Separator: FunctionComponent<ISeparatorProps> = ({ style }) => (
  <View style={StyleSheet.flatten([styles.separator, style])} />
);

const styles = StyleSheet.create({
  separator: {
    borderBottomWidth: 1,
    marginLeft: 10,
    marginRight: 10,
    borderColor: Colors.separatorColor,
  },
});

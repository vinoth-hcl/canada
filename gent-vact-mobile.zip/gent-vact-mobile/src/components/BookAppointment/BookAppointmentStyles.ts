import { StyleSheet } from 'react-native';
import { Colors } from '../../utilities/design';

export const bookAppointmentStyles = StyleSheet.create({
  root: { backgroundColor: Colors.almostBlack, height: 375, marginBottom: 15 },
  title: {
    color: 'white',
    marginBottom: 25,
    marginLeft: 15,
    marginTop: 15,
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 24,
    lineHeight: 28,
  },
  subtitle: {
    color: 'white',
    marginBottom: 12,
    alignSelf: 'center',
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 18,
    lineHeight: 21,
  },
  buttons: {
    paddingLeft: 15,
    paddingRight: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    height: 109,
    marginBottom: 30,
  },
  okWindow: {
    width: 32,
    height: 32,
    marginLeft: 16,
    marginRight: 16,
    borderRadius: 16,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  dateTme: {
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 15,
    lineHeight: 18,
    color: 'white',
  },
});

export const buttonStyle = StyleSheet.create({
  container: {
    width: 93,
    height: 109,
  },
  textStyle: {
    fontStyle: 'normal',
    fontWeight: '500',
    fontSize: 15,
    lineHeight: 18,
    textAlign: 'center',
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
});

import React, { FunctionComponent, useCallback, useState } from 'react';
import { get } from 'lodash';
import { AppointmentSlotDto } from '../../api/AppointmentSlotDto';
import { useTimeout } from '../../utilities/hooks';
import { AppointmentType, IBookAppointmentSlotParams } from '../../services/appointments/types';
import { BookAppointmentStepOne } from './BookAppointmentStepOne';
import { BookAppointmentStepTwo } from './BookAppointmentStepTwo';

interface IBookAppointmentViewProps {
  timeSlots: AppointmentSlotDto[];
  onBook: (body: IBookAppointmentSlotParams) => void;
  onCall: () => void;
}

export const BookAppointmentView: FunctionComponent<IBookAppointmentViewProps> = ({
  timeSlots,
  onBook,
  onCall,
}) => {
  const [step, setStep] = useState(1);
  const [slot, setSlot] = useState<number | null>(null);

  const timeoutToStep2 = useTimeout(() => {
    setStep(2);
  }, 0);

  const timeoutToStep1 = useTimeout(() => {
    setStep(1);
  }, 0);

  const handlePress = useCallback(
    (index) => {
      return () => {
        setSlot(index);
        timeoutToStep2.start();
      };
    },
    [timeoutToStep2],
  );

  const handleBack = useCallback(() => {
    timeoutToStep1.start();
  }, [timeoutToStep1]);

  const dateTime = get(timeSlots, `${slot}.startTime`, '');

  const handleTelehealth = useCallback(() => {
    onBook({
      startTime: dateTime,
      appointmentType: AppointmentType.VIDEO,
      reason: 'Telehealth call',
    });
  }, [onBook, dateTime]);

  const handleMobile = useCallback(() => {
    onBook({ startTime: dateTime, appointmentType: AppointmentType.PHONE, reason: 'call' });
  }, [onBook, dateTime]);

  switch (step) {
    case 1:
      return (
        <BookAppointmentStepOne
          handlePress={handlePress}
          slot={slot}
          timeSlots={timeSlots}
          onCall={onCall}
        />
      );
    case 2:
      return (
        <BookAppointmentStepTwo
          handleBack={handleBack}
          handleTelehealth={handleTelehealth}
          handleMobile={handleMobile}
          dateTime={dateTime}
        />
      );
    default:
      return null;
  }
};

import React, { FunctionComponent, useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { bookAppointmentSlot, getAppointmentsFreeSlots } from '../../services/appointments/actions';
import { getAppointmentsFreeSlotsSelector } from '../../services/appointments/selector';
import { IBookAppointmentSlotParams } from '../../services/appointments/types';
import { BookAppointmentView } from './BookAppointmentView';

interface IBookAppointmentProps {
  handleClose: () => void;
}
export const BookAppointment: FunctionComponent<IBookAppointmentProps> = ({ handleClose }) => {
  const dispatch = useDispatch();
  const handleBook = useCallback(
    (body: IBookAppointmentSlotParams) => {
      dispatch(bookAppointmentSlot(body));
      handleClose && handleClose();
    },
    [dispatch, handleClose],
  );
  const handleCall = useCallback(() => {
    //TODO implement call to clinic team
  }, []);

  useEffect(() => {
    dispatch(getAppointmentsFreeSlots());
  }, [dispatch]);
  const freeSlots = useSelector(getAppointmentsFreeSlotsSelector);

  return <BookAppointmentView timeSlots={freeSlots} onBook={handleBook} onCall={handleCall} />;
};

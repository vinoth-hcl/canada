import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import dayjs from 'dayjs';

import {
  TEXT_BOOK_STANDARD_APPOINTMENT,
  TEXT_CALL_VA_FACILITY,
  TEXT_CANT_JOIN,
  TEXT_NO_FREE_SLOTS,
  TEXT_SELECT_ONE_OPTION,
} from '../../constants/constants';
import { Button } from '../Button/Button';
import { ButtonKind } from '../Button/types';
import DayAppointmentBlack from '../../../assets/images/DayAppointment_black.svg';
import DayAppointment from '../../../assets/images/DayAppointment.svg';
import { AppointmentSlotDto } from '../../api/AppointmentSlotDto';
import { PlaceHolderView } from '../PlaceholderView/PlaceholderView';
import { testId } from '../../utilities/TestId';
import { FORMAT_TIME_24_ENABLED } from '../../utilities/config';
import { buttonStyle, bookAppointmentStyles } from './BookAppointmentStyles';

const FORMAT_DATE = FORMAT_TIME_24_ENABLED ? 'MMMM D HH:mm' : 'MMMM D hh:mm A';
interface IBookAppointmentStepOneProps {
  timeSlots: AppointmentSlotDto[];
  slot: number | null;
  handlePress: (index: number) => () => void;
  onCall: () => void;
}

export const BookAppointmentStepOne: FunctionComponent<IBookAppointmentStepOneProps> = ({
  timeSlots,
  handlePress,
  slot,
  onCall,
}) => {
  return (
    <View style={bookAppointmentStyles.root}>
      <Text style={bookAppointmentStyles.title}>{TEXT_BOOK_STANDARD_APPOINTMENT}</Text>
      <Text style={bookAppointmentStyles.subtitle}>{TEXT_SELECT_ONE_OPTION}</Text>
      <View style={bookAppointmentStyles.buttons}>
        {timeSlots.length > 0 ? (
          timeSlots.map((time, index) => {
            return (
              <Button
                style={buttonStyle}
                kind={slot === index ? ButtonKind.WHITE : ButtonKind.BORDERED_TRANSPARENT_BLACK}
                text={dayjs(time.startTime).format(FORMAT_DATE)}
                onPress={handlePress(index)}
                Icon={slot === index ? DayAppointmentBlack : DayAppointment}
                key={index}
                testID={`BookButton_${index}`}
              />
            );
          })
        ) : (
          <PlaceHolderView
            text={TEXT_NO_FREE_SLOTS}
            style={{ container: longButtonStyle.placeHolder }}
          />
        )}
      </View>
      <Text style={bookAppointmentStyles.subtitle} {...testId('CantJoin')}>
        {TEXT_CANT_JOIN}
      </Text>
      <Button
        style={longButtonStyle}
        kind={ButtonKind.WHITE}
        text={TEXT_CALL_VA_FACILITY}
        onPress={onCall}
        testID={'CallVaFacility'}
      />
    </View>
  );
};

const longButtonStyle = StyleSheet.create({
  container: {
    marginLeft: 15,
    marginRight: 15,
    height: 40,
  },
  textStyle: {
    fontStyle: 'normal',
    fontWeight: '500',
    fontSize: 15,
    lineHeight: 18,
    textAlign: 'center',
  },
  iconStyle: {},
  placeHolder: {
    height: '100%',
  },
});

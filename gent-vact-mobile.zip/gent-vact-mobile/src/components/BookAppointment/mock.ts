import { AppointmentSlotDto } from '../../api/AppointmentSlotDto';

export const mockData: AppointmentSlotDto[] = [
  { startTime: '2020-09-03T09:00:00-05:00', endTime: '2020-09-03T10:00:00-05:00' },
  { startTime: '2020-10-03T09:00:00-05:00', endTime: '2020-10-03T10:00:00-05:00' },
  { startTime: '2020-09-06T09:00:00-05:00', endTime: '2020-09-06T10:00:00-05:00' },
];

import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import dayjs from 'dayjs';

import Feather from '../../app/Feather';
import {
  TEXT_BOOK_STANDARD_APPOINTMENT,
  TEXT_PHONE_CALL,
  TEXT_SELECT_PREFERRED_TYPE,
  TEXT_START_AGAIN,
  TEXT_VIDEO_CALL,
} from '../../constants/constants';
import { Colors } from '../../utilities/design';
import { Button } from '../Button/Button';
import { ButtonKind } from '../Button/types';
import Camera from '../../../assets/images/Camera.svg';
import Mobile from '../../../assets/images/Mobile.svg';
import { TextLink } from '../TextLink/TextLink';
import { FORMAT_TIME_24_ENABLED } from '../../utilities/config';
import { bookAppointmentStyles, buttonStyle } from './BookAppointmentStyles';

const FORMAT_DATE = FORMAT_TIME_24_ENABLED
  ? 'dddd, MMMM D YYYY HH:mm'
  : 'dddd, MMMM D YYYY hh:mm A';

interface IBookAppointmentStepTwoProps {
  dateTime: string;
  handleTelehealth: () => void;
  handleMobile: () => void;
  handleBack: () => void;
}

export const BookAppointmentStepTwo: FunctionComponent<IBookAppointmentStepTwoProps> = ({
  dateTime,
  handleTelehealth,
  handleMobile,
  handleBack,
}) => {
  return (
    <View style={bookAppointmentStyles.root}>
      <Text style={bookAppointmentStyles.title}>{TEXT_BOOK_STANDARD_APPOINTMENT}</Text>
      <View style={{ flexDirection: 'row', marginBottom: 30, height: 32, width: 180 }}>
        <View style={bookAppointmentStyles.okWindow}>
          <Feather name={'check'} size={22} color={Colors.mint} />
        </View>
        <Text style={bookAppointmentStyles.dateTme}>{dayjs(dateTime).format(FORMAT_DATE)}</Text>
      </View>
      <Text style={bookAppointmentStyles.subtitle}>{TEXT_SELECT_PREFERRED_TYPE}</Text>
      <View style={bookAppointmentStyles.buttons}>
        <Button
          style={{ ...buttonStyle, ...largeButtonStyle }}
          kind={ButtonKind.BORDERED_TRANSPARENT_BLACK}
          text={TEXT_VIDEO_CALL}
          onPress={handleTelehealth}
          Icon={Camera}
        />
        <Button
          style={{ ...buttonStyle, ...largeButtonStyle }}
          kind={ButtonKind.BORDERED_TRANSPARENT_BLACK}
          text={TEXT_PHONE_CALL}
          onPress={handleMobile}
          Icon={Mobile}
        />
      </View>
      <TextLink onPress={handleBack} text={TEXT_START_AGAIN} />
    </View>
  );
};
const largeButtonStyle = StyleSheet.create({
  container: {
    width: 146,
    height: 103,
    justifyContent: 'flex-end',
    paddingLeft: 30,
    paddingRight: 30,
    paddingBottom: 10,
  },
  iconStyle: {
    width: 50,
    height: 50,
    marginBottom: 15,
  },
});

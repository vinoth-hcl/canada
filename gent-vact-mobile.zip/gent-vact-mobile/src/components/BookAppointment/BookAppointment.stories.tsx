import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action } from '@storybook/addon-actions';

import centered from '../../../storybook/decorators/centered';
import { BookAppointmentView } from './BookAppointmentView';
import { mockData } from './mock';
import { BookAppointmentStepOne } from './BookAppointmentStepOne';
import { BookAppointmentStepTwo } from './BookAppointmentStepTwo';

storiesOf('BookAppointmentView', module)
  .addDecorator(centered)
  .add('View', () => (
    <BookAppointmentView timeSlots={mockData} onBook={action('onBook')} onCall={action('onCall')} />
  ))
  .add('StepOne: no active slot', () => {
    const handlePress = (num: number) => () => {
      action(`onPress: ${num}`);
    };
    return (
      <BookAppointmentStepOne
        timeSlots={mockData}
        handlePress={handlePress}
        slot={null}
        onCall={action('onCall')}
      />
    );
  })
  .add('StepOne: slot 1', () => {
    const handlePress = (num: number) => () => {
      action(`onPress: ${num}`);
    };
    return (
      <BookAppointmentStepOne
        timeSlots={mockData}
        handlePress={handlePress}
        slot={0}
        onCall={action('onCall')}
      />
    );
  })
  .add('StepOne: slot 2', () => {
    const handlePress = (num: number) => () => {
      action(`onPress: ${num}`);
    };
    return (
      <BookAppointmentStepOne
        timeSlots={mockData}
        handlePress={handlePress}
        slot={1}
        onCall={action('onCall')}
      />
    );
  })
  .add('StepOne: slot 3', () => {
    const handlePress = (num: number) => () => {
      action(`onPress: ${num}`);
    };
    return (
      <BookAppointmentStepOne
        timeSlots={mockData}
        handlePress={handlePress}
        slot={2}
        onCall={action('onCall')}
      />
    );
  })
  .add('StepOne: no available slots', () => {
    const handlePress = (num: number) => () => {
      action(`onPress: ${num}`);
    };
    return (
      <BookAppointmentStepOne
        timeSlots={[]}
        handlePress={handlePress}
        slot={1}
        onCall={action('onCall')}
      />
    );
  })
  .add('StepTwo', () => (
    <BookAppointmentStepTwo
      handleBack={action('onPressBack')}
      handleTelehealth={action('onPressTelehealth')}
      handleMobile={action('onPressMobile')}
      dateTime={mockData[1].startTime}
    />
  ));

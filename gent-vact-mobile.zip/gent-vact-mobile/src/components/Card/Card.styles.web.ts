import { StyleSheet } from 'react-native';
import { merge } from 'lodash';
import { Colors } from '../../utilities/design';
import { Layout } from '../../style/layout';
import { Font } from '../../style/font';
import { IButtonProps } from '../Button/types';
import { BASIC_WEBLAYOUT_BLOCK_WIDTH } from '../../constants/constants';

export default StyleSheet.create({
  container: StyleSheet.flatten([Layout.containerWithPadding, { justifyContent: 'space-between' }]),
  header: {
    paddingTop: 44,
    paddingBottom: 44,
    marginBottom: 4,
    justifyContent: 'center',
    width: BASIC_WEBLAYOUT_BLOCK_WIDTH,
    alignSelf: 'center',
  },
  body: StyleSheet.flatten([
    Layout.containerWithPadding,
    {
      backgroundColor: Colors.primaryAltLightestAlt,
      paddingTop: 32,
      paddingBottom: 32,
      borderRadius: 24,
      flex: 0,
      width: BASIC_WEBLAYOUT_BLOCK_WIDTH,
      alignSelf: 'center',
    },
  ]),
  headerTitle: StyleSheet.flatten([
    Font.H1,
    Font.center,
    {
      lineHeight: 28.8,
      marginBottom: 16,
    },
  ]),
  bodyTitle: StyleSheet.flatten([
    Font.H3,
    {
      lineHeight: 24,
      marginBottom: 16,
    },
  ]),
  bodyTextContainer: {
    marginBottom: 16,
  },
  headerText: StyleSheet.flatten([
    Font.Primary,
    Font.center,
    {
      lineHeight: 24,
      marginBottom: 4,
      marginLeft: 16,
      marginRight: 16,
    },
  ]),
  bodyText: StyleSheet.flatten([
    Font.Primary,
    {
      lineHeight: 24,
      marginBottom: 8,
    },
  ]),
  separator: {
    backgroundColor: Colors.primary,
    height: 1,
    marginBottom: 24,
  },
  blockWithButton: {
    justifyContent: 'center',
    flex: 1,
  },
  backButton: {
    paddingTop: 8,
  },
});

const buttonStyle: IButtonProps['style'] = {
  container: {
    borderRadius: 24,
    height: 48,
    paddingTop: 12,
    paddingBottom: 12,
    paddingLeft: 16,
    paddingRight: 16,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
  iconContainerStyle: {
    marginRight: 12,
  },
  textStyle: StyleSheet.flatten([
    Font.Button,
    {
      lineHeight: 20,
    },
  ]),
};

export const cardButtonStyle = merge({}, buttonStyle, {
  container: {
    backgroundColor: Colors.newBlue,
  },
  textStyle: {
    color: Colors.white,
  },
});

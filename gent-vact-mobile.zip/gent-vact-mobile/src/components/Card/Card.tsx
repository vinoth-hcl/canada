import React, { FunctionComponent } from 'react';
import { View, Text } from 'react-native';
import { Button } from '../Button/Button';
import Notes from '../../../assets/images/Notes.svg';
import { BackButton } from '../../scenes/Options/components/BackButton';
import styles, { cardButtonStyle } from './Card.styles';

type TextBlockPropsType = {
  title: string;
  block?: string | Array<string>;
};

export const Card: FunctionComponent<{
  header: TextBlockPropsType;
  body: TextBlockPropsType;
  buttonLabel: string;
  buttonHandler(): void;
  onBackButtonPress(): void;
}> = ({ header, body, buttonLabel, buttonHandler, onBackButtonPress }) => {
  return (
    <View style={styles.container}>
      <View style={styles.backButton}>
        <BackButton onPress={onBackButtonPress} />
      </View>
      <View style={styles.header}>
        <Text
          style={styles.headerTitle}
          accessible={true}
          accessibilityLabel={header.title}
          accessibilityRole={'header'}
        >
          {header.title}
        </Text>
        {header.block && <Text style={styles.headerText}>{header.block}</Text>}
      </View>
      <View style={styles.body}>
        <Text style={styles.bodyTitle}>{body.title}</Text>
        {Array.isArray(body.block) && (
          <View style={styles.bodyTextContainer}>
            {body.block.map((block, index) => (
              <Text key={index} style={styles.bodyText}>
                {block}
              </Text>
            ))}
          </View>
        )}
        <View style={styles.separator} />
        <View style={styles.blockWithButton}>
          <Button text={buttonLabel} Icon={Notes} style={cardButtonStyle} onPress={buttonHandler} />
        </View>
      </View>
    </View>
  );
};

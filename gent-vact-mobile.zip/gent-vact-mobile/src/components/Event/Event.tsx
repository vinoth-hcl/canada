import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Colors } from '../../utilities/design';
import { getColor } from './utils';
import { IEventProps } from './types';

export const Event: FunctionComponent<IEventProps> = ({ event, style }) => {
  const backgroundColor = getColor(event.alertLevel);

  return (
    <View style={StyleSheet.flatten([styles.event, { backgroundColor }, style && style.container])}>
      <Text style={styles.textEventStyle} children={event.openComment} />
    </View>
  );
};

const styles = StyleSheet.create({
  event: {
    flex: 1,
    maxHeight: 115,
    justifyContent: 'center',
    alignItems: 'flex-start',
    borderRadius: 6,
    paddingLeft: 22,
    paddingRight: 22,
  },
  textStyle: {
    fontSize: 14,
    lineHeight: 16,
    fontWeight: 'normal',
    color: Colors.white,
  },
  textEventStyle: {
    fontSize: 20,
    lineHeight: 23,
    color: Colors.white,
    fontWeight: 'bold',
  },
});

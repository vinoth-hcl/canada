import { StyleProp, ViewStyle } from 'react-native';

import { AlertDto } from '../../api/AlertDto';

export interface IEventProps {
  style?: {
    container?: StyleProp<ViewStyle>;
  };
  event: AlertDto;
}

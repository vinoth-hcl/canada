import { Colors } from '../../utilities/design';
import { AlertLevel } from '../../services/patient/types';
import { getColor } from './utils';

describe('Sensors utils tests', () => {
  describe('getColor test', () => {
    it('should return active red', () => {
      expect(getColor(AlertLevel.CRITICAL)).toBe(Colors.red);
    });

    it('should return yellow', () => {
      expect(getColor(AlertLevel.MIDDLE)).toBe(Colors.yellow);
      expect(getColor(AlertLevel.LOW)).toBe(Colors.yellow);
    });
  });
});

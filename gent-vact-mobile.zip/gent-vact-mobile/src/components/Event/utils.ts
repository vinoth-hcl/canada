import { AlertLevel } from '../../services/patient/types';
import { Colors } from '../../utilities/design';

export function getColor(type: string): string {
  switch (type) {
    case AlertLevel.CRITICAL: {
      return Colors.red;
    }
    default: {
      return Colors.yellow;
    }
  }
}

import { StyleProp, TextStyle, ViewStyle } from 'react-native';
import { ToDoDto } from '../../api/ToDoDto';

export enum TODO_STATES {
  DONE = 'DONE',
  PLANNED = 'PLANNED',
  EXPIRED = 'EXPIRED',
}

export enum TODO_TYPES {
  TRIAL = 'TRIAL',
  STANDARD_CARE = 'STANDARD_CARE',
  NONE = 'NONE',
  ACTIVITY = 'ACTIVITY',
  MEDICATION = 'MEDICATION',
  SURVEY = 'SURVEY',
  APPOINTMENT = 'APPOINTMENT',
  APPOINTMENT_SLOTS = 'APPOINTMENT_SLOTS',
  SYNC_OURA_RING_REGULAR = 'SYNC_OURA_RING_REGULAR',
  SYNC_OURA_RING_IRREGULAR = 'SYNC_OURA_RING_IRREGULAR',
  POST_VISIT_SURVEY = 'POST_VISIT_SURVEY',
  PATIENT_EXIT_SURVEY = 'PATIENT_EXIT_SURVEY',
}

export enum TODO_ACTION_STATES {
  DONE = 'DONE',
  UNDONE = 'UNDONE',
}

export interface IToDoProps extends ToDoDto {
  isPending: boolean;
  onClick: (e: any) => void;
  onButtonClick: (e: any) => void;
}

export interface ICommonToDoProps extends IToDoProps {
  withButton?: boolean;
  withIndicator?: boolean;
  withLoadAnimation?: boolean;
  buttonProps?: {
    Icon?: React.ElementType;
    text: string;
    style?: {
      container?: StyleProp<ViewStyle>;
      text?: StyleProp<TextStyle>;
      icon?: StyleProp<ViewStyle>;
    };
  };
  indicatorProps?: {
    style?: StyleProp<ViewStyle>;
  };
  dateWarning?: string;
}

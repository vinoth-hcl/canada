import { FORMAT_TIME_24_ENABLED } from '../../utilities/config';
import { TODO_TYPES } from './types';

const BEFORE_TIME_FORMAT = FORMAT_TIME_24_ENABLED
  ? {
      sameDay: 'Before H:mm [today]',
      nextDay: 'Before H:mm [tomorrow]',
      nextWeek: 'Before H:mm dddd',
      lastDay: 'Before H:mm [yesterday]',
      lastWeek: 'Before H:mm [last] dddd',
      sameElse: 'Before H:mm MMMM DD, YYYY',
    }
  : {
      sameDay: 'Before h:mm A [today]',
      nextDay: 'Before h:mm A [tomorrow]',
      nextWeek: 'Before h:mm A dddd',
      lastDay: 'Before h:mm A [yesterday]',
      lastWeek: 'Before h:mm A [last] dddd',
      sameElse: 'Before h:mm A MMMM DD, YYYY',
    };

const EXACT_TIME_FORMAT = FORMAT_TIME_24_ENABLED
  ? {
      sameDay: '[today], H:mm',
      nextDay: '[tomorrow], H:mm',
      nextWeek: 'dddd, H:mm',
      lastDay: '[yesterday], H:mm',
      lastWeek: '[last] dddd, H:mm',
      sameElse: 'MMMM DD, YYYY H:mm',
    }
  : {
      sameDay: '[today], h:mm A',
      nextDay: '[tomorrow], h:mm A',
      nextWeek: 'dddd, h:mm A',
      lastDay: '[yesterday], h:mm A',
      lastWeek: '[last] dddd, h:mm A',
      sameElse: 'MMMM DD, YYYY h:mm A',
    };

export const CALENDAR_FORMAT = {
  [TODO_TYPES.STANDARD_CARE]: EXACT_TIME_FORMAT,
  [TODO_TYPES.TRIAL]: EXACT_TIME_FORMAT,

  [TODO_TYPES.NONE]: BEFORE_TIME_FORMAT,
  [TODO_TYPES.ACTIVITY]: BEFORE_TIME_FORMAT,
  [TODO_TYPES.APPOINTMENT]: BEFORE_TIME_FORMAT,
  [TODO_TYPES.MEDICATION]: BEFORE_TIME_FORMAT,
  [TODO_TYPES.SURVEY]: BEFORE_TIME_FORMAT,
};

export const BUTTON_BORDER_WIDTH = 2;

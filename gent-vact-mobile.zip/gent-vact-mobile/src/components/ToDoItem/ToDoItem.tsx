import { FunctionComponent, useRef } from 'react';
import dayjs from 'dayjs';
import calendar from 'dayjs/plugin/calendar';
import { IToDoProps, TODO_TYPES } from './types';
import { TrialToDo } from './specificToDoItems/TrialToDo';
import { SurveyToDo } from './specificToDoItems/SurveyToDo';
import { StandardCareToDo } from './specificToDoItems/StandardCareToDo';
import { SimpleToDo } from './specificToDoItems/SimpleToDo';
import { AppointmentToDo } from './specificToDoItems/AppointmentToDo';
import { AppointmentSlotsToDo } from './specificToDoItems/AppointmentSlotsToDo';

dayjs.extend(calendar);

export const ToDoItem: FunctionComponent<IToDoProps> = (props) => {
  const ToDos = useRef({
    [TODO_TYPES.TRIAL]: TrialToDo,
    [TODO_TYPES.NONE]: SimpleToDo,
    [TODO_TYPES.ACTIVITY]: SimpleToDo,
    [TODO_TYPES.APPOINTMENT]: AppointmentToDo,
    [TODO_TYPES.MEDICATION]: SimpleToDo,
    [TODO_TYPES.SURVEY]: SurveyToDo,
    [TODO_TYPES.STANDARD_CARE]: StandardCareToDo,
    [TODO_TYPES.APPOINTMENT_SLOTS]: AppointmentSlotsToDo,
    [TODO_TYPES.SYNC_OURA_RING_REGULAR]: SimpleToDo,
    [TODO_TYPES.SYNC_OURA_RING_IRREGULAR]: SimpleToDo,
    [TODO_TYPES.POST_VISIT_SURVEY]: SurveyToDo,
    [TODO_TYPES.PATIENT_EXIT_SURVEY]: SurveyToDo,
  });

  return ToDos.current[props.type](props);
};

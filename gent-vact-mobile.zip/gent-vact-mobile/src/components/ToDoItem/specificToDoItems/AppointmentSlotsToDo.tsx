import React, { FunctionComponent } from 'react';
import { IToDoProps } from '../types';
import { CommonToDo } from '../CommonToDo';
import { TODO_BUTTONS_TITLES } from '../../../constants/constants';

export const AppointmentSlotsToDo: FunctionComponent<IToDoProps> = (props) => {
  return (
    <CommonToDo
      buttonProps={{
        text: TODO_BUTTONS_TITLES.CHOOSE,
      }}
      {...props}
    />
  );
};

import React, { FunctionComponent } from 'react';
import { IToDoProps } from '../types';
import { CommonToDo } from '../CommonToDo';

export const SimpleToDo: FunctionComponent<IToDoProps> = (props) => {
  return <CommonToDo withLoadAnimation={true} {...props} />;
};

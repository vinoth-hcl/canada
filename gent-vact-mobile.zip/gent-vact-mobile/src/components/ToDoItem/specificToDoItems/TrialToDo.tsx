import React, { FunctionComponent, useState } from 'react';
import { StyleSheet } from 'react-native';
import { IToDoProps, TODO_STATES } from '../types';
import { useDateTimeout } from '../../../hooks/useDateTimeout';
import { CommonToDo } from '../CommonToDo';
import { Colors } from '../../../utilities/design';
import { TODO_BUTTONS_TITLES } from '../../../constants/constants';

export const TrialToDo: FunctionComponent<IToDoProps> = (props) => {
  const [isButtonVisible, setButtonVisibility] = useState(false);
  useDateTimeout({
    from: new Date(),
    to: new Date(props.when),
    action: () => setButtonVisibility(true),
    skip: props.state === TODO_STATES.DONE,
  });

  return (
    <CommonToDo
      withIndicator={true}
      indicatorProps={{ style: styles.trialIndicator }}
      withButton={isButtonVisible}
      buttonProps={{
        text: TODO_BUTTONS_TITLES.JOIN,
      }}
      {...props}
    />
  );
};

const styles = StyleSheet.create({
  trialIndicator: {
    backgroundColor: Colors.green,
  },
});

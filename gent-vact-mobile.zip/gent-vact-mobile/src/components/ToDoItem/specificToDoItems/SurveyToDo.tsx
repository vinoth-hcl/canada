import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet } from 'react-native';
import { IToDoProps } from '../types';
import { CommonToDo } from '../CommonToDo';
import { TEXT_OVERDUE_SURVEY, TODO_BUTTONS_TITLES } from '../../../constants/constants';
import BluePenIcon from '../../../../assets/images/Pen/blue.svg';
import { useRelativeTime } from '../../../hooks/useRelativeTime';
import { Colors } from '../../../utilities/design';

const ON_EXPIRE_CHECK_FREQUENCY = 10 * 1000;

export const SurveyToDo: FunctionComponent<IToDoProps> = (props) => {
  const compareDates = useCallback((targetDate) => new Date() > new Date(targetDate), []);
  const isExpired = useRelativeTime(props.when, compareDates, ON_EXPIRE_CHECK_FREQUENCY);

  return (
    <CommonToDo
      buttonProps={{
        Icon: BluePenIcon,
        text: TODO_BUTTONS_TITLES.FILL_SURVEY,
      }}
      {...props}
      dateWarning={props.state === 'EXPIRED' || isExpired ? TEXT_OVERDUE_SURVEY : ''}
      withIndicator={Boolean(isExpired)}
      indicatorProps={{
        style: styles.indicator,
      }}
      withLoadAnimation
    />
  );
};

const styles = StyleSheet.create({
  indicator: {
    backgroundColor: Colors.secondary,
  },
});

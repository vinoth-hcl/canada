import React, { FunctionComponent } from 'react';
import { IToDoProps } from '../types';
import { CommonToDo } from '../CommonToDo';

export const StandardCareToDo: FunctionComponent<IToDoProps> = (props) => {
  return <CommonToDo withButton={false} {...props} />;
};

import React, { FunctionComponent, useCallback } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import dayjs from 'dayjs';
import calendar from 'dayjs/plugin/calendar';
import { get } from 'lodash';
import { Colors } from '../../utilities/design';
import { Button } from '../Button/Button';
import BlueCheckIcon from '../../../assets/images/Check/blue.svg';
import { TEXT_SENDING, TODO_BUTTONS_TITLES } from '../../constants/constants';
import { useRelativeTime } from '../../hooks/useRelativeTime';
import { Indicator } from '../Indicator/Indicator';
import { IndicatorTypes } from '../Indicator/types';
import { LoadAnimation } from '../LoadAnimation/LoadAnimation';
import { ICommonToDoProps, TODO_STATES, TODO_TYPES } from './types';
import { BUTTON_BORDER_WIDTH, CALENDAR_FORMAT } from './constants';

dayjs.extend(calendar);

export const CommonToDo: FunctionComponent<ICommonToDoProps> = ({
  what = '',
  when = '',
  state: status = TODO_STATES.PLANNED,
  type = TODO_TYPES.NONE,
  isPending = false,
  withButton = true,
  withLoadAnimation = false,
  buttonProps = {
    Icon: BlueCheckIcon,
    text: TODO_BUTTONS_TITLES.DONE,
  },
  withIndicator = false,
  indicatorProps = {},
  dateWarning = '',
  onClick = () => {},
  onButtonClick = () => {},
}) => {
  const formatDate = useCallback(
    (timeToConvert: Date | string) => dayjs(timeToConvert).calendar(dayjs(), CALENDAR_FORMAT[type]),
    [type],
  );
  const formattedDeadLine = useRelativeTime(when, formatDate);
  const showIf = useCallback((condition: any, element: React.ReactElement) => {
    if (condition) {
      return element;
    }

    return null;
  }, []);

  return (
    <TouchableOpacity onPress={onClick}>
      <View style={[styles.container]}>
        {withIndicator && <Indicator type={IndicatorTypes.VERTICAL} {...indicatorProps} />}
        <View style={styles.infoContainer}>
          <View style={[styles.descContainer, styles.infoTaskContainer]}>
            <Text style={[styles.textCommon, styles.info, styles.bold]}>{what}</Text>
          </View>
          {showIf(
            when,
            <View>
              <Text style={[styles.textCommon, styles.info]}>
                {dateWarning || formattedDeadLine}
              </Text>
            </View>,
          )}
        </View>
        <View style={styles.buttonContainer}>
          {showIf(
            withButton,
            <Button
              style={{
                container: StyleSheet.flatten([
                  styles.button,
                  styles.whiteButton,
                  get(buttonProps, 'style.container', {}),
                ]),
                textStyle: StyleSheet.flatten([
                  styles.buttonText,
                  styles.whiteButtonText,
                  get(buttonProps, 'style.text', {}),
                ]),
                iconStyle: StyleSheet.flatten([styles.icon, get(buttonProps, 'style.icon', {})]),
              }}
              Icon={buttonProps?.Icon}
              text={buttonProps.text}
              onPress={onButtonClick}
            />,
          )}
        </View>
        {showIf(withLoadAnimation && isPending, <LoadAnimation text={TEXT_SENDING} />)}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: Colors.white,
    borderRadius: 6,
    paddingLeft: 25,
    paddingRight: 25,
    paddingTop: 20,
    paddingBottom: 20,
    position: 'relative',
  },
  infoContainer: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    flex: 0.55,
  },
  descContainer: {
    marginBottom: 10,
  },
  infoTaskContainer: {
    marginRight: 10,
  },
  buttonContainer: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    flex: 0.4,
  },
  textContainer: {
    fontSize: 16,
  },
  textCommon: {
    fontSize: 16,
    lineHeight: 20,
    color: Colors.black,
  },
  bold: {
    fontWeight: 'bold',
  },
  info: {
    flexWrap: 'wrap',
    flexShrink: 1,
  },
  infoHeader: {
    textTransform: 'uppercase',
    marginBottom: 10,
    fontWeight: 'bold',
  },
  button: {
    flexDirection: 'row',
    paddingLeft: 20,
    paddingRight: 20,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 24,
    borderWidth: BUTTON_BORDER_WIDTH,
    width: 135 - BUTTON_BORDER_WIDTH * 2,
    height: 40 - BUTTON_BORDER_WIDTH * 2,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 16,
    lineHeight: 24,
  },
  icon: {
    marginRight: 10,
  },
  whiteButton: {
    borderColor: Colors.primary,
    backgroundColor: Colors.white,
  },
  whiteButtonText: {
    color: Colors.primary,
  },
});

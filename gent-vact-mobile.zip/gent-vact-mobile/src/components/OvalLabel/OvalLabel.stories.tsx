import React from 'react';
import { storiesOf } from '@storybook/react-native';
import centered from '../../../storybook/decorators/centered';
import { Colors } from '../../utilities/design';
import { OvalLabel } from './OvalLabel';

storiesOf('OvalLabel', module)
  .addDecorator(centered)
  .add('View', () => (
    <OvalLabel text={'Any Text'} color={'white'} backgroundColor={Colors.green} width={68} />
  ));

import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

interface IOvalLabelProps {
  text: string;
  color: string;
  width: number;
  backgroundColor: string;
}
export const OvalLabel: FunctionComponent<IOvalLabelProps> = ({
  text,
  color,
  backgroundColor,
  width,
}) => {
  return (
    <View style={[styles.container, { backgroundColor, width }]}>
      <Text style={[styles.text, { color }]}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 14,
    lineHeight: 14,
    textTransform: 'uppercase',
  },
});

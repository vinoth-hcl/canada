import { useEffect } from 'react';

export interface IDateTimeoutProps {
  from: Date;
  to: Date;
  skip: boolean;
  action: () => any;
}

export function useDateTimeout({
  from = new Date(),
  to = new Date(),
  action = () => {},
  skip = false,
}: IDateTimeoutProps): void {
  useEffect(() => {
    if (skip) {
      action();

      return () => {};
    }

    const timeoutDuration = Math.abs(to.getTime() - from.getTime());
    let timeoutId: null | NodeJS.Timeout = null;

    timeoutId = setTimeout(action, timeoutDuration);

    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
    };
  });
}

import { useWindowDimensions } from 'react-native';

import { WEB_LANDSCAPE_BREAKPOINT } from '../constants/constants';

export function useIsPortrait() {
  const dimensions = useWindowDimensions();
  const isPortrait = dimensions.width < WEB_LANDSCAPE_BREAKPOINT;
  return isPortrait;
}

import { useState, useEffect, useRef, useCallback } from 'react';
import dayjs from 'dayjs';
import relativeTimePlugin from 'dayjs/plugin/relativeTime';

dayjs.extend(relativeTimePlugin);

const DEFAULT_FREQUENCY = 60000;

export function useRelativeTime(
  timeToConvert: string | Date,
  convertTime: (time: string | Date) => any,
  updateFrequency: number = DEFAULT_FREQUENCY,
): any {
  const timer: { current: NodeJS.Timeout | null } = useRef(null);
  const [relativeTime, setRelativeTime] = useState('');
  const updateRelativeTime = useCallback(() => {
    setRelativeTime(convertTime(timeToConvert));
  }, [timeToConvert, convertTime]);

  useEffect(() => {
    updateRelativeTime();
    timer.current = setInterval(updateRelativeTime, updateFrequency);

    return () => {
      if (timer.current) {
        clearInterval(timer.current);
        timer.current = null;
      }
    };
  }, [timeToConvert, updateFrequency, updateRelativeTime]);

  return relativeTime;
}

import { Dispatch } from 'redux';
import { useSelector } from 'react-redux';

import { isAuthenticatedSelector } from '../app/selectors';
import { appAuthState, appLoginSuccess, replaceRoute } from '../app/actions';
import { AppAuthState } from '../app/types';
import { getTokensSync } from '../services/authentication/getTokens.web';
import { setAuthTokens, setKeychain } from '../services/info/actions';
import { fetchPatientProfile } from '../services/patient/actions';
import { track } from '../services/metrics/actions';
import { METRIC_EVENTS } from '../services/metrics/types';
import { AUTH_ROUTES } from '../navigation/routes';
import { setTimezone } from '../services/options/actions';

export function useAuthenticated(dispatch: Dispatch) {
  const { access_token, refresh_token } = getTokensSync();
  const currentAuth = !!access_token && !!refresh_token;
  const isAuthenticated = useSelector(isAuthenticatedSelector);

  if (isAuthenticated && !currentAuth) {
    dispatch(appAuthState(AppAuthState.INITIAL));
  } else if (!isAuthenticated && currentAuth) {
    dispatch(setKeychain(access_token, refresh_token));
    dispatch(setAuthTokens(access_token, refresh_token));
    dispatch(
      fetchPatientProfile(
        [
          appAuthState(AppAuthState.AUTHENTICATED),
          setTimezone(),
          appLoginSuccess(),
          track(METRIC_EVENTS.LOGIN),
          replaceRoute(AUTH_ROUTES.MODAL_NAVIGATOR),
        ],
        replaceRoute(AUTH_ROUTES.FORBIDDEN),
        access_token,
      ),
    );
  }

  return currentAuth;
}

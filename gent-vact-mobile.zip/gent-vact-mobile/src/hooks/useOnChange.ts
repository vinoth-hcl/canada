import { useState, useEffect } from 'react';

export function useOnChange(value: any, func: (value: any) => void) {
  const [oldValue, setOldValue] = useState(value);
  useEffect(() => {
    if (value !== oldValue) {
      setOldValue(value);
      func(value);
    }
  }, [value, oldValue, func]);
}

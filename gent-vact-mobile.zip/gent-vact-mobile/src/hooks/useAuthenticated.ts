import { useSelector } from 'react-redux';
import { Dispatch } from 'redux';
import { isAuthenticatedSelector } from '../app/selectors';

export function useAuthenticated(dispatch: Dispatch) {
  return useSelector(isAuthenticatedSelector);
}

import { useNetInfo } from '@react-native-community/netinfo';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { isConnectNetwork } from '../app/actions';

export function useNetInfoConnection() {
  const [isConnect, setIsConnect] = useState<boolean>(false);
  const dispatch = useDispatch();

  const { isConnected } = useNetInfo();

  useEffect(() => {
    if (isConnected !== isConnect) {
      setIsConnect(isConnected);
      dispatch(isConnectNetwork(isConnected));
    }
  }, [dispatch, isConnected, isConnect]);
}

import { useEffect } from 'react';
import { StatusBar } from 'react-native';
import { OS_ANDROID } from '../constants/constants';

export const useStatusBar = (platform: string) => {
  useEffect(() => {
    if (platform === OS_ANDROID) {
      StatusBar.setBarStyle('light-content', true);
      StatusBar.setBackgroundColor('#000000');
    }
  }, [platform]);
};

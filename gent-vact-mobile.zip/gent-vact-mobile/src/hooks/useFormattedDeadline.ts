import { useState, useEffect, useRef, useCallback } from 'react';
import dayjs from 'dayjs';
import calendar from 'dayjs/plugin/calendar';
import { FORMAT_TIME_24_ENABLED } from '../utilities/config';

dayjs.extend(calendar);

const CALENDAR_PARAMS = FORMAT_TIME_24_ENABLED
  ? {
      sameDay: 'Before H:mm [today]', // The same day ( Today at 2:30 AM )
      nextDay: 'Before H:mm [tomorrow]', // The next day ( Tomorrow at 2:30 AM )
      nextWeek: 'Before H:mm dddd', // The next week ( Sunday at 2:30 AM )
      lastDay: 'Before H:mm [yesterday]', // The day before ( Yesterday at 2:30 AM )
      lastWeek: 'Before H:mm [last] dddd', // Last week ( Last Monday at 2:30 AM )
      sameElse: 'Before H:mm DD/MM/YYYY', // Everything else ( 7/10/2011 )
    }
  : {
      sameDay: 'Before h:mm A [today]', // The same day ( Today at 2:30 AM )
      nextDay: 'Before h:mm A [tomorrow]', // The next day ( Tomorrow at 2:30 AM )
      nextWeek: 'Before h:mm A dddd', // The next week ( Sunday at 2:30 AM )
      lastDay: 'Before h:mm A [yesterday]', // The day before ( Yesterday at 2:30 AM )
      lastWeek: 'Before h:mm A [last] dddd', // Last week ( Last Monday at 2:30 AM )
      sameElse: 'Before h:mm A DD/MM/YYYY', // Everything else ( 7/10/2011 )
    };

function getMStoNextDay() {
  const accuracy = 5000;
  const currentDate = new Date();
  const nextDayBeginDate = new Date().setHours(23, 59, 59, 999);

  return Math.abs(currentDate.getTime() - nextDayBeginDate) + accuracy;
}

function useFormattedDeadline(deadLineDate: Date | string): string {
  const timeoutId: { current: NodeJS.Timeout | null } = useRef(null);
  const [formattedDeadLine, setFormattedDeadLine] = useState('');

  const updateFormattedDeadline = useCallback(() => {
    setFormattedDeadLine(dayjs(deadLineDate).calendar(dayjs(), CALENDAR_PARAMS));
  }, [deadLineDate]);

  const startTimout = useCallback(() => {
    if (timeoutId.current) {
      clearTimeout(timeoutId.current);
    }

    const timeoutValue = getMStoNextDay();

    timeoutId.current = setTimeout(() => {
      updateFormattedDeadline();
      startTimout();
    }, timeoutValue);
  }, [updateFormattedDeadline]);

  useEffect(() => {
    updateFormattedDeadline();
    startTimout();

    return () => {
      if (timeoutId.current) {
        clearTimeout(timeoutId.current);
      }
    };
  }, [updateFormattedDeadline, startTimout]);

  return formattedDeadLine;
}

export default useFormattedDeadline;

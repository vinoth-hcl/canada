import { useCallback, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { Action } from 'redux';

const TAPS_DURATION = 2000;
const TAPS_COUNT = 5;

export function useMultiTap(action: Action) {
  const count = useRef(0);
  const timeoutId = useRef(0);
  const dispatch = useDispatch();
  return useCallback(() => {
    if (!timeoutId.current) {
      count.current = 1;
      timeoutId.current = setTimeout(() => {
        timeoutId.current = 0;
        count.current = 0;
      }, TAPS_DURATION);
    }
    if (count.current) {
      count.current++;
      if (count.current === TAPS_COUNT) {
        clearTimeout(timeoutId.current);
        timeoutId.current = 0;
        dispatch(action);
      }
    }
  }, [dispatch, action]);
}

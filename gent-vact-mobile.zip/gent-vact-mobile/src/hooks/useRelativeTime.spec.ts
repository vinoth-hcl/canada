import { renderHook, act } from '@testing-library/react-hooks';
import dayjs from 'dayjs';
import calendar from 'dayjs/plugin/calendar';
import relativeTimePlugin from 'dayjs/plugin/relativeTime';
import { TODO_TYPES } from '../components/ToDoItem/types';
import { CALENDAR_FORMAT } from '../components/ToDoItem/constants';
import { useRelativeTime } from './useRelativeTime';

dayjs.extend(calendar);

const TODAY = new Date(2020, 8, 8, 15, 30);

describe('test useRelativeTime hook', () => {
  it('should call injected function each minute and should call it immediately if we pass new props', () => {
    jest.useFakeTimers();

    const formatDate = jest.fn((timeToConvert: Date | string) =>
      dayjs(timeToConvert).calendar(dayjs(TODAY), CALENDAR_FORMAT[TODO_TYPES.NONE]),
    );

    const { result, rerender } = renderHook(
      ({ timeToConvert, convertFunc }) => useRelativeTime(timeToConvert, convertFunc),
      {
        initialProps: {
          timeToConvert: new Date(2020, 8, 8, 17, 30),
          convertFunc: formatDate,
        },
      },
    );

    expect(result.current).toEqual('Before 5:30 PM today');

    act(() => {
      jest.advanceTimersByTime(60000 * 10);
    });

    expect(formatDate).toBeCalledTimes(11);
    expect(result.current).toEqual('Before 5:30 PM today');

    rerender({ timeToConvert: new Date(2020, 8, 9, 17, 30), convertFunc: formatDate });

    expect(formatDate).toBeCalledTimes(12);
    expect(result.current).toEqual('Before 5:30 PM tomorrow');
  });

  describe('test different current dates', () => {
    const MOCK_DATE = new Date(2020, 8, 11, 15, 30);

    it.each`
      currentDate                      | calendarFormat                       | expected
      ${MOCK_DATE}                     | ${CALENDAR_FORMAT[TODO_TYPES.NONE]}  | ${'Before 3:30 PM today'}
      ${new Date(2020, 8, 12, 15, 30)} | ${CALENDAR_FORMAT[TODO_TYPES.NONE]}  | ${'Before 3:30 PM yesterday'}
      ${new Date(2020, 8, 10, 5, 20)}  | ${CALENDAR_FORMAT[TODO_TYPES.NONE]}  | ${'Before 3:30 PM tomorrow'}
      ${new Date(2020, 8, 11, 19, 30)} | ${CALENDAR_FORMAT[TODO_TYPES.NONE]}  | ${'Before 3:30 PM today'}
      ${new Date(2020, 8, 11, 8, 30)}  | ${CALENDAR_FORMAT[TODO_TYPES.NONE]}  | ${'Before 3:30 PM today'}
      ${new Date(2020, 8, 16, 15, 30)} | ${CALENDAR_FORMAT[TODO_TYPES.NONE]}  | ${'Before 3:30 PM last Friday'}
      ${new Date(2020, 8, 8, 15, 30)}  | ${CALENDAR_FORMAT[TODO_TYPES.NONE]}  | ${'Before 3:30 PM Friday'}
      ${new Date(2007, 8, 7, 18, 40)}  | ${CALENDAR_FORMAT[TODO_TYPES.NONE]}  | ${'Before 3:30 PM September 11, 2020'}
      ${new Date(2020, 8, 12, 15, 30)} | ${CALENDAR_FORMAT[TODO_TYPES.TRIAL]} | ${'yesterday, 3:30 PM'}
      ${new Date(2020, 8, 10, 5, 20)}  | ${CALENDAR_FORMAT[TODO_TYPES.TRIAL]} | ${'tomorrow, 3:30 PM'}
      ${new Date(2020, 8, 11, 19, 30)} | ${CALENDAR_FORMAT[TODO_TYPES.TRIAL]} | ${'today, 3:30 PM'}
      ${new Date(2020, 8, 11, 8, 30)}  | ${CALENDAR_FORMAT[TODO_TYPES.TRIAL]} | ${'today, 3:30 PM'}
      ${new Date(2020, 8, 16, 15, 30)} | ${CALENDAR_FORMAT[TODO_TYPES.TRIAL]} | ${'last Friday, 3:30 PM'}
      ${new Date(2020, 8, 8, 15, 30)}  | ${CALENDAR_FORMAT[TODO_TYPES.TRIAL]} | ${'Friday, 3:30 PM'}
      ${new Date(2007, 8, 7, 18, 40)}  | ${CALENDAR_FORMAT[TODO_TYPES.TRIAL]} | ${'September 11, 2020 3:30 PM'}
    `(
      'should return current relative time before the event',
      ({ currentDate, calendarFormat, expected }) => {
        const formatDate = jest.fn((timeToConvert: Date | string) =>
          dayjs(timeToConvert).calendar(dayjs(currentDate), calendarFormat),
        );

        const { result } = renderHook(() => useRelativeTime(MOCK_DATE, formatDate));

        expect(result.current).toEqual(expected);
      },
    );
  });

  describe('aaa', () => {
    dayjs.extend(relativeTimePlugin);

    const MOCK_DATE = new Date(2020, 8, 11, 15, 30, 25);

    it.each`
      currentDate                          | expected
      ${MOCK_DATE}                         | ${'a few seconds ago'}
      ${new Date(2020, 8, 11, 15, 30, 49)} | ${'a few seconds ago'}
      ${new Date(2020, 8, 11, 15, 30, 35)} | ${'a few seconds ago'}
      ${new Date(2020, 8, 11, 19, 35)}     | ${'4 hours ago'}
      ${new Date(2020, 8, 11, 15, 35, 58)} | ${'6 minutes ago'}
      ${new Date(2020, 8, 12, 15, 30)}     | ${'a day ago'}
      ${new Date(2020, 8, 13, 18, 22)}     | ${'2 days ago'}
      ${new Date(2027, 9, 7, 18, 40)}      | ${'7 years ago'}
    `('$value should be converted to $expected', ({ currentDate, expected }) => {
      const formatDate = jest.fn((timeToConvert) => dayjs(timeToConvert).from(currentDate));

      const { result } = renderHook(() => useRelativeTime(MOCK_DATE, formatDate));

      expect(result.current).toEqual(expected);
    });
  });
});

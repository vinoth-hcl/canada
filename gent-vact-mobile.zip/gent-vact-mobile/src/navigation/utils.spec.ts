import { checkCurrentRoute, getInitRoutNameModalNav } from './utils';
import { AUTH_ROUTES, MODAL_ROUTES, TAB_ROUTES } from './routes';

describe('Navigator utils tests', () => {
  describe('getInitRoutNameModalNav', () => {
    it('should return correct init route name', () => {
      expect(getInitRoutNameModalNav({ isTrialComplete: false, isShowStartPage: true })).toBe(
        MODAL_ROUTES.START_PAGE,
      );
      expect(getInitRoutNameModalNav({ isTrialComplete: true, isShowStartPage: true })).toBe(
        MODAL_ROUTES.EXIT_INSTRUCTIONS,
      );
      expect(getInitRoutNameModalNav({ isTrialComplete: false, isShowStartPage: false })).toBe(
        MODAL_ROUTES.TAB_NAVIGATOR,
      );
      expect(getInitRoutNameModalNav({ isTrialComplete: true, isShowStartPage: false })).toBe(
        MODAL_ROUTES.EXIT_INSTRUCTIONS,
      );
    });
  });

  describe('checkCurrentRoute', () => {
    it('should return true', () => {
      expect(checkCurrentRoute(AUTH_ROUTES.WELCOME)).toBeTruthy();
      expect(checkCurrentRoute(AUTH_ROUTES.LOGIN)).toBeTruthy();
      expect(checkCurrentRoute(AUTH_ROUTES.LOGOUT)).toBeTruthy();
      expect(checkCurrentRoute(TAB_ROUTES.DASHBOARD)).toBeTruthy();
      expect(checkCurrentRoute(MODAL_ROUTES.START_PAGE)).toBeTruthy();
      expect(checkCurrentRoute(MODAL_ROUTES.EXIT_INSTRUCTIONS)).toBeTruthy();
      expect(checkCurrentRoute(MODAL_ROUTES.LOADING)).toBeTruthy();
    });
    it('should return false', () => {
      expect(checkCurrentRoute(AUTH_ROUTES.FORBIDDEN)).toBeFalsy();
      expect(checkCurrentRoute(AUTH_ROUTES.SOMETHING_WENT_WRONG)).toBeFalsy();
      expect(checkCurrentRoute(TAB_ROUTES.APPOINTMENTS_MODAL_NAVIGATOR_LIST)).toBeFalsy();
      expect(checkCurrentRoute(TAB_ROUTES.OPTIONS)).toBeFalsy();
      expect(checkCurrentRoute(MODAL_ROUTES.SUPPORT_REQUEST)).toBeFalsy();
      expect(checkCurrentRoute(MODAL_ROUTES.SURVEY)).toBeFalsy();
    });
  });
});

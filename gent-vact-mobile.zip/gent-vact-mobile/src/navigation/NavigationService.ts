import { noop, get } from 'lodash';
import { StackActions, CommonActions } from '@react-navigation/native';

const emptyNavigator: any = {
  dispatch: noop,
};

let _navigator: any = emptyNavigator;

export function setTopLevelNavigator(navigatorRef: any) {
  _navigator = navigatorRef || emptyNavigator;
}

export function navigate(name: string, params?: { [key: string]: any }, key?: string) {
  _navigator.dispatch(
    CommonActions.navigate({
      name,
      params,
      key,
    }),
  );
}

export function replace(name: string, params?: { [key: string]: any }) {
  _navigator.dispatch(StackActions.replace(name, params));
}

export function back() {
  _navigator.dispatch(CommonActions.goBack());
}

export function getCurrentRouteName(nav: any = _navigator): any {
  return get(nav.getCurrentRoute(), 'name', '');
}

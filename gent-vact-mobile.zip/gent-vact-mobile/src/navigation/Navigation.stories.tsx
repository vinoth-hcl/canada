import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { StyleSheet, View } from 'react-native';

import IconHome from '../../assets/images/Home.svg';
import NewIconHome from '../../assets/images/NewHome.svg';
import { Colors } from '../utilities/design';
import centered from '../../storybook/decorators/centered';
import { Icon } from './Icon';
import { Label } from './Label';
import { LabelName } from './types';

storiesOf('Navigation', module)
  .addDecorator(centered)
  .add('Label', () => (
    <View style={styles.container}>
      <Label label={LabelName.HOME} />
    </View>
  ))
  .add('Icon', () => (
    <View style={styles.container}>
      <Icon
        children={<IconHome />}
        style={{ container: { backgroundColor: Colors.primaryDarkest } }}
      />
    </View>
  ))
  .add('Active: Icon + Label', () => (
    <View style={styles.container}>
      <Icon
        children={<NewIconHome />}
        style={{
          container: { borderColor: Colors.primary, shadowColor: Colors.primary },
          labelContainer: { color: Colors.primary },
          underlineContainer: { borderColor: Colors.primary },
        }}
        label={LabelName.HOME}
        underline={true}
      />
    </View>
  ))
  .add('Non Active: Icon + Label', () => (
    <View style={styles.container}>
      <Icon
        children={<NewIconHome />}
        style={{ container: { borderColor: 'transparent' } }}
        label={LabelName.HOME}
        underline={false}
      />
    </View>
  ));

const styles = StyleSheet.create({
  container: {
    width: 80,
    height: 65,
  },
});

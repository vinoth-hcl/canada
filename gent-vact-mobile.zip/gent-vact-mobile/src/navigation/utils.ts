import { AUTH_ROUTES, MODAL_ROUTES, TAB_ROUTES } from './routes';

export function getInitRoutNameModalNav({
  isShowStartPage,
  isTrialComplete,
  isTrialWithdraw,
}: {
  isTrialComplete: boolean;
  isShowStartPage: boolean;
  isTrialWithdraw: boolean;
}) {
  if (isTrialComplete || isTrialWithdraw) {
    return MODAL_ROUTES.EXIT_INSTRUCTIONS;
  }
  if (isShowStartPage) {
    return MODAL_ROUTES.START_PAGE;
  }
  return MODAL_ROUTES.TAB_NAVIGATOR;
}

export function checkCurrentRoute(routeName: string): boolean {
  switch (routeName) {
    case AUTH_ROUTES.WELCOME:
    case AUTH_ROUTES.LOGIN:
    case AUTH_ROUTES.LOGOUT:
    case TAB_ROUTES.DASHBOARD:
    case MODAL_ROUTES.START_PAGE:
    case MODAL_ROUTES.EXIT_INSTRUCTIONS:
    case MODAL_ROUTES.LOADING: {
      return true;
    }
    default: {
      return false;
    }
  }
}

import React from 'react';
import { map } from 'lodash';
import {
  BottomTabNavigationOptions,
  createBottomTabNavigator,
} from '@react-navigation/bottom-tabs';

import { BottomTabBarOptions } from '@react-navigation/bottom-tabs/lib/typescript/src/types';
import { Colors } from '../utilities/design';
import { Icon } from './Icon';
import { INavigatorTab } from './types';

export const getNavigationOptions = ({
  IconElement,
  IconElementActive,
  label,
  activeColor,
}: INavigatorTab): BottomTabNavigationOptions => {
  const tabBarIcon = (props: any) => {
    const { focused } = props;
    const borderColor = focused ? activeColor : 'transparent';
    const color = focused ? activeColor : Colors.greyDark;
    const renderIcon = focused ? <IconElementActive /> : <IconElement />;
    return (
      <Icon
        style={{
          container: { borderColor, shadowColor: activeColor },
          labelContainer: { color },
          underlineContainer: { borderColor: activeColor },
        }}
        children={renderIcon}
        label={label}
        underline={focused}
      />
    );
  };
  return {
    tabBarIcon,
    unmountOnBlur: true,
    tabBarAccessibilityLabel: label,
  };
};

export function TabNavigatorView(tabs: INavigatorTab[], config: BottomTabBarOptions) {
  const TabsNavigator = createBottomTabNavigator();

  return () => (
    <TabsNavigator.Navigator tabBarOptions={config}>
      {map(tabs, (tab: INavigatorTab, index: number) => (
        <TabsNavigator.Screen
          name={tab.route}
          component={tab.screen}
          options={getNavigationOptions(tab)}
          key={`${tab.route}_${index}`}
        />
      ))}
    </TabsNavigator.Navigator>
  );
}

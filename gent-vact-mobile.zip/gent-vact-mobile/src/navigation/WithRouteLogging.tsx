import React, { FunctionComponent, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useFocusEffect } from '@react-navigation/native';
import { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { logToggleTab, TCurrentTab } from '../services/navigation/actions';

export const WithRouteLogging = (
  WrappedComponent: FunctionComponent<any>,
): FunctionComponent<BottomTabScreenProps<{ navigation: object; route: object }>> => {
  return function WrappedFC(props) {
    const dispatch = useDispatch();
    const {
      route: { name: routeName },
    } = props;
    const logRoute = useCallback(() => {
      dispatch(logToggleTab(routeName as TCurrentTab));
    }, [dispatch, routeName]);

    useFocusEffect(logRoute);

    return <WrappedComponent {...props} />;
  };
};

import React, { FunctionComponent, useCallback, useEffect, useMemo } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { useDispatch, useSelector } from 'react-redux';
import { BackHandler } from 'react-native';

import { SomethingWentWrong } from '../scenes/SomethingWentWrong/SomethingWentWrong';
import { Login } from '../scenes/Auth/Login';
import { UpdateSensorsPage } from '../scenes/UpdateSensorsPage/UpdateSensorsPage';
import { WelcomePage } from '../scenes/Welcome/Welcome';
import { WelcomePage as StartPage } from '../scenes/Welcome/Welcome.new';
import { Forbidden } from '../scenes/Forbidden/Forbidden';
import { Logout } from '../scenes/Auth/Logout';
import { FeedbackEdit } from '../scenes/FeedbackEdit/FeedbackEdit';
import { Feedback } from '../scenes/Feedback/Feedback';
import { Home } from '../scenes/Home/Home';
import { ModalMessage } from '../scenes/Modal/ModalMessage';
import { Survey, SurveyQueryScreen } from '../scenes/Survey';
import { ModalNotification } from '../scenes/Modal/ModalNotification';
import { ScheduleAppointment } from '../scenes/RescheduleAppointment/ScheduleAppointment';
import { SurveySummary } from '../scenes/Survey/SurveySummary';
import { ChooseReason } from '../scenes/Support/ChooseReason';
import { ModalLoading } from '../scenes/Modal/ModalLoading';
import { ExitInstructions } from '../scenes/ExitInstructions/ExitInstructions';
import { Instruction } from '../scenes/Instruction/Instruction';
import { useAuthenticated } from '../hooks/useAuthenticated';
import { RescheduleReason } from '../scenes/RescheduleAppointment/RescheduleReason';
import { RequestReason } from '../scenes/RescheduleAppointment/RequestReason';
import { isStudyComplete, isStudyWithdraw } from '../services/patient/selector';
import { getIsShowStartPageByUserId } from '../app/selectors';
import { Withdrawal } from '../scenes/Withdrawal';
import { withIdleTimeoutTracker } from '../services/metrics/utils';
import { RequestRingSize } from '../scenes/Instruction/RequestRingSize';
import { useOnChange } from '../hooks/useOnChange';
import { appRoute, modalRouteLoaded, replaceRoute } from '../app/actions';
import { WelcomeSplash } from '../scenes/WelcomeSplash/WelcomeSplash';
import { useNetInfoConnection } from '../hooks/useNetInfo';
import { getCurrentRouteName, setTopLevelNavigator } from './NavigationService';
import { AUTH_ROUTES, MODAL_ROUTES } from './routes';
import { AuthStackParamList, ModalStackParamList } from './types';
import { TabNavigator } from './TabNavigator';
import { checkCurrentRoute, getInitRoutNameModalNav } from './utils';
import { WithRouteLogging } from './WithRouteLogging';

const ModalStackNavigator = createStackNavigator<ModalStackParamList>();
const ModalStackNavigatorScreen = () => {
  const isTrialComplete = useSelector(isStudyComplete);
  const isShowStartPage = useSelector(getIsShowStartPageByUserId);
  const isTrialWithdraw = useSelector(isStudyWithdraw);

  const initialRouteName = useMemo(
    () => getInitRoutNameModalNav({ isShowStartPage, isTrialComplete, isTrialWithdraw }),
    [isTrialComplete, isShowStartPage, isTrialWithdraw],
  );

  const dispatch = useDispatch();

  useOnChange(initialRouteName, (value) => {
    if (value === MODAL_ROUTES.EXIT_INSTRUCTIONS) {
      dispatch(appRoute(value));
    }
  });

  useEffect(() => {
    dispatch(modalRouteLoaded());
  }, [dispatch]);

  return (
    <ModalStackNavigator.Navigator
      headerMode={'none'}
      screenOptions={{
        cardStyle: { backgroundColor: 'transparent' },
        cardOverlayEnabled: true,
        cardStyleInterpolator: ({ current: { progress } }) => ({
          overlayStyle: {
            opacity: progress.interpolate({
              inputRange: [0, 1],
              outputRange: [0, 0.5],
              extrapolate: 'clamp',
            }),
          },
        }),
      }}
      mode={'modal'}
      initialRouteName={initialRouteName}
    >
      <ModalStackNavigator.Screen name={MODAL_ROUTES.TAB_NAVIGATOR} component={TabNavigator} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.MODAL_MESSAGE} component={ModalMessage} />
      <ModalStackNavigator.Screen
        name={MODAL_ROUTES.MODAL_NOTIFICATION}
        component={ModalNotification}
      />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.HOME} component={Home} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.UPDATE_SENSOR} component={UpdateSensorsPage} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.FEEDBACK} component={Feedback} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.FEEDBACK_EDIT} component={FeedbackEdit} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.SURVEY_SUMMARY} component={SurveySummary} />
      <ModalStackNavigator.Screen
        name={MODAL_ROUTES.SCHEDULING_WITH_TIME_SLOT}
        component={ScheduleAppointment}
      />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.SURVEY} component={Survey} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.SURVEY_QUERY} component={SurveyQueryScreen} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.SUPPORT_REQUEST} component={ChooseReason} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.LOADING} component={ModalLoading} />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.INSTRUCTION} component={Instruction} />
      <ModalStackNavigator.Screen
        name={MODAL_ROUTES.EXIT_INSTRUCTIONS}
        component={ExitInstructions}
      />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.WELCOME_SPLASH} component={WelcomeSplash} />
      <ModalStackNavigator.Screen
        name={MODAL_ROUTES.RESCHEDULE_REASON}
        component={RescheduleReason}
      />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.REQUEST_REASON} component={RequestReason} />
      <ModalStackNavigator.Screen
        name={MODAL_ROUTES.CHANGE_RING_SIZE}
        component={RequestRingSize}
      />
      <ModalStackNavigator.Screen
        name={MODAL_ROUTES.START_PAGE}
        component={WithRouteLogging(StartPage)}
      />
      <ModalStackNavigator.Screen name={MODAL_ROUTES.WITHDRAWAL_REQUEST} component={Withdrawal} />
    </ModalStackNavigator.Navigator>
  );
};

const WELCOME_SPLASH_TIMEOUT = 1500;
const AuthStackNavigator = createStackNavigator<AuthStackParamList>();
const AuthStackNavigatorScreen = ({ isAuth }: { isAuth: boolean }) => {
  const dispatch = useDispatch();

  useEffect(() => {
    setTimeout(() => {
      const routeName = isAuth ? AUTH_ROUTES.MODAL_NAVIGATOR : AUTH_ROUTES.WELCOME;
      dispatch(replaceRoute(routeName));
    }, WELCOME_SPLASH_TIMEOUT);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <AuthStackNavigator.Navigator
      initialRouteName={AUTH_ROUTES.WELCOME_SPLASH}
      headerMode={'none'}
      screenOptions={{
        animationEnabled: false,
      }}
    >
      <AuthStackNavigator.Screen name={AUTH_ROUTES.WELCOME} component={WelcomePage} />
      <AuthStackNavigator.Screen name={AUTH_ROUTES.WELCOME_SPLASH} component={WelcomeSplash} />
      <AuthStackNavigator.Screen name={AUTH_ROUTES.LOGIN} component={Login} />
      <AuthStackNavigator.Screen name={AUTH_ROUTES.LOGOUT} component={Logout} />
      <AuthStackNavigator.Screen
        name={AUTH_ROUTES.MODAL_NAVIGATOR}
        component={ModalStackNavigatorScreen}
      />
      <AuthStackNavigator.Screen name={AUTH_ROUTES.FORBIDDEN} component={Forbidden} />
      <AuthStackNavigator.Screen
        name={AUTH_ROUTES.SOMETHING_WENT_WRONG}
        component={SomethingWentWrong}
      />
    </AuthStackNavigator.Navigator>
  );
};

const RootNavigator: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();
  const isAuthenticated = useAuthenticated(dispatch);

  const navRef = useCallback((ref) => {
    setTopLevelNavigator(ref);
  }, []);

  useEffect(() => {
    const backAction = () => {
      const routeName = getCurrentRouteName();
      if (checkCurrentRoute(routeName)) {
        return true;
      }
      return false;
    };

    const backHandler = BackHandler.addEventListener('hardwareBackPress', backAction);

    return () => backHandler.remove();
  }, []);

  useNetInfoConnection();

  return (
    <NavigationContainer ref={navRef} documentTitle={{ enabled: false }}>
      <AuthStackNavigatorScreen isAuth={isAuthenticated} />
    </NavigationContainer>
  );
};

const WrappedRootNavigator = withIdleTimeoutTracker(RootNavigator);

export { WrappedRootNavigator as RootNavigator };

import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Colors } from '../utilities/design';
import { ILabelProps } from './types';

export const Label: FunctionComponent<ILabelProps> = ({ style, label }) => (
  <View style={[styles.container]}>
    <Text style={[styles.text, style && style.text]} children={label} />
    <View style={[styles.underline, style && style.underline]} />
  </View>
);

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    width: '100%',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.primaryDarkest,
  },
  text: {
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: 20,
    textAlign: 'center',
    color: Colors.white,
  },
  underline: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    height: 6,
    backgroundColor: Colors.primaryDarkest,
  },
});

import React from 'react';
import { BottomTabBarOptions } from '@react-navigation/bottom-tabs/lib/typescript/src/types';
import { createStackNavigator } from '@react-navigation/stack';

import { Platform } from 'react-native';
import IconNavigator from '../../assets/images/TabNavigator/Navigator.svg';
import IconNavigatorActive from '../../assets/images/TabNavigator/NavigatorActive.svg';
import IconCalendar from '../../assets/images/TabNavigator/Calendar.svg';
import IconCalendarActive from '../../assets/images/TabNavigator/CalendarActive.svg';
import IconSettings from '../../assets/images/TabNavigator/Settings.svg';
import IconSettingsActive from '../../assets/images/TabNavigator/SettingsActive.svg';
import IconCall from '../../assets/images/TabNavigator/Call.svg';
import IconCallActive from '../../assets/images/TabNavigator/CallActive.svg';
import { Colors } from '../utilities/design';
import { Appointments } from '../scenes/Appointments/Appointments';
import { Support } from '../scenes/Support/Support';
import { AppointmentsDetailPage } from '../scenes/Appointments/AppointmentsDetailPage';
import { Options } from '../scenes/Options/Options';
import { isIPhoneXrSize, isIPhoneXSize, OS_WEB } from '../constants/constants';
import { getFeatureFlag } from '../utilities/config';
import { Dashboard } from '../scenes/Dashboard/Dashboard';
import { APPT_MODAL_ROUTES, APPT_ROUTES, TAB_ROUTES } from './routes';
import { TabNavigatorView } from './TabNavigatorView';
import {
  AppointmentsModalStackParamList,
  AppointmentsStackParamList,
  INavigatorTab,
  LabelName,
} from './types';
import { WithRouteLogging } from './WithRouteLogging';

const AppointmentsStackNavigator = createStackNavigator<AppointmentsStackParamList>();
const AppointmentsStackNavigatorScreen = () => (
  <AppointmentsStackNavigator.Navigator headerMode={'none'} initialRouteName={APPT_ROUTES.LIST}>
    <AppointmentsStackNavigator.Screen
      name={APPT_ROUTES.LIST}
      component={WithRouteLogging(Appointments)}
    />
    <AppointmentsStackNavigator.Screen
      name={APPT_ROUTES.DETAIL}
      component={WithRouteLogging(AppointmentsDetailPage)}
    />
  </AppointmentsStackNavigator.Navigator>
);

const AppointmentsModalStackNavigator = createStackNavigator<AppointmentsModalStackParamList>();
const AppointmentsModalStackNavigatorScreen = () => (
  <AppointmentsModalStackNavigator.Navigator
    headerMode={'none'}
    screenOptions={{
      cardStyle: { backgroundColor: 'transparent' },
      cardOverlayEnabled: true,
      cardStyleInterpolator: ({ current: { progress } }) => ({
        cardStyle: {
          opacity: progress.interpolate({
            inputRange: [0, 0.5, 0.9, 1],
            outputRange: [0, 0.25, 0.7, 1],
          }),
        },
        overlayStyle: {
          opacity: progress.interpolate({
            inputRange: [0, 1],
            outputRange: [0, 0.5],
            extrapolate: 'clamp',
          }),
        },
      }),
    }}
    mode={'modal'}
    initialRouteName={APPT_MODAL_ROUTES.APPOINTMENTS_STACK_NAVIGATOR}
  >
    <AppointmentsModalStackNavigator.Screen
      name={APPT_MODAL_ROUTES.APPOINTMENTS_STACK_NAVIGATOR}
      component={AppointmentsStackNavigatorScreen}
    />
  </AppointmentsModalStackNavigator.Navigator>
);

const routesIcon: INavigatorTab[] = [
  {
    route: TAB_ROUTES.DASHBOARD,
    screen: WithRouteLogging(Dashboard),
    activeColor: Colors.newBlue,
    IconElement: IconNavigator,
    IconElementActive: IconNavigatorActive,
    label: LabelName.HOME,
  },
  {
    route: TAB_ROUTES.APPOINTMENTS_MODAL_NAVIGATOR,
    screen: WithRouteLogging(AppointmentsModalStackNavigatorScreen),
    activeColor: Colors.newBlue,
    IconElement: IconCalendar,
    IconElementActive: IconCalendarActive,
    label: LabelName.CALENDAR,
  },
  {
    route: TAB_ROUTES.SUPPORT,
    screen: WithRouteLogging(Support),
    activeColor: Colors.newBlue,
    IconElement: IconCall,
    IconElementActive: IconCallActive,
    label: LabelName.SUPPORT,
  },
  {
    route: TAB_ROUTES.OPTIONS,
    screen: WithRouteLogging(Options),
    activeColor: Colors.newBlue,
    IconElement: IconSettings,
    IconElementActive: IconSettingsActive,
    label: LabelName.SETTINGS,
  },
];

const config: BottomTabBarOptions = !(
  Platform.OS === OS_WEB && getFeatureFlag('enableNewWebLayout')
)
  ? {
      showLabel: false,
      style: {
        minHeight: isIPhoneXSize() || isIPhoneXrSize() ? 110 : 88,
        height: 'auto',
        paddingLeft: 4,
        paddingRight: 4,
        borderWidth: 0,
        borderTopWidth: 1,
        borderTopColor: Colors.greyLighter,
        backgroundColor: Colors.greyLightest,
        elevation: 0,
        shadowColor: Colors.white,
        shadowOpacity: 0,
        shadowOffset: {
          height: 0,
          width: 0,
        },
        shadowRadius: 0,
      },
      tabStyle: {
        marginLeft: 4,
        marginRight: 4,
      },
      keyboardHidesTabBar: true,
    }
  : {
      showLabel: false,
      style: {
        minHeight: isIPhoneXSize() || isIPhoneXrSize() ? 110 : 88,
        height: 'auto',
        paddingLeft: 4,
        paddingRight: 4,
        borderWidth: 0,
        borderTopWidth: 1,
        borderTopColor: Colors.greyLighter,
        backgroundColor: Colors.greyLightest,
        elevation: 0,
        shadowColor: Colors.white,
        shadowOpacity: 0,
        shadowOffset: {
          height: 0,
          width: 0,
        },
        alignItems: 'center',
        minWidth: 500,
        shadowRadius: 0,
      },
      tabStyle: {
        marginLeft: 4,
        marginRight: 4,
        maxWidth: 224,
        minWidth: 117,
        width: '23vw',
      },
      keyboardHidesTabBar: true,
    };

export const TabNavigator = TabNavigatorView(routesIcon, config);

import React, { FunctionComponent } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Colors } from '../utilities/design';
import { testId } from '../utilities/TestId';
import { IS_OS_WEB, WEB_TAB_NAV_WIDTH } from '../constants/constants';
import { IIconProps } from './types';

export const Icon: FunctionComponent<IIconProps> = ({
  style: { container = {}, labelContainer = {}, underlineContainer = {} },
  children,
  label,
  underline = false,
}) => (
  <View
    style={StyleSheet.flatten([styles.container, styles.containerPadding, container])}
    {...testId(`view_${label}`)}
    importantForAccessibility={'no-hide-descendants'}
  >
    <View importantForAccessibility={'no-hide-descendants'}>{children}</View>
    {!!label && (
      <View style={StyleSheet.flatten([styles.borderContainer, underline && styles.underline])}>
        <Text
          style={StyleSheet.flatten([styles.label, labelContainer])}
          {...testId(`icon_${label}`)}
          maxFontSizeMultiplier={1.4}
        >
          {label}
        </Text>
      </View>
    )}
  </View>
);

const styles = StyleSheet.create({
  containerPadding: IS_OS_WEB
    ? {
        paddingLeft: 20,
        paddingRight: 20,
        marginBottom: 4,
        marginTop: 2,
        minWidth: WEB_TAB_NAV_WIDTH,
        width: '100%',
      }
    : { width: '100%' },
  container: {
    height: 'auto',
    minHeight: 72,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 10,
    backgroundColor: Colors.white,
    shadowColor: Colors.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  label: {
    marginTop: 3,
    color: Colors.greyDark,
    fontFamily: 'SourceSansPro-SemiBold',
    fontStyle: 'normal',
    fontWeight: '600',
    fontSize: 16,
    lineHeight: 20,
  },
  borderContainer: {
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  underline: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.newBlue,
  },
});

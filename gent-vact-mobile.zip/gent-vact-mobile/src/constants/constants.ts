import { Appearance, Dimensions, Platform } from 'react-native';
import { Grade } from '../scenes/Feedback/types';
import { MODAL_ROUTES, TAB_ROUTES } from '../navigation/routes';
import { IMenuItem } from '../scenes/Menu/types';
import { FormattedString } from '../components/FormattedText/types';
import { Colors } from '../utilities/design';
import { AppointmentStatus, FutureAppointmentStatus } from '../services/appointments/types';
import { IFAQInstruction } from '../scenes/Instruction/types';

export const OS_ANDROID = 'android';
export const OS_IOS = 'ios';
export const OS_WEB = 'web';

export const CURRENT_WIDTH = Dimensions.get('window').width;
const CURRENT_HEIGHT = Dimensions.get('window').height;

const getDeviceWidth = () => {
  if (CURRENT_HEIGHT > 940) {
    if (CURRENT_WIDTH > 496) {
      return 442;
    } else {
      return 400;
    }
  } else {
    return 450;
  }
};

const getDeviceHeight = () => {
  if (CURRENT_WIDTH <= 496) {
    return 568;
  } else if (CURRENT_HEIGHT > 940) {
    return 888;
  } else {
    return 716;
  }
};

export const DEVICE_WIDTH = Platform.OS === OS_WEB ? getDeviceWidth() : CURRENT_WIDTH;
export const DEVICE_HEIGHT = Platform.OS === OS_WEB ? getDeviceHeight() : CURRENT_HEIGHT;

export const MOCK_FEEDBACK_BUTTON = 'FEEDBACK';
export const MOCK_HEADER_TEXT = ["It's ", ' of the trial.', 'Here’s your focus for today:'];

export const TEXT_LOGOUT = 'Logout';
export const TEXT_LOGOUT_CONFIRM = 'Confirm Logout';
export const TEXT_LOGOUT_CONFIRM_DESCRIPTION =
  'Tap Logout in case you really want to change your account';
export const TEXT_WITHDRAWAL = 'Request Withdrawal';
export const TEXT_LOGIN = 'LOGIN';
export const TEXT_RESUME = 'RESUME';
export const TEXT_RELOGIN = 'RESTART';
export const TEXT_MENU = 'Menu';
export const TEXT_TASKS = 'TASKS';
export const TEXT_TRIAL = 'Trial';
export const TEXT_OK = 'Ok';
export const TEXT_RETRY = 'Retry';
export const TEXT_BACK = 'Back';
export const TEXT_INFO_HEADER = 'Check your device';
export const TEXT_INFO_CONNECT_BUTTON = 'See how to connect';
export const TEXT_INFO_TELEHEALTH_BUTTON = 'Do a Telehealth trial run';
export const TEXT_APPOINTMENT = 'Appointment';
export const TEXT_APPOINTMENTS = 'Appointments';
export const TEXT_REQUESTS = 'Requests';
export const TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_RESCHEDULED = 'Reschedule requested by you';
export const TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_CANCELLED = 'Cancelled by doctor';
export const TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_COMPLETED = 'Completed';
export const TEXT_APPT_DETAIL_PLACEHOLDER_HEADER_MISSED = 'Missed';
export const TEXT_APPT_DETAIL_PLACEHOLDER_DESCRIPTION = 'Awaiting doctor’s decision';
export const TEXT_SURVEY_HEADER = 'Preparing for your appointment';
export const TEXT_SUPPORT_HEADER = 'Support';
export const TEXT_SUPPORT_CANCEL_REQUEST = 'Cancel Request';
export const TEXT_SUPPORT_MODAL_WARNING_CANCEL_REQUEST = 'Are you sure you want to cancel request?';
export const TEXT_SUPPORT_MODAL_SUCCESS_CANCEL_REQUEST = 'This request has been canceled.';
export const TEXT_SUPPORT_REASON =
  'Use the options below if you have any issues to discuss or wish to withdraw from the trial.';
export const TEXT_SUPPORT_DESCRIPTION =
  'Contact Dr Jones if you have any non-emergency health issues, or need more info on the trial.';
export const TEXT_SUPPORT_BUTTON = 'Request a call';
export const TEXT_SUPPORT_CALL_NOW = 'Call now';
export const TEXT_SUPPORT_CHOOSE_REASON_HEADER = 'Request a call';
export const TEXT_SUPPORT_CHOOSE_REASON_BUTTON = 'Submit Request';
export const TEXT_SUPPORT_CHOOSE_REASON = 'Please specify the reason for a call:';
export const TEXT_SUPPORT_SELECT_TO_CONTINUE = 'Select a reason to continue';
export const GET_TEXT_SUPPORT_NAME_FOR_ADDITIONAL_DESCRIPTION = (contactName: string): string =>
  contactName ? `\n${contactName} will call you as soon as possible.` : '';
export const GET_TEXT_SUPPORT_DATE_FOR_ADDITIONAL_DESCRIPTION = (date: string): string =>
  `You requested a call on ${date}.`;

export const GET_TEXT_SUPPORT_ADDITIONAL_DESCRIPTION = (date = '', contactName = ''): string =>
  `${GET_TEXT_SUPPORT_DATE_FOR_ADDITIONAL_DESCRIPTION(
    date,
  )}${GET_TEXT_SUPPORT_NAME_FOR_ADDITIONAL_DESCRIPTION(contactName)}`;

export const TEXT_SUPPORT_REQUEST_SUCCESS = (name: string): FormattedString => [
  {
    text: 'Your call request was successfully sent! ',
    size: 16,
    lineHeight: 24,
    isBold: true,
    fontFamily: 'SourceSansPro-Bold',
  },
  { text: `\n\n${name} will call you as soon as possible.`, size: 16, lineHeight: 24 },
];

export const TEXT_NO_NET_CONNECT: FormattedString = [
  {
    text: 'Ooops, we’re experiencing trouble with your connection. ',
    size: 20,
    lineHeight: 28,
    isBold: true,
    fontFamily: 'SourceSansPro-Bold',
  },
  { text: 'You can try to change your internet connection.', size: 20, lineHeight: 28 },
];

export const TEXT_SUPPORT_REQUEST_ERROR =
  'An error occurred while\nprocessing your request.\nPlease try again later.';

export const TEXT_LAST_UPDATED = 'Last updated';
export const TEXT_BOOK_APPOINTMENT = 'Book appointment';
export const TEXT_STOP_BOOK_APPOINTMENT = 'Stop booking';
export const TEXT_NO_FREE_SLOTS = 'No available slots';
export const TEXT_PLEASE_INSTALL_TEAMS = 'Please install Teams';

export const TEXT_UPDATE_BUTTON = 'update';
export const TEXT_REQUEST_AN_APPOINTMENT_BUTTON = 'Request an Appointment';
export const TEXT_SURVEY_BUTTON = 'Fill in survey now';
export const TEXT_CANCEL_BUTTON = 'CANCEL';
export const TEXT_CANCEL_LOWERCASE = 'Cancel';
export const TEXT_CLOSE_BUTTON = 'Close';
export const TEXT_REQUEST_DOCTORS_CALL_BUTTON = "REQUEST DOCTOR'S CALL";
export const TEXT_HEARTBEAT_ON_BUTTON = 'ACTIVATE HEARTBEAT SENSOR';
export const TEXT_SKIP_BUTTON = 'SKIP';
export const TEXT_SUBMIT_BUTTON = 'SUBMIT';
export const TEXT_SUBMIT_APPOINTMENT_REQUEST = 'Request appointment';
export const TEXT_SUBMIT_RESCHEDULE_REQUEST = 'Reschedule appointment';
export const TEXT_ENTER_REASON = 'Enter a reason to continue';
export const TEXT_ENTER_SIZE = 'Select a size to continue';
export const TEXT_ENTER_SUBMIT = 'Submit new ring size';
export const TEXT_EDIT_BUTTON = 'edit';
export const TEXT_RING_SIZE = 'Ring Size';
export const TEXT_RING_SIZE_HEAD = 'Submit a New Ring Size';
export const TEXT_RING_SIZE_DESC =
  'Please select and submit your new ring size from the options below.';

export const TEXT_FEEDBACK_HEADER = 'Please Rate the Following';
export const TEXT_FEEDBACK_EDIT_HEADER = 'Please provide details';
export const TEXT_FEEDBACK_EDIT_INPUT = 'Your comment ...';
export const TEXT_MESSAGE_FOR_DOCTOR = 'Call requested by you';
export const TEXT_INDEX_ZERO = '\u00B0';
export const TEXT_CANNOT_CONNECT_SERVER = 'Cannot connect the authentication server';
export const TEXT_CONNECTING_AUTH_SERVER = 'Connecting to the authentication server...';
export const TEXT_SOMETHING_WENT_WRONG = 'Something went wrong';
export const TEXT_INTERNAL_SERVER_ERROR = 'Internal Server Error';
export const TEXT_ERROR = 'Error';
export const TEXT_FORBIDDEN = 'You do not have required permissions';
export const TEXT_CONTACT_ADMINISTRATOR = 'Please contact administrator';
export const TEXT_DESCRIPTION = 'Press your finger against the sensor';
export const TEXT_NO_ITEMS = 'There are no items here';
export const TEXT_REQUEST_STATUS = 'Request status:';
export const TEXT_SERVER_MESSAGE = 'Server message:';
export const TEXT_URL = 'URL:';
export const TEXT_TIMESTAMP = 'Timestamp:';

export const TEXT_WELCOME_TITLE = 'Welcome to The Compass';
export const TEXT_WELCOME_CONTINUE = 'Please tap Login to continue';
export const TEXT_BOOK_STANDARD_APPOINTMENT = 'Book new standard care appointment';
export const TEXT_SELECT_ONE_OPTION = 'Select one of the following options';
export const TEXT_CANT_JOIN = "Can't join any of these dates?";
export const TEXT_CALL_VA_FACILITY = 'Call VA facility/clinical team to schedule';
export const TEXT_VIDEO_CALL = 'Telehealth Video Call';
export const VIDEO_CALL = 'Video Call';
export const TEXT_PHONE_CALL = 'Phone Call';
export const TEXT_IN_PERSON = 'In Person';
export const TEXT_SELECT_PREFERRED_TYPE = 'Select your preferred type of call';
export const TEXT_START_AGAIN = 'Start again';
export const TEXT_DEFAULT_PLACEHOLDER = 'No data';
export const TEXT_RESCHEDULE_PLACEHOLDER = 'Wrong date';
export const TEXT_EMPTY_APPOINTMENTS = 'You have no appointments';
export const TEXT_EMPTY_SUPPORT = 'You have no contacts';
export const TEXT_EMPTY_APPOINTMENT = 'Your appointment was not found';
export const TEXT_PREPARATION = 'Preparation required';
export const TEXT_CHOOSE_FREE_TIME_SLOT = 'Choose time slot';
export const TEXT_CHOOSE_DAY_TIME = 'Choose day/time';
export const TEXT_RESCHEDULE_REQUESTED = "You've requested to reschedule";
export const TEXT_WAITING_FOR_DOCTOR_REPLY = "Awaiting for Doctor's reply";
export const TEXT_APPOINTMENT_WAS_CANCELLED = 'This appointment was cancelled';
export const TEXT_REAQUSTED_BY_YOU_ON = 'Requested by you on';

export const isIPhoneXSize = () => {
  return Platform.OS === OS_IOS && (DEVICE_HEIGHT === 812 || DEVICE_WIDTH === 812);
};

export const isIPhoneXrSize = () => {
  return Platform.OS === OS_IOS && (DEVICE_HEIGHT === 896 || DEVICE_WIDTH === 896);
};

export const TEXT_OVERDUE_SURVEY = 'survey is overdue.';
export const TEXT_SENDING = 'Sending...';

export const TEXT_TO_DO_LIST_HEADER = 'To-Do Today';

export const BUTTON_VARIABLE: Grade[] = [
  Grade.ANGRY,
  Grade.SAD,
  Grade.SCEPTIC,
  Grade.HAPPY,
  Grade.VERY_HAPPY,
];

export const MENU_ITEMS: IMenuItem[] = [
  {
    route: TAB_ROUTES.DASHBOARD,
    title: 'DASHBOARD',
  },
  {
    route: MODAL_ROUTES.HOME,
    title: 'HOME',
  },
  {
    route: MODAL_ROUTES.FEEDBACK,
    title: 'FEEDBACK',
  },
  {
    route: MODAL_ROUTES.STORYBOOK,
    title: 'STORYBOOK',
  },
];

export const PATIENT_ID = 'Patient ID:';

export const TODO_HEADERS = {
  WHAT: 'WHAT',
  WHEN: 'WHEN',
};

export const TODO_BUTTONS_TITLES = {
  JOIN: 'Join now',
  JOINED: 'Joined',
  MARK: 'Mark done',
  FILL_SURVEY: 'Fill survey',
  FILLED_SURVEY: 'Filled',
  DONE: 'Done',
  ACCEPT_APT: 'Accept',
  ACCEPTED: 'Accepted',
  DETAILS: 'Details',
  CHOOSE: 'Choose',
  UNDO: 'Undo',
};

export const VIDEO_CALL_WITH = (name: string) => {
  return `Video Call with Dr ${name}`;
};
export const APPOINTMENT_ERROR = 'Your Appointment can not be accepted';
export const APPOINTMENT_ACCEPTED_MESSAGE =
  'Your appointment was successfully requested!\nYour doctor will get back to you shortly with a suitable time slot.';
export const GOOD_EVENING = 'Good evening';
export const GOOD_MORNING = 'Good morning';
export const GOOD_AFTERNOON = 'Good afternoon';
export const GREETING_CHECK_INTERVAL = 60000;

export const IS_OS_WEB = Platform.OS === OS_WEB;

export const FREQUENCY_RADIO_VALUES = ['Instant', 'From', 'till'];

export const CHOOSE_NEW_TIME = 'Select a time to confirm your appointment';
export const TIME_SLOTS_DONT_SUIT = "Time slots don't suit you?";
export const YOUR_NEW_TIME = 'Your new time for video call with dr.';
export const TEXT_CONFIRM = 'Confirm';
export const PICK_ANOTHER = 'Pick another time slot';
export const RESCHEDULE_APT = 'Reschedule appointment';
export const RESCHEDULE_DECLINE_DESCR =
  'Please specify a reason for the reschedule so the doctor can offer you available time slot(s).';
export const REQUEST_APT = 'Request an appointment';
export const REQUEST_DESCRIPTION =
  'Select a reason for your appointment so your doctor can get back to with a suitable time.';
export const RESCHEDULE_DECLINE_MESSAGE_ERROR = 'Your reschedule request can not be accepted';
export const RESCHEDULE_DECLINE_MESSAGE_SUCCESS =
  'Your reschedule request was successfully registered!\nYour doctor will get back to you shortly with a suitable time slot.';
export const APPOINTMENT_RESCHEDULED = 'Appointment Rescheduled';
export const VIEW_DETAILS = 'View details';
export const APPOINTMENT_SETTINGS = 'Appointment settings';
export const APPOINTMENT_STARTED = 'Appointment started';
export const NOTIFICATION_SETTINGS = 'Notification settings';
export const PREFERRED_TYPE_OF_APPOINTMENT = 'Preferred type of appointment';
export const APPOINTMENT_REMINDERS = 'Appointment reminders';
export const MENU_SELECT_ONE_OPTION: FormattedString = [
  { text: 'Select ', size: 16, lineHeight: 24 },
  { text: 'one option', size: 16, lineHeight: 24, isBold: true, fontFamily: 'SourceSansPro-Bold' },
  { text: ' for your first reminder', size: 16, lineHeight: 24 },
];
export const MENU_SELECT_ANY_OPTIONS: FormattedString = [
  { text: 'Select ', size: 16, lineHeight: 24 },
  {
    text: 'one or more options',
    size: 16,
    lineHeight: 24,
    isBold: true,
    fontFamily: 'SourceSansPro-Bold',
  },
  { text: ' for your second reminder', size: 16, lineHeight: 24 },
];

export const APPOINTMENT_RADIO_ITEMS = ['As defined by the Doctor', 'Video call', 'Phone call'];

export const CLEAN_VIEWED_NOTIFICATIONS_DAYS_DIFFERENCE = 2;
export const CLEAN_VIEWED_NOTIFICATIONS_INTERVAL = 6 * 60 * 60 * 1000;
export const VIRTUAL_APPOINTMENT = (name: string) => `Virtual Visit Appointment with ${name}`;
export const TELEHEALTH_APT = 'Telehealth appointment';
export const APPOINTMENT_DETAILS = 'Appointment details';
export const EVERYTHING_READY = 'Everything is ready';
export const MARK_EVERYTHING_READY = 'Check box when everything is ready';

export const NOTIFICATIONS_TITLES = {
  ALERT: 'Alert',
  NEW_APT: 'New appointment',
  PROCESSED_APT: 'Appointment confirmed',
  DECLINED_APT: 'Appointment declined',
  REMINDER: 'Reminder',
  DEFAULT: 'Appointment',
  COMING_APPOINTMENT: 'Appointment Reminder',
  [AppointmentStatus.SCHEDULED]: 'Appointment scheduled',
  [AppointmentStatus.PARTIAL_SCHEDULED]: 'Appointment partially scheduled',
  [AppointmentStatus.CANCELLED]: 'Appointment cancelled',
  [FutureAppointmentStatus.DECLINED]: 'Appointment request declined',
  [AppointmentStatus.COMPLETED]: 'Appointment completed',
  [AppointmentStatus.MISSED]: 'Appointment missed',
  [AppointmentStatus.RESCHEDULED]: 'Appointment rescheduled',
  [AppointmentStatus.NEW]: 'New appointment',
};

export const TEXT_REQUEST_TITLE = 'Request by patient';

export const TEXT_APPOINTMENT_REQUEST_ERROR = 'Your Appointment request can not be accepted';
export const TEXT_CHANGE_RING_SIZE_REQUEST_ERROR = 'Your request cannot be send';
export const TEXT_CHANGE_RING_SIZE_REQUEST_SUCCESS = 'Your request was submitted';
export const TEXT_APPOINTMENT_REQUEST_ACCEPTED =
  'Your appointment was successfully requested!\nYour doctor will get back to you shortly with a suitable time slot.';
export const APPOINTMENT_RESCHEDULED_TEXT = (drName: string) =>
  `You have requested for this appointment to be rescheduled. ${drName} will contact you as soon as possible.`;
export const TEXT_NEW_APPOINTMENT_WITH = 'New appointment with';
export const TEXT_YOUR_APPOINTMENT_WITH = 'Your appointment with';
export const TEXT_NEW_APPOINTMENT = 'New appointment';
export const TEXT_PROVISIONAL = 'Provisional';
export const TEXT_APPOINTMENT_PRESENTATION =
  'We would like to set up an appointment for you. Please let us know your preferred date and time.';
export const TEXT_GET_STARTED = 'Get started';
export const TEXT_PROCESSED = 'Proceed to application';
export const TEXT_REMIND_ME_LATER = 'Remind me later';
export const SELECT_TO_CONTINUE = 'Select a time to continue';
export const DECLINE_APPOINTMENT = 'Request new time';
export const DECLINE_MESSAGE_ERROR = 'Your request new time can not be accepted';
export const TEXT_DECLINE_APPOINTMENT = 'Are you sure?';
export const TEXT_DECLINE_DESCRIPTION =
  'If you declined this appointment, your health care provider will be in touch soon with an alternative set of time slots';
export const TEXT_DECLINE_BUTTON1 = 'Decline appointment';
export const TEXT_DECLINE_BUTTON2 = 'Select a time slot';
export const APPOINTMENT_CANCEL_REASON = 'Cancel';
export const TEXT_CONTINUE = 'Continue';
export const TEXT_APPOINTMENT_DETAILS_LINE1 = 'Here are the details of your appointment.';
export const TEXT_APPOINTMENT_DETAILS_LINE2 = 'Please double-check before confirming.';
export const CHOOSE_A_DIFFERENT_TIME = 'Choose a different time';
export const WOULD_YOU_LIKE_TO_SHARE = 'Would you like to share this appointment?';
export const CONFIRM_APPOINTMENT = 'Confirm appointment';
export const SHARE_WITH_CAREGIVER = 'Share with caregiver';
export const APPOINTMENT_CONFIRMED = 'Your appointment confirmed successfully';
export const APPOINTMENT_REJECTED =
  'Sorry, that time slot is no longer available. Please choose another slot to book your appointment.';
export const SENSORS_DATA = 'Sensors data';
export const CONTACT_DETAILS = 'Contact details';
export const RESPONSES_TEXT = ['Response', 'Responses'];
export const EXPAND_TEXT = ['Collapse', 'Expand'];
export const SUBMIT_ANSWERS = 'Submit answers';
export const CHANGE_ANSWER = 'Change answer';

export const MAX_PARTIAL_APPOINTMENTS = 3;
export const TEAMS_NOT_INSTALLED = 'The MS Teams is not installed';
export const OURA_NOT_INSTALLED = 'The Oura app is not installed';
export const OURA_NOT_AVAILABLE = 'Action is not available in the web version';
export const OURA_NOT_AVAILABLE_WEB: FormattedString = [
  {
    text: 'The Oura app will not open from your desktop. ',
    size: 16,
    lineHeight: 24,
    isBold: true,
    fontFamily: 'SourceSansPro-Bold',
  },
  {
    text: '\nPlease open the Compass app on your phone to sync your ring.',
    size: 16,
    lineHeight: 24,
  },
];
export const CALLS_NOT_AVAILABLE = 'Phone calls are not available in the web version';

export const DR_HAS_STARTED_APPOINTMENT = (drName: string) =>
  drName
    ? `Dr. ${drName} has started an appointment with you`
    : 'Doctor has started an appointment with you';
export const TEXT_ATTEND = 'Attend';
export enum COLOR_SCHEMAS {
  LIGHT = 'light',
  DARK = 'dark',
}
export const CURRENT_COLOR_SCHEME =
  Platform.OS === OS_IOS ? Appearance.getColorScheme() : COLOR_SCHEMAS.LIGHT;

export const SAFE_AREA_COLOR =
  CURRENT_COLOR_SCHEME === COLOR_SCHEMAS.DARK ? Colors.greyDark : Colors.white;
export const SURVEY_COMPLITED = 'Survey completed successfully';
export const SEND_SURVEY_ERROR = 'Error sending data';
export const TEXT_LIMITED_INDICATOR = '...';
export const TEXT_INSTRUCTION_OURA = 'Instructions';
export const TEXT_INSTRUCTION_OURA_FAQ_TITLE = 'Useful information';
export const TEXT_INSTRUCTION_OURA_HOME_PAGE_LINK = 'View guide';
export const TEXT_INSTRUCTION_OURA_HOME_PAGE_SYNCING_DESCRIPTION = 'Keep your health data updated';
export const TEXT_INSTRUCTION_OURA_HOME_PAGE_CHARGING_DESCRIPTION =
  'Keep your ring’s battery in good health';
export const TEXT_INSTRUCTION_OURA_RING = 'Your Oura ring';
export const TEXT_INSTRUCTION_OURA_CHARGING_HEADER = 'Charging your Oura ring';
export const TEXT_INSTRUCTION_OURA_CHANGING_HEADER = 'Changing your Oura ring';
export const TEXT_INSTRUCTION_CONTACT_HEADER = 'The Compass Helpdesk';
export const TEXT_INSTRUCTION_CONTACT_DESC = 'Technical Support';
export const TEXT_INSTRUCTION_TRIAL_HEADER = 'Trial information';
export const TEXT_INSTRUCTION_TRIAL_TITLE = 'About your trial';
export const TEXT_INSTRUCTION_TRIAL_DESCRIPTION =
  'Here is some important information about the trial, and what you can expect from it. Please take your time to read through.';
export const TEXT_INSTRUCTION_OURA_SYNCING_HEADER = 'Syncing your Oura ring';
export const TEXT_INSTRUCTION_OURA_CHARGING_DESCRIPTION =
  'Keep your ring charged to make sure your health data is being captured for your care provider.';
export const TEXT_INSTRUCTION_OURA_SYNCING_DESCRIPTION =
  'Sync your ring regularly to ensure your health data is being sent to your care provider.';
export const TEXT_INSTRUCTION_OURA_SYNCING_DETAIL_DESCRIPTION =
  'Syncing your Oura ring regularly is important to ensure your health care provider always has the latest health data recorded by the device.';
export const TEXT_INSTRUCTION_OURA_CHANGING_DETAIL_ADD_DESCRIPTION =
  'As you can wear your ring on any finger of your hand, you can always try another finger before choosing to select a new size.';
export const TEXT_INSTRUCTION_OURA_CHANGING_DETAIL_DESCRIPTION =
  'Sorry your Oura ring isn’t fitting correctly. Please follow these steps to request a new ring size.';
export const TEXT_INSTRUCTION_OURA_CHARGING_DETAIL_DESCRIPTION =
  'Keeping your Oura ring charged each day is important to make sure your health data is being captured as much as possible.';
export const TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_ONE =
  'Plug your Oura ring charger into a power source.';
export const TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_TWO =
  'Place your ring on to the charging dock, the LED light should start pulsing.';
export const TEXT_INSTRUCTION_OURA_CHARGING_ELEMENT_DESCRIPTION_STEP_THREE =
  'Wait for the LED light on the charger to stop pulsing, then remove the ring.';
export const TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_DESCRIPTION_STEP_ONE =
  'Open the Oura ring app on your phone.';
export const TEXT_INSTRUCTION_ARTICLE_HEADER_ONE = 'Why is this trial being done?';
export const TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_ONE =
  'This observational study will collect data through review of your medical records, surveys and use of a wearable device.\n\nThe information that comes from this study will play an important role in developing new ways to expand the opportunity for Veterans to participate in clinical trials.';
export const TEXT_INSTRUCTION_ARTICLE_HEADER_TWO = 'How long will I be in the trial?';
export const TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_TWO =
  'Your participation in this study will last about 6 months.';
export const TEXT_INSTRUCTION_ARTICLE_HEADER_THREE = 'What is involved in the trial?';
export const TEXT_INSTRUCTION_ARTICLE_THREE_POINT_ONE =
  'Inform your doctor about how you are, and of any changes in your health, medications, doctor or nurse appointments or hospital admissions you may have had.';
export const TEXT_INSTRUCTION_ARTICLE_THREE_POINT_TWO =
  'Inform your doctor if you participate in any other research study.';
export const TEXT_INSTRUCTION_ARTICLE_THREE_POINT_THREE =
  'Wear the wearable device as much as you can, unless it starts bothering you.';
export const TEXT_INSTRUCTION_ARTICLE_THREE_POINT_FOUR =
  'Dial in to the scheduled telehealth visits with your doctors.';
export const TEXT_INSTRUCTION_ARTICLE_THREE_POINT_FIVE = 'Complete surveys.';
export const TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_THREE =
  'You will be requested to do the following:';
export const TEXT_INSTRUCTION_ARTICLE_HEADER_FOUR = 'Does this replace my normal care?';
export const TEXT_INSTRUCTION_ARTICLE_DESCRIPTION_FOUR =
  'This study will not affect the treatments or diagnostic tests you receive, and you will continue to receive your usual standard-of-care as determined by your physician.';
export const TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_DESCRIPTION_STEP_TWO =
  'Wait a few moments... Your ring will sync the data automatically.';
export const TEXT_INSTRUCTION_OURA_SYNCING_ELEMENT_LINK_STEP_ONE = 'Open the app now';
export const TEXT_INSTRUCTION_OURA_OPEN_APP = 'Open the Oura App';
export const TEXT_INSTRUCTION_CHANGE_RING_SIZE_ONE =
  'Retrieve the Sizing kit that came with your Trial Kit.';
export const TEXT_INSTRUCTION_CHANGE_RING_SIZE_TWO =
  'Follow the instructions in the sizing kit, and try on the different sized rings to find one that feels most comfortable.';
export const TEXT_INSTRUCTION_CHANGE_RING_SIZE_THREE =
  'Once you’ve found a comfortable size as instructed in the kit, submit your new size using the button below.';
export const TEXT_INSTRUCTION_CHANGE_RING_SIZE_FOUR =
  'Once your replacement ring arrives, pair the ring to your phone using the Oura App.';
export const TEXT_INSTRUCTION_CHANGE_RING_SIZE_FIVE =
  'You can follow the instructions in the app, or contact The Compass Helpdesk if you need any assistance.';
export const TEXT_INSTRUCTION_MESSAGE_TITLE = 'Your next steps';
export const TEXT_INSTRUCTION_MESSAGE_DESC_ADD = 'You may now return to The Compass app.';
export const TEXT_INSTRUCTION_MESSAGE_DESC_ONE =
  'Your new ring should arrive within two weeks. Once it arrives, please return to the ';
export const TEXT_INSTRUCTION_MESSAGE_DESC_TWO = 'Changing your Oura ring ';
export const TEXT_INSTRUCTION_MESSAGE_DESC_THREE =
  'instructions on the Settings page to complete step 3 - pairing your new ring with your phone.';

export const FAQ_SYNCING_OURA: IFAQInstruction[] = [
  {
    question: 'How close does the Oura ring need to be to the phone to sync?',
    answer:
      'Your phone should be able to sync with your Oura ring from up to 100 metres away, but it’s best if it is in the same room.',
  },
  {
    question: 'How often should I sync the Oura ring to the Oura app?',
    answer:
      'Syncing your Oura ring every day is good practice to make sure your provider has up-to-date health data for you. Your ring can store data for up to 6 weeks without syncing to the app.',
  },
  {
    question: 'How long does it take for the Oura ring to finish syncing?',
    answer:
      'It should only take a few moments to sync your health data to the app. It may take a little longer if you’ve not synced your Oura ring for a few days.',
  },
];
export const FAQ_CHARGING_OURA: IFAQInstruction[] = [
  {
    question: 'How long will it take to charge the Oura ring?',
    answer:
      'Depending on the battery level, your ring could take from 20 to 80 minutes to fully charge.',
  },
  {
    question: 'How long will the Oura ring’s battery last?',
    answer:
      'The battery should last between 4 to 7 days depending on your activity level. The Oura ring app will remind you to charge if the battery gets too low.',
  },
  {
    question: 'How often should I charge the Oura ring?',
    answer:
      'Charging your ring a bit each day, such as when you’re brushing your teeth is a great habit and will ensure your ring never runs out of battery.',
  },
];
export const TEXT_INSTRUCTION_BUTTON = 'Got it!';
export const TEXT_INSTRUCTION_BUTTON_RING_SIZE = 'Submit a new ring size';
export const TEXT_INSTRUCTION_BUTTON_CALL = 'Call';
export const TEXT_INSTRUCTION_EMPTY = 'You have no instruction';
export const TRIAL_COMPLETED_TITLE = 'Trial withdrawal confirmed';
export const TRIAL_COMPLETED_MESSAGE =
  'Your request to withdraw from the trial has been accepted, please follow these next steps.';
export const TRIAL_COMPLETED_BUTTON = 'View exit instructions';
export const SUCCESS_COMPLETED_TRIAL_TITLE = 'Thank you for taking part in the trial';
export const TEXT_THANKS = 'Thank you!';
export const SUCCESS_COMPLETED_TRIAL_MESSAGE =
  'Please follow these next steps to finalize your exit.';

export const MAX_32_BIT_INT = 2147483647;
export const WEB_TAB_NAV_WIDTH = 80;
export const TEXT_START_PAGE_WELCOME_HEADER_EL1 = 'Welcome!';
export const TEXT_START_PAGE_WELCOME_DESCRIPTION_EL1 =
  'The Compass is a program to create new ways of supporting veterans like yourself by making it more convenient to take part in clinical trials.';
export const TEXT_START_PAGE_WELCOME_HEADER_EL2 = 'Let’s get started';
export const TEXT_START_PAGE_INSTRUCTION_TRIAL_HEADER = 'You are enrolled in';
export const TEXT_START_PAGE_INSTRUCTION_TRIAL_ID = (code: string): string =>
  `POTENTIAL Trial (${code})`;
export const TEXT_START_PAGE_INSTRUCTION_TRIAL_DESCRIPTION =
  'This is the team who is responsible for running the trial and making sure you’re taken care of:';
export const TEXT_START_PAGE_WELCOME_DESCRIPTION_EL2 =
  'The next few pages will give you more information about your trial and introduce you to some of the activities you will be asked to do as part of the trial.';

export const WEB_DEVICE_WIDTH = 516;

export const PATIENT_IDLE_TIMEOUT = 5000;

export const TEXT_OURA_CHARGE_COMPLETE =
  'Your Oura ring is now charged & the sync is completed.\n Remember to put your Oura ring back on.';

export const DEFAULT_OURA_RING_CHARGE_DURATION = 60 * 1000 * 10;
export const TEXT_DASHBOARD_EMPTY_TASKS =
  'You have no activities to complete for the rest of the day.';

export const WITHDRAWAL_MODAL_TITLE = 'Cancel withdrawal';
export const WITHDRAWAL_MODAL_MESSAGE = 'Are you sure you want to cancel your withdrawal request?';
export const WITHDRAWAL_CANCEL_REQUEST = 'Yes, cancel the request';
export const WITHDRAWAL_CONFIRM_REQUEST = 'No, I want to withdraw';

export const SUCCESS_TRIAL_WITHDRAWAL = 'Trial withdrawal confirmed';
export const SUCCESS_TRIAL_WITHDRAWAL_MESSAGE =
  'Your request to withdraw from the trial has been accepted, please follow these next steps.';
export const TEXT_ROOTED_DEVICE =
  'The device is rooted. For security reasons the application cannot be run from a rooted device.';
export const TEXT_PLACEHOLDER_CALENDAR_TITLE = 'You have no upcoming appointments';
export const TEXT_PLACHOLDER_CALENDAR_HEADER =
  'Your health care provider will schedule regular appointments with you as part of the trial.';
export const TEXT_PLACHOLDER_CALENDAR_DESC =
  'If you need to speak to your doctor, you can request an appointment at any time.';
export const MODAL_WEB_WIDTH = 400;
export const BASIC_WEBLAYOUT_BLOCK_WIDTH = 400;
export const WEB_LANDSCAPE_BREAKPOINT = 800;
export const TEXT_WELCOME_BUTTON_FINISH = 'Finish';
export const TEXT_WELCOME_BUTTON_NEXT = 'Next';
export const TEXT_WELCOME_BUTTON_SKIP = 'Skip';

export const IANA_TIMEZONE_DEFAULT = 'America/Los_Angeles';

export const TEXT_WITHDRAWAL_IMMEDIATELY = 'Immediately';
export const TEXT_WITHDRAWAL_DAYS = 'Within 7—10 days';
export const TEXT_WITHDRAWAL_CONTENT_ASK =
  'You will be asked to provide your reasons for withdrawing from the trial.';
export const TEXT_WITHDRAWAL_CONTENT_HEALTH =
  'Your health care provider will contact you to confirm your withdrawal from the trial.';
export const TEXT_WITHDRAWAL_CONTENT_PROVIDED =
  'If you have been provided with an Oura ring or phone, your provider will arrange for these to be returned.';
export const INNER_WEB_CONTAINER = 328;
export const OUTER_WEB_CONTAINER = 432;
export const LEFT_SIDE_MARGIN_TOP = 160;
export const getMakePhoneCallMessage = (phone: string, title: string) =>
  `The direct dialing feature is not enabled at this time, please call the ${title} at ${phone}`;

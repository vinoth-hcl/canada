export default {
  isJailBroken: () => false,
};

export interface SurveyModelDto {
  name: string;
  title: string;
  description: string;
  pages: {
    elements: {
      type: 'panel';
      name?: string;
      title: string;
      content: string;
      imageSource: string;
      hideNumber?: boolean;
      elements: {
        type: 'rating' | 'checkbox';
        name?: string;
        title: string;
        titleLocation?: string;
        hideNumber?: boolean;
        valueName?: string;
        defaultValue?: string;
        rateValues?: {
          value: string;
          text: string;
          [k: string]: unknown;
        }[];
        choices?: {
          value: string;
          text: string;
          [k: string]: unknown;
        }[];
        [k: string]: unknown;
      }[];
      [k: string]: unknown;
    }[];
    [k: string]: unknown;
  }[];
}

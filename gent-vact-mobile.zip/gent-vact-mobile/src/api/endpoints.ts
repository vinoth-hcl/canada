import { stringify } from 'query-string';
import {
  IAppointmentsFreeSlotsQueryParams,
  IAppointmentsQueryParams,
} from '../services/appointments/types';
import { INotificationsQueryParams } from '../services/notifications/types';
import { ITrialContactQueryParams } from '../services/support/types';

export const PATIENT_PROFILE_ENDPOINT = '/api/v1/patient/profile';
export const PATIENT_ALERTS_ENDPOINT = '/api/v1/patient/alerts/active';
export const API_AUTHENTICATE_ENDPOINT = '/api/v1/authenticate';
export const PATIENT_REQUEST_CALL_DOCTOR_ENDPOINT = (body: {
  message: string;
  level: string;
}): string => `/api/v1/patient/alert?${stringify(body)}`;
export const REFRESH_TOKENS_ENDPOINT = '/api/v1/refresh';
export const POST_FCM_TOKEN_ENDPOINT = '/api/v1/device';
export const DETACH_FCM_TOKEN_ENDPOINT = '/api/v1/device/detach';
export const API_LOGOUT_ENDPOINT = '/api/v1/logout';
export const GET_CONFIGURATION_PROFILE = '/api/v1/profile/me';
export const GET_BACKEND_VERSION_ENDPOINT = '/api/v1/info';
export const POST_ADD_APPOINTMENT_SLOT_ENDPOINT = '/api/v1/patient/appointment';
export const GET_APPOINTMENTS_FREE_SLOTS_ENDPOINT = (body?: IAppointmentsFreeSlotsQueryParams) => {
  const FETCH_APPOINTMENTS_FREE_SLOTS_ENDPOINT = '/api/v1/patient/appointment/free-slots';
  return body
    ? `${FETCH_APPOINTMENTS_FREE_SLOTS_ENDPOINT}?${stringify(body)}`
    : FETCH_APPOINTMENTS_FREE_SLOTS_ENDPOINT;
};
export const POST_APPOINTMENTS_ENDPOINT = (query: IAppointmentsQueryParams) =>
  `/api/v1/appointment/search?${stringify(query)}`;
export const APPOINTMENTS_REQUESTS_ENDPOINT = '/api/v1/patient/newAppointmentRequests';
export const GET_APPOINTMENT_DETAILS_BY_ID_ENDPOINT = (id: string) => `/api/v1/appointment/${id}`;
export const RESCHEDULE_APPOINTMENT_ENDPOINT = (id: string) =>
  `/api/v1/appointment/${id}/reschedule`;
export const CANCEL_APPOINTMENT_ENDPOINT = (id: string) => `/api/v1/appointment/${id}/cancel`;
export const REQUEST_APPOINTMENT_ENDPOINT = '/api/v1/patient/appointmentRequest';
export const GET_PATCH_CHECK_LIST_BY_ID = (id: string) => `/api/v1/checklist/${id}`;
export const COMPLETE_TODO_TASK_ENDPOINT = (taskId: string): string =>
  `/api/v1/patient/action/${taskId}`;
export const GET_TODO_LIST_ENDPOINT = '/api/v1/patient/action/nearest';
export const GENERATE_NEW_TODO_TASKS_ENDPOINT = '/api/v1/initNearestTasks';
export const GET_NOTIFICATIONS_ENDPOINT = (queryParams?: INotificationsQueryParams): string =>
  `/api/v1/notifications?${stringify(queryParams || {})}`;
export const RESOLVE_NOTIFICATION_ENDPOINT = (id: string) => `/api/v1/notification/${id}/resolve`;
export const GET_NOTIFICATION_ENDPOINT = (id: string): string => `/api/v1/notification/${id}`;
export const GET_CERTIFICATE_ENDPOINT = (deviceId: string) => `/api/v1/certificate/${deviceId}`;
export const GET_OPTIONS_ENDPOINT = '/api/v1/profile/preferences';
export const PUT_CHECK_LIST_COMPLETE_ENDPOINT = (id: string) => `/api/v1/checklist/${id}/complete`;
export const POST_CONFIRM_TIME_SLOT = (id: string) => `/api/v1/appointment/${id}/time-slot/confirm`;
export const GET_SURVEY_ID_ENDPOINT = (id: string) => `/api/v1/survey/${id}`;
export const PUT_SURVEY_RESULT = '/api/v1/survey/';

export const GET_TRIAL_CONTACTS_ENDPOINT = (queryParams: ITrialContactQueryParams): string =>
  `/api/v1/trial-contact?${stringify(queryParams)}`;
export const GET_INIT_TRIAL_CONTACTS_ENDPOINT = (trialId: string): string =>
  `/api/v1/initTrialContacts/${trialId}`;
export const REQUEST_CALL_ENDPOINT = '/api/v1/callrequest';

// TODO: should be change later path after implemented on backend
export const GET_CANCEL_REQUEST_CALL_ENDPOINT = (id: string) => `/api/v1/callrequest/${id}/cancel`;
export const POST_SURVEY_TEMPLATE_SEARCH = '/api/v1/survey/template/search';
export const GET_EXIT_INSTRUCTIONS_ENDPOINT = (trialId: string) =>
  `/api/v1/trial/${trialId}/exit-instructions`;

export const POST_METRICS = '/api/v1/metrics';
export const POST_METRICS_BEACON = '/api/v1/metrics-beacon';

export const PUT_CHANGE_RING_SIZE_ENDPOINT = '/api/v1/ring/size/update';

export const GET_WITHDRAW_REASONS = '/api/v1/withdraw-request/withdraw-reason';
export const POST_WITHDRAWAL_REQUEST = '/api/v1/withdraw-request';
export const POST_DELETE_WITHDRAWAL_REQUEST = (requestId: string) =>
  `/api/v1/withdraw-request/${requestId}`;

export const GET_CREDENTIALS_ENDPOINT = '/api/v1/patient/settings';

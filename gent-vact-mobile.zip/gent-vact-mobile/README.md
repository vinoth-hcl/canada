
# Android
## build and run on emulator for Android

```
> npm i
> npm run android:dev
```

## build package

```
> npm i
> npm run android:dev:build
```

install *json* package if it is not installed
```shell
> brew install json
```

# IOS

## build and run on simulator
```
> npm run ios:install
> npm run ios:dev
```

## build package

```
> npm run ios:dev:build
```

> **NOTE**: ios package build require an AppleID login and provision file downloading in xcode

# Web platform

## Start Web frontend in development mode
1. Create certificates files from key values from [Vault](https://vault.gent-vact.projects.epam.com/ui/vault/secrets/local_dev_secrets/show/certbot_local.dev1.gneva.io) (use LDAP authorization and your EPAM credentials):
    * from key `IssuerCA` into file `.cert/ca.pem`
    * from key `cert` into file `.cert/server.crt`
    * from key `privateKey` into file `.cert/server.key` 
  * for dev2: https://vault.gent-vact.projects.epam.com/ui/vault/secrets/local_dev_secrets/show/certbot_local.dev2.gneva.io
2. Run local dev server
```
> npm i
> npm run web:local
```
3. App will be available at https://local.dev1.gneva.io:8080/.


4. Build app for dev/dev2/demo env
```
> npm run web:dev:build
```

```
> npm run web:dev2:build
```

```
> npm run web:demo:build
```

Static bundle with index.html will be in folder `dist`

#!/bin/sh
npm run ios:install \
  && npm run android:demo:build && npm run android:qa1:build && npm run android:prod:build \
  && npm run ios:demo:build && npm run ios:qa1:build && npm run ios:prod:build

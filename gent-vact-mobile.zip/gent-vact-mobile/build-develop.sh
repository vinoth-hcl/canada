#!/bin/sh
npm run ios:install \
  && npm run android:dev:build && npm run android:dev2:build \
  && npm run ios:dev:build && npm run ios:dev2:build

#!/bin/sh
npm run ios:install \
  && npm run android:prod:build \
  && npm run ios:prod:build

#!/bin/bash

set -e

export SCHEME="GentvactMobile"
export APP="The Compass"
export DISTNAME="theCompass"
export DEVELOPMENT_TEAM="Q7TST28CLD"
export PROVISIONING_PROFILE="./gentvactadhoc14.mobileprovision"
export PROVISIONING_PROFILE_SPECIFIER="gentvact-adhoc-14"
export ENVFILE=".env.${ENVNAME:-demo}"
export VERSION=$(json -f ../package.json version)

echo start build: $ENVFILE $VERSION

xcodebuild clean archive -scheme ${SCHEME} \
  -workspace ${SCHEME}.xcworkspace \
  -configuration Release -archivePath ./builds/${SCHEME}.xcarchive \
  DEVELOPMENT_TEAM=${DEVELOPMENT_TEAM} \
  PROVISIONING_PROFILE=${PROVISIONING_PROFILE}

xcodebuild -exportArchive -allowProvisioningUpdates -allowProvisioningDeviceRegistration \
  -archivePath ./builds/${SCHEME}.xcarchive -exportPath ./builds/ -exportOptionsPlist ./iosExportOptions.plist \
  DEVELOPMENT_TEAM=${DEVELOPMENT_TEAM} \
  PROVISIONING_PROFILE=${PROVISIONING_PROFILE}

mv "./builds/${APP}.ipa" ./builds/${DISTNAME}-${ENVNAME}-${VERSION}.ipa

echo "package created: " ios/builds/${DISTNAME}-${ENVNAME}-${VERSION}.ipa
ls -l ./builds/${DISTNAME}-${ENVNAME}-${VERSION}.ipa

#!/bin/sh
ENVFILE=qa1 ./build-ipa.sh

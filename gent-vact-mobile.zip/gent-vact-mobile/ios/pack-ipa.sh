#!/bin/bash

export SCHEME="theCompass"
export APP="theCompass"
export DEVELOPMENT_TEAM="Q7TST28CLD"
export PROVISIONING_PROFILE="./gentvact062.mobileprovision"

xcodebuild -exportArchive -archivePath ./builds/${APP}.xcarchive -exportPath ./builds/ -exportOptionsPlist ./iosExportOptions.plist

#!/bin/sh
ENVNAME=dev2 ./build-ipa.sh

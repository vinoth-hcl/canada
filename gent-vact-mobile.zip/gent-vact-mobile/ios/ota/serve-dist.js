const { readFileSync } = require('fs');
const https = require('https');

const serveStatic = require('serve-static');
const express = require('express');
// const morgan = require('morgan');

const credentials = {
  key: readFileSync('../../cert/server.key'),
  cert: readFileSync('../../cert/server.crt'),
  ca: readFileSync('../../cert/ca.pem'),
};

const app = express();

const port = 8008;
const hostname = 'local.dev1.gneva.io';

// eslint-disable-next-line no-console
console.log({ port, hostname });

// app.use(morgan('tiny'));
app.use(serveStatic('dist', { index: ['index.html'] }));

const httpsServer = https.createServer(credentials, app);

httpsServer.listen({ port, host: hostname }, () => {
  // eslint-disable-next-line no-console
  console.log(`server running at https://${hostname}:${port}`);
});

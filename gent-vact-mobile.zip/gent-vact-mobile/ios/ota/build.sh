#!/bin/bash
set -e

VERSION=$(json -f ../../package.json version)

ROOT_URL="${ROOT_URL:-https://gent-mobile-static.s3.amazonaws.com}"
ENVS="${ENVS:-dev2 demo qa1 prod}"
ENVS_JS="${ENVS_JS:-[\"dev2\", \"demo\", \"qa1\", \"prod\"]}"
APP_TITLE="The Compass"
APP_BUNDLE_IDENTIFIER="com.gentvactmobile"
APP_NAME="theCompass"

OPTIONS="{\
\"APP_BUNDLE_IDENTIFIER\":\"${APP_BUNDLE_IDENTIFIER}\",\
\"APP_BUNDLE_VERSION\":\"${VERSION}\",\
\"APP_TITLE\":\"${APP_TITLE}\",\
\"ROOT_URL\":\"${ROOT_URL}\",\
\"ENVS_JS\":${ENVS_JS},\
\"APP_NAME\":\"${APP_NAME}\",\
\"IPA_URL\":\"${ROOT_URL}/${IPAFILE}\"\
}"

OUT="./dist/${VERSION}"

npx ejs-cli "index.html.ejs" --out "${OUT}" --options "${OPTIONS}"

for ENVNAME in $ENVS
do
IPAFILE="${APP_NAME}-${ENVNAME}-${VERSION}.ipa"
APKFILE="${APP_NAME}-${ENVNAME}-${VERSION}.apk"
MOPTIONS="{\
\"APP_BUNDLE_IDENTIFIER\":\"${APP_BUNDLE_IDENTIFIER}\",\
\"APP_BUNDLE_VERSION\":\"${VERSION}\",\
\"APP_TITLE\":\"${APP_TITLE}\",\
\"ROOT_URL\":\"${ROOT_URL}\",\
\"IPA_URL\":\"${ROOT_URL}/${VERSION}/${IPAFILE}\",\
\"APK_URL\":\"${ROOT_URL}/${VERSION}/${APKFILE}\"\
}"
  npx ejs-cli "manifest.plist.ejs" --out "${OUT}" --options "${MOPTIONS}"
  mv "${OUT}/manifest.plist" "${OUT}/manifest-${ENVNAME}-${VERSION}.plist"
  cp -v "../builds/${IPAFILE}" "${OUT}/${IPAFILE}"
  cp -v "../../android/app/build/outputs/apk/release/${APKFILE}" "${OUT}/${APKFILE}"
done

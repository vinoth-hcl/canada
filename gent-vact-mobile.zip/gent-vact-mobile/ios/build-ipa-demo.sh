#!/bin/sh
ENVFILE=demo ./build-ipa.sh

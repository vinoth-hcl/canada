#!/bin/sh
ENVNAME=dev1 ./build-ipa.sh

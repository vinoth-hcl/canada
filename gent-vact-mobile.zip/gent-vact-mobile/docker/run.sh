#!/bin/bash -xe

ENV_VARIABLES='${AWS_BUCKET},${AWS_REGION},${NGINX_TOKEN},${GENEVA_VERSION},${CONFIG_JSON},${LISTEN_PORT},${CONTENT_PATH},${ENVIRONMENT}'

envsubst "${ENV_VARIABLES}" < /etc/nginx/conf.d/site.template
envsubst "${ENV_VARIABLES}" < /etc/nginx/conf.d/site.template  > /etc/nginx/conf.d/default.conf
exec nginx -g 'daemon off;'

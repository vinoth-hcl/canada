/**
 * @format
 */
import 'react-native-gesture-handler';
import { AppRegistry } from 'react-native';
import config from 'react-native-config';

import { name as appName } from './app.json';

const App = config.STORYBOOK === 'ON' ? require('./storybook') : require('./src/app/App');

AppRegistry.registerComponent(appName, () => App);

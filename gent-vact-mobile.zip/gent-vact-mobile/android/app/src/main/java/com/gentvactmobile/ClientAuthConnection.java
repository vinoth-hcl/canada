package com.gentvactmobile;

import android.os.Build;

import androidx.annotation.RequiresApi;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.Arrays;
import java.util.Base64;
import java.util.Optional;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import static java.util.Optional.*;

public class ClientAuthConnection extends ReactContextBaseJavaModule {
  private static ReactApplicationContext reactContext;

  private SSLContext sslContext;
  private SSLTrustContext sslTrustContext;
  private String lastClientCertP12Base64;
  private String lastClientCertPasswd;
  private String lastServerPem;

  ClientAuthConnection(ReactApplicationContext context) {
    super(context);
    reactContext = context;
  }

  @Override
  public String getName() {
    return "ClientAuthConnection";
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  @ReactMethod
  public void post(String clientCertP12Base64, String clientCertPasswd, String serverPem, String url, String deviceId,
    String payload, final Promise promise) {

    try {
      if (clientCertP12Base64 != lastClientCertP12Base64 || clientCertPasswd != lastClientCertPasswd || serverPem != lastServerPem ) {
        sslTrustContext = buildSSLContext(clientCertP12Base64, clientCertPasswd, serverPem);
        sslContext = sslTrustContext.sslContext;
        lastClientCertPasswd = clientCertPasswd;
        lastClientCertP12Base64 = clientCertP12Base64;
        lastServerPem = serverPem;
      }
      doPostOkHttp(sslTrustContext, url, deviceId, payload, promise);

    } catch (Exception e) {
      promise.reject(e);
    }
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  @ReactMethod
  public void post2(String clientPemCert, String clientPrivateKey, String clientCertPasswd, String serverPem, String url, String deviceId,
    String payload, final Promise promise) {

    try {
      if (clientPemCert != lastClientCertP12Base64 || clientCertPasswd != lastClientCertPasswd || serverPem != lastServerPem ) {
        sslTrustContext = buildSSLContext2(clientPemCert, clientPrivateKey, clientCertPasswd, serverPem);
        sslContext = sslTrustContext.sslContext;
        lastClientCertPasswd = clientCertPasswd;
        lastClientCertP12Base64 = clientPemCert;
        lastServerPem = serverPem;
      }
      doPostOkHttp(sslTrustContext, url, deviceId, payload, promise);

    } catch (Exception e) {
      promise.reject(e);
    }
  }

  private static class SSLTrustContext {
    public SSLContext sslContext;
    public X509TrustManager trustManager;

    public SSLTrustContext(SSLContext ssl, X509TrustManager manager) {
      sslContext = ssl;
      trustManager = manager;
    }
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  private SSLTrustContext buildSSLContext(String clientCertP12Base64, String clientPasswd, String caCert) throws CertificateException, NoSuchAlgorithmException, IOException, KeyStoreException, UnrecoverableKeyException, KeyManagementException {
    KeyStore keyStore = KeyStore.getInstance("PKCS12");

    // client certificate
    byte[] clientCert = Base64.getDecoder().decode(clientCertP12Base64.replaceAll("\n", ""));
    InputStream is = new ByteArrayInputStream(clientCert);
    keyStore.load(is, clientPasswd.toCharArray());
    is.close();
    KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("X509");
    keyManagerFactory.init(keyStore, clientPasswd.toCharArray());
    // Amazon Root Certificate
    CertificateFactory cf = CertificateFactory.getInstance("X.509");
    InputStream in = new ByteArrayInputStream(caCert.getBytes());
    Certificate certs = cf.generateCertificate(in);
    in.close();
    keyStore.setCertificateEntry("AmazonCA1", certs);
    TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
    trustManagerFactory.init(keyStore);
    // create context
    SSLContext sslContext = SSLContext.getInstance("TLS");
    TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
    sslContext.init(keyManagerFactory.getKeyManagers(), trustManagers, null);
    if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
      throw new IllegalStateException("Unexpected default trust managers:" + Arrays.toString(trustManagers));
    }
    X509TrustManager trustManager = (X509TrustManager) trustManagers[0];
    return new SSLTrustContext(sslContext, trustManager);
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  private SSLTrustContext buildSSLContext2(String clientPemCert, String clientPrivateKey, String clientPasswd, String caCert) throws GeneralSecurityException, IOException {

    KeyStore keyStore = PemReader.loadKeyStore(clientPemCert, clientPrivateKey, clientPasswd.isEmpty() ? Optional.empty() : of(clientPasswd));

    KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("X509");
    keyManagerFactory.init(keyStore, clientPasswd.toCharArray());

    // Amazon Root Certificate
    CertificateFactory cf = CertificateFactory.getInstance("X.509");
    InputStream in = new ByteArrayInputStream(caCert.getBytes());
    Certificate certs = cf.generateCertificate(in);
    in.close();
    keyStore.setCertificateEntry("AmazonCA1", certs);
    TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
    trustManagerFactory.init(keyStore);
    // create context
    SSLContext sslContext = SSLContext.getInstance("TLS");
    TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();

    sslContext.init(keyManagerFactory.getKeyManagers(), trustManagers, null);

    if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
      throw new IllegalStateException("Unexpected default trust managers:" + Arrays.toString(trustManagers));
    }
    X509TrustManager trustManager = (X509TrustManager) trustManagers[0];
    return new SSLTrustContext(sslContext, trustManager);
  }

  private void doPostOkHttp(SSLTrustContext context, String URL, String deviceId, String payload, Promise promise)  {
    OkHttpClient client = new OkHttpClient.Builder()
      .sslSocketFactory(context.sslContext.getSocketFactory(), context.trustManager)
      .build();

    Request request = new Request.Builder()
      .url(URL + deviceId + "?qos=1")
      .post(RequestBody.create(MediaType.parse("application/json; charset=utf-8"), payload))
      .build();

    client.newCall(request).enqueue(new Callback() {
      @Override public void onFailure(Call call, IOException e) {
        promise.reject(e);
      }

      @Override public void onResponse(Call call, Response response) throws IOException {
        promise.resolve(response.body().string());
//        promise.resolve(response.code());
      }
    });
  }

  private int doPost(SSLContext sslContext, String URL, String deviceId, String payload) throws Exception {
    HttpsURLConnection conn = (HttpsURLConnection) new URL(URL + deviceId + "?qos=1").openConnection();
    conn.setSSLSocketFactory(sslContext.getSocketFactory());
    conn.setRequestMethod("POST");
    conn.setDoInput(true);
    conn.setDoOutput(true);

    OutputStream os = conn.getOutputStream();
    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os));
    writer.write(payload);

    writer.flush();
    os.close();

    int status = conn.getResponseCode();
    if (status != 200)
      throw new Exception("Response status: " + status + " message: " +  conn.getResponseMessage());
    return status;
  }
}

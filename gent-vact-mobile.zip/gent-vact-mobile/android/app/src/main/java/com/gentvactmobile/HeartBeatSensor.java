package com.gentvactmobile;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import androidx.annotation.Nullable;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.modules.core.DeviceEventManagerModule;

public class HeartBeatSensor extends ReactContextBaseJavaModule {
  private static ReactApplicationContext reactContext;

  private SensorManager sensorManager;
  private SensorEventListener sensorEventListener;
  private Sensor heartRateSensor;
  private Sensor pressureSensor;
  private Sensor accelerometerSensor;
  private Sensor temperatureSensor;

  HeartBeatSensor(ReactApplicationContext context) {
    super(context);
    reactContext = context;
    initSensors();
  }

  private void sendEvent(ReactContext reactContext,
                         String eventName,
                         @Nullable WritableMap params) {
    reactContext
      .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
      .emit(eventName, params);
  }

  private void initSensors() {
    sensorManager = (SensorManager) reactContext.getSystemService(reactContext.SENSOR_SERVICE);
    sensorEventListener = new SensorEventListener() {
      @Override
      public void onSensorChanged(SensorEvent sensorEvent) {
        WritableMap params = Arguments.createMap();
        int sensorType = sensorEvent.sensor.getType();
        float value = sensorEvent.values[0];
        if ( sensorType == Sensor.TYPE_PRESSURE) {
          params.putDouble("pressure", value);
        }  else if (sensorType == Sensor.TYPE_HEART_RATE) {
          params.putDouble("heart_rate", value);
        }  else if (sensorType == Sensor.TYPE_ACCELEROMETER) {
          params.putDouble("accelerometer", value);
        }  else if (sensorType == Sensor.TYPE_AMBIENT_TEMPERATURE) {
          params.putDouble("temperature", value);
        }

        sendEvent(reactContext, "HeartBeatEvent",  params);
      }

      @Override
      public void onAccuracyChanged(Sensor sensor, int i) {
      }
    };
    heartRateSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
    pressureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
    accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    temperatureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
  }

  @Override
  public String getName() {
    return "HeartBeatSensor";
  }

  @ReactMethod
  public void start() {
    stop();
    if (heartRateSensor != null) {
      sensorManager.registerListener(sensorEventListener, heartRateSensor, SensorManager.SENSOR_DELAY_UI);
    }
    if (pressureSensor != null) {
      sensorManager.registerListener(sensorEventListener, pressureSensor, SensorManager.SENSOR_DELAY_UI);
    }
    if (accelerometerSensor != null) {
      sensorManager.registerListener(sensorEventListener, accelerometerSensor, SensorManager.SENSOR_DELAY_UI);
    }
    if (temperatureSensor != null) {
      sensorManager.registerListener(sensorEventListener, temperatureSensor, SensorManager.SENSOR_DELAY_UI);
    }
  }

  @ReactMethod
  public void stop() {
    if (heartRateSensor != null) {
      sensorManager.unregisterListener(sensorEventListener, heartRateSensor);
    }
    if (pressureSensor != null) {
      sensorManager.unregisterListener(sensorEventListener, pressureSensor);
    }
  }
}

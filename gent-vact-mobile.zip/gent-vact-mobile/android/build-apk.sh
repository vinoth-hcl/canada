#!/bin/bash

set -e

export APP="theCompass"
export DISTNAME="theCompass"
export ENVFILE=".env.${ENVNAME:-demo}"
export VERSION=$(json -f ../package.json version)

echo start build: $ENVFILE $VERSION

(cd .. && npx jetify)

./gradlew assembleRelease

mv ./app/build/outputs/apk/release/app-release.apk ./app/build/outputs/apk/release/${DISTNAME}-${ENVNAME}-${VERSION}.apk

echo "package created: " android/app/build/outputs/apk/release/${DISTNAME}-${ENVNAME}-${VERSION}.apk
ls -l ./app/build/outputs/apk/release/${DISTNAME}-${ENVNAME}-${VERSION}.apk

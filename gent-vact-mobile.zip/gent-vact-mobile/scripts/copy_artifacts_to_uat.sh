#!/bin/bash
echo "start copy artifacts to qa"
aws s3 cp --grants read=uri=http://acs.amazonaws.com/groups/global/AllUsers \
    full=id=${UAT_ACCOUNT_ID} \
    --recursive  "s3://${DEV_FRONT_S3}/${APPLICATION_NAME}/${BRANCH}" "s3://${UAT_FRONT_S3}/${APPLICATION_NAME}/${BRANCH}"

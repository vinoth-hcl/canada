#!/bin/bash

echo 'copy start'

if [ -d "dist" ]; then
  aws s3 rm --recursive "s3://${DEV_FRONT_S3}/${APPLICATION_NAME}/${BRANCH}"
  aws s3 cp --grants read=uri=http://acs.amazonaws.com/groups/global/AllUsers \
    full=id=${DEV_ACCOUNT_ID} \
    --recursive dist "s3://${DEV_FRONT_S3}/${APPLICATION_NAME}/${BRANCH}"
else
  echo "Artifacts doesn't exist"
fi

#!/bin/bash
echo "start copy artifacts to uat"
aws s3 cp --grants read=uri=http://acs.amazonaws.com/groups/global/AllUsers \
    full=id=${DEV_ACCOUNT_ID} \
    --recursive  "s3://${DEV_FRONT_S3}/${APPLICATION_NAME}/${BRANCH}" "s3://${QA_FRONT_S3}/${APPLICATION_NAME}/${BRANCH}"

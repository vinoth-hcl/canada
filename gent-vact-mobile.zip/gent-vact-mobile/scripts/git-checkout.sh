#!/bin/bash

STATIC_BRANCHES='develop|master|stable'
FEATURE_BRANCHES='((feature|hotfix|bugfix)-GENTVACT-[0-9]{1,4}-[A-Za-z0-9-]{1,64})'
MR_BRANCHES='(merge-requests/[0-9]{1,5})'

REGEX_STRING="^${STATIC_BRANCHES}|${FEATURE_BRANCHES}|${MR_BRANCHES}$"

# https://gitlab.com/gitlab-org/gitlab/-/issues/195933
# https://gitlab.com/gitlab-org/gitlab-foss/-/issues/19421
# https://docs.gitlab.com/ee/ci/variables/predefined_variables.html
if [[ "${CI_PIPELINE_SOURCE}" = "merge_request_event" ]]; then
  BRANCH_NAME="merge-requests/${CI_MERGE_REQUEST_IID}"
elif [[ -n "${CI_COMMIT_TAG}" ]]; then
  BRANCH_NAME=$(git branch --points-at "${CI_BUILD_TAG}" --format="%(refname:short)" | head -n 1);
else
  BRANCH_NAME="${CI_COMMIT_REF_NAME}"
fi
git checkout -B "${BRANCH_NAME}" "${CI_COMMIT_SHA}"

export BRANCH=$(git rev-parse --abbrev-ref HEAD)

echo "Branch name is ${BRANCH}"

if [[ -z $(echo "${BRANCH}" | grep -E "${REGEX_STRING}") ]]; then
  echo  "[Error] Name branches as follows: <branch_type>-<jira-issue>-<keyphrase>"
  echo  "[Error] branch_type is one of - feature|hotfix|bugfix"
  echo  "[Error] jira-issue - number of JIRA issue with prefix GENTVACT"
  echo  "[Error] keyphrase - whatever you see fit to help identifying the branch owner or subject."
  echo  "[Error] Please see https://kb.epam.com/display/GENTVACT/Dev+Practices"
  exit 1
fi

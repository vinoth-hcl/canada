import { AppRegistry } from 'react-native';
import App from './src/app/App';
// import React from 'react';

import { name as appName } from './app.json';

// import App from './src/app/AppWebTest';
// console.log({appName, App})

AppRegistry.registerComponent(appName, () => App);

AppRegistry.runApplication(appName, {
  initialProps: {},
  rootTag: document.getElementById('react-root'),
});

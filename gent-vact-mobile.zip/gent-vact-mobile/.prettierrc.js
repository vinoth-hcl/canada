module.exports = {
  bracketSpacing: true,
  jsxBracketSameLine: false,
  jsxSingleQuote: false,
  printWidth: 100,
  singleQuote: true,
  trailingComma: 'all',
  endOfLine: 'auto',
  useTabs: false,
  tabWidth: 2,
  semi: true,
};

module.exports = {
  project: {
    ios: {},
    android: {},
    web: {},
  },
  assets: ['./assets/fonts'],
};
